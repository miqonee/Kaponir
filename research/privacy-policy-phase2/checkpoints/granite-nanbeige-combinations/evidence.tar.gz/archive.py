"""Archive combined Kaponir presets and update the existing search table."""

import csv
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile


REPO = Path('/workspace/Kaponir')
WORK = Path(__file__).parent
OUTPUT = WORK / 'kaponir-hybrid-pilot/granite-nanbeige-v2'
CHECKPOINT = REPO / 'research/privacy-policy-phase2/checkpoints/granite-nanbeige-combinations'
CSV = REPO / 'docs/experiments/model-search-summary.csv'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()


def trial(folder, files):
    details = json.loads((folder / 'result.json').read_text())
    r = details['search']
    keys = ('completed', 'private_total', 'public_total', 'private_full', 'public_lost',
            'reference_replacements', 'http_seconds', 'quality_70', 'score_100', 'exact_roundtrips')
    plan = {k: details[k] for k in ('model', 'label', 'profile')}
    plan['search'] = {k: r[k] for k in keys}
    for path in ('plan.json', 'layout.json', 'discovery.json', 'transports.json',
                 'non-log/transports.json', 'result.json'):
        file = folder / path
        if file.is_file():
            files[file.relative_to(OUTPUT).as_posix()] = file.read_bytes()
    for file in (folder / 'apply').rglob('*.json'):
        files[file.relative_to(OUTPUT).as_posix()] = file.read_bytes()
    if r['completed']:
        name = f"{details['model']}-{details['label']}-application.json.gz"
        app = gzip.compress((folder / 'apply/result.json').read_bytes(), mtime=0)
        destination = CHECKPOINT / name
        destination.write_bytes(app)
        plan['application'] = str(destination.relative_to(REPO))
        plan['application_sha256'] = sha(app)
    return plan


def archive():
    CHECKPOINT.mkdir(parents=True, exist_ok=True)
    files = {'producer.py': (WORK / 'check-kaponir-granite-nanbeige-combos.py').read_bytes(),
             'archive.py': Path(__file__).read_bytes()}
    folders = [p.parent for p in sorted(OUTPUT.glob('*/*/result.json'))]
    trials = [trial(folder, files) for folder in folders]
    memory = io.BytesIO()
    with tarfile.open(fileobj=memory, mode='w') as tar:
        for name, raw in sorted(files.items()):
            member = tarfile.TarInfo(name)
            member.size = len(raw)
            tar.addfile(member, io.BytesIO(raw))
    raw = gzip.compress(memory.getvalue(), mtime=0)
    (CHECKPOINT / 'evidence.tar.gz').write_bytes(raw)
    receipt = {'data': 'Kaponir synthetic privacy corpus',
               'evidence_sha256': sha(raw), 'evidence_file': 'evidence.tar.gz',
               'members': {name:sha(raw) for name, raw in files.items()}, 'trials': trials}
    (CHECKPOINT / 'manifest.json').write_bytes(encoded(receipt))
    return trials


def append(trials):
    with CSV.open(newline='') as f:
        reader = csv.DictReader(f)
        rows, columns = list(reader), reader.fieldnames
    indexed = {(r['model'],r['series'],r['profile']): r for r in rows}
    assert len(indexed)==len(rows)
    for t in trials:
        s=t['search']
        if not s['completed']:
            continue
        archived_fragments = '-first-fragment-' in t['label']
        series = 'archive_hybrid' if t['label']=='direct-md-stock-log' or archived_fragments else 'calibrated'
        r = {'model': t['model'], 'series': series, 'profile': t['label'],
             'private_full_193': s['private_full'], 'public_lost_87': s['public_lost'],
             'guide_replacements': s['reference_replacements'], 'http_minutes': f"{s['http_seconds']/60:.9f}",
             'score_100': f"{s['score_100']:.2f}", 'application_or_table': t['application'],
             'application_sha256': t['application_sha256']}
        indexed[(t['model'],series,t['label'])] = r
    temporary = CSV.with_suffix('.csv.tmp')
    with temporary.open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=columns, lineterminator='\n')
        writer.writeheader()
        writer.writerows(indexed.values())
    temporary.replace(CSV)
    print(len(indexed), 'CSV profiles,', sum(bool(row['application_sha256']) for row in indexed.values()), 'application hashes')


if __name__ == '__main__':
    measured = archive()
    append(measured)
    print(len(measured), 'presets and', sum(t['search']['exact_roundtrips'] for t in measured), 'exact restores archived')
