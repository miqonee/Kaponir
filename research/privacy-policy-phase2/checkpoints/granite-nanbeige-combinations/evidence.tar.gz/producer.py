"""Measure parameter combinations on the archived four-part Kaponir log."""

from argparse import ArgumentParser, Namespace
from contextlib import contextmanager
import gzip
import hashlib
import json
import os
from pathlib import Path
import runpy
from tempfile import TemporaryDirectory
from types import SimpleNamespace

from experiment_inference import discover, extraction_schema, prompts_and_kinds
from kaponir_inference import document_hint, plan_text
from kaponir_worker import FILES, Worker, configuration, schema_prompt
from run_privacy_policy_suite import atomic_json, file_sha
from summarize_privacy_policy import digest, require, strict_json


BASE = runpy.run_path(str(Path(__file__).with_name('check-kaponir-granite-nanbeige.py')))
REPO, STUDY, RUNTIME, BINARY = (BASE[k] for k in ('REPO', 'STUDY', 'RUNTIME', 'BINARY'))
GRANITE, NANBEIGE = (BASE[k] for k in ('GRANITE', 'NANBEIGE'))
LOG = '02-application.log'
CONFIRM = 'granite-full-type-presets'
LEGACY = {
    GRANITE: ('granite', ((0, 2), (2, 6), (6, 7)), 'direct-card'),
    NANBEIGE: ('nanbeige', ((0, 15), (15, 25), (25, 26)), 'direct-greedy-schema'),
}
OPTIONS = {
    GRANITE: {
        'granite-log-t025': (.25, -1, 'chat-grammar'),
        'granite-log-low128-t0': (0, 128, 'chat-grammar'),
    },
    NANBEIGE: {
        'nanbeige-log-t0-schema': (0, -1, 'completion-grammar'),
        'nanbeige-log-t06-schema': (.6, -1, 'completion-grammar'),
    },
}
OUTPUT = BASE['PILOT'] / 'granite-nanbeige-v2'


def read(path):
    raw = gzip.decompress(path.read_bytes()) if path.suffix == '.gz' else path.read_bytes()
    return strict_json(raw.decode())


def legacy_inputs(model, sources):
    name, slices, _ = LEGACY[model]
    source_path = REPO / 'docs/benchmarks' / f'{name}-calibration--result.json.gz'
    archive = read(source_path)
    app_path = REPO / 'research/privacy-policy-phase2/checkpoints/2026-11-17/evidence/application-v2' / 'runs/archive' / f'{name}-calibration/current_union/result.json.gz'
    app = read(app_path)
    require(app['source_model_artifact'] == list(FILES[model]), 'legacy_weights_changed')
    require(all(d['source_sha256'] == hashlib.sha256(sources[d['file']].encode()).hexdigest()
                for d in app['documents']), 'legacy_documents_changed')
    stages = {}
    for doc, (start, end) in zip(BASE['DOCUMENTS'], slices, strict=True):
        old = archive['stages'][f'discovery:{doc}']
        hits = archive['discovery_progress'][doc]['responses'].values()
        require(not old['errors'] and max(row['record_index'] for row in hits) == end-1
                and all(start <= row['record_index'] < end for row in hits), 'legacy_call_mapping_changed')
        stages[doc] = {**old, 'http_seconds': sum(row['seconds'] for row in archive['calls'][start:end]),
                       'source': {'kind': 'legacy', 'path': str(source_path.relative_to(REPO)),
                                  'sha256': file_sha(source_path), 'call_start': start, 'call_end': end}}
    return archive, stages


def donor_stages(model):
    _, _, label = LEGACY[model]
    folder = BASE['OUTPUT'] / model / 'full' / label
    replay = BASE['load_replay'](folder)
    plan = read(folder / 'plan.json')
    require(plan['artifact'] == list(FILES[model]) and plan['runtime_sha256'] == file_sha(RUNTIME)
            and plan['binary_sha256'] == file_sha(BINARY), 'direct_donor_changed')
    stages = {}
    for doc, previous in replay['stages'].items():
        call, = [entry for entry in replay['requests'] if entry['record']['measurement_stage'] == f'discovery:{doc}']
        require(call['request_sha256'] == digest(call['request']) and not previous['errors']
                and previous['http_seconds'] == call['record']['http_wall_seconds'], 'direct_donor_bad_receipt')
        stages[doc] = {**previous, 'source': {'kind': 'recorded', 'profile': label,
                                            'request_sha256': call['request_sha256']}}
    return stages, plan['profile']


def apply(profile, model, folder, fixture, stages):
    atomic_json(folder / 'discovery.json', stages)
    result = BASE['apply_search'](SimpleNamespace(model=model), folder, fixture, stages)
    atomic_json(folder / 'result.json', {'model': model, 'label': folder.name, 'profile': profile,
                                        'search': result})
    data = result['documents'][LOG]
    print(model, folder.name, 'search', result['completed'], 'private', result['private_full'],
          'public lost', result['public_lost'], 'log private', data['private_spans_fully_covered'],
          'log public lost', data['public_occurrences_lost'], 'seconds', round(result['http_seconds'], 2),
          'score', round(result['score_100'], 2), flush=True)


def archived_combo(model, fixture):
    folder = OUTPUT / model / 'direct-md-stock-log'
    if (folder / 'result.json').exists():
        return
    folder.mkdir(parents=True, exist_ok=True)
    old, archived = legacy_inputs(model, fixture[0])
    direct, donor = donor_stages(model)
    profile = {'model_path': 'stock log and direct non-log', 'non_log_profile': donor,
               'archived_sampling': old['generation']}
    apply(profile, model, folder, fixture, {**direct, LOG: archived[LOG]})


def first_fragment_combo(model, label, fixture):
    previous = OUTPUT / model / label
    if not (previous / 'result.json').exists():
        return
    folder = OUTPUT / model / label.replace('-log-', '-first-fragment-')
    if (folder / 'result.json').exists():
        return
    layout = read(previous / 'layout.json')
    journal = read(previous / 'transports.json')
    first, = [entry for entry in journal['requests'] if entry['record'].get('fragment_index') == 1]
    old, historical = legacy_inputs(model, fixture[0])
    direct, profile = donor_stages(model)
    source = fixture[0][LOG]
    windows = [(strict_json(first['raw_reply']['content']), first['record']['http_wall_seconds'])]
    for part in layout[1:]:
        reply = old['discovery_progress'][LOG]['responses'][part['legacy_key']]
        windows.append((reply['reply'], old['calls'][reply['record_index']]['seconds']))
    found = {}
    for part, (reply, _) in zip(layout, windows, strict=True):
        text = source[part['start']:part['end']]
        for candidate in reply['candidates']:
            value = candidate.get('value', '')
            if isinstance(value, str) and 3 <= len(value.encode()) <= 512 and value == value.strip() and value in text:
                found.setdefault(value, {'value': value, 'kind': candidate.get('kind', 'CUSTOM'),
                                         'confidence': candidate.get('confidence')})
    direct[LOG] = {'values': list(found.values()), 'errors': [], 'fragments': len(layout),
                   'http_seconds': sum(seconds for _, seconds in windows),
                   'source': {'kind': 'first_schema', 'first_profile': label,
                              'legacy': historical[LOG]['source']}}
    settings = {'non_log_profile': profile, 'first_log_fragment': journal['profile'],
                'remaining_log_fragments': old['generation']}
    folder.mkdir(parents=True, exist_ok=True)
    apply(settings, model, folder, fixture, direct)


def matched_parts(client, archive, prompt, schema, source):
    planning = schema_prompt(prompt, schema) if archive['structured_output'] == 'prompt' else prompt
    def hint(offset):
        return document_hint(source, offset, 256, client.token_count)
    def fits(fragment, context):
        return client.worker.prompt_token_count(planning, {'context': context, 'source': fragment},
                                               {'enable_thinking': False}) <= 2432
    spans = plan_text(source, fits, hint)
    previous = archive['discovery_progress'][LOG]['responses']
    parts = []
    matched = 0
    for span in spans:
        value = {'context': span['context'], 'source': source[span['start']:span['end']]}
        fields = [prompt, value, schema, 1600, client.model, archive['structured_output'], archive['generation']]
        key = hashlib.sha256(json.dumps(fields, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        index = previous[key]['record_index'] if key in previous else None
        matched += index is not None
        parts.append((value, {**span, 'legacy_key': key, 'legacy_call_index': index}))
    print(client.model, 'legacy layout', len(parts), 'matched requests', matched, flush=True)
    require(len(parts) == 4 and matched >= 3, 'could_not_match_legacy_log_layout')
    return parts


def measure_log(client, archive, output, source):
    prompt, _, kinds = prompts_and_kinds()
    schema = extraction_schema(kinds, 'typed', client.profile['max_candidates'])
    parts = matched_parts(client, archive, prompt, schema, source)
    atomic_json(output / 'layout.json', [metadata for _, metadata in parts])
    found = {}
    errors = []
    client.measurement_stage = f'discovery:{LOG}'
    for idx, (value, meta) in enumerate(parts, 1):
        print(client.model, output.name, 'log fragment', idx, 'of', len(parts),
              'archive call', meta['legacy_call_index'], flush=True)
        try:
            reply = client.infer(prompt, value, schema, client.output_tokens)
            count_before = len(found)
            for candidate in reply['candidates']:
                quoted = candidate['value']
                if 3 <= len(quoted.encode()) <= 512 and quoted == quoted.strip() and quoted in value['source']:
                    found.setdefault(quoted, candidate)
            client.records[-1].update(candidate_count=len(reply['candidates']),
                                      new_values=len(found)-count_before, fragment_index=idx)
            client.save_history()
        except (ValueError, OSError) as exc:
            errors.append({'fragment': idx, 'error': type(exc).__name__, 'detail': str(exc)[:160]})
    return {'values': list(found.values()), 'errors': errors, 'fragments': len(parts),
            'requests': len(client.records), 'http_seconds': sum(r['http_wall_seconds'] for r in client.records),
            'source': {'kind': 'measured', 'transports': 'transports.json', 'layout': 'layout.json'}}


@contextmanager
def local(model, settings, folder, cpus):
    with TemporaryDirectory(prefix='kaponir-combination-') as td:
        home = Path(td)
        worker = Worker(home, configuration(home, {'model_dir': str(STUDY / 'models'),
                        'runtime': str(RUNTIME), 'threads': len(cpus), 'ocr_timeout_seconds': 300}), 'unused')
        try:
            sampling = {k: settings[k] for k in ('temperature', 'top_p', 'top_k', 'min_p', 'seed')}
            yield BASE['ValidatedClient'](worker, model, settings['context_tokens'], settings['output_tokens'],
                                         settings['response_format'], sampling, settings, folder, [])
        finally:
            worker.stop_runtime()


def fresh_nonlog(model, settings, folder, cpus, sources):
    output = folder / 'non-log'
    output.mkdir()
    prompt, _, kinds = prompts_and_kinds()
    args = Namespace(**settings, candidate_mode='typed', strategy='auto', target_input_tokens=0)
    stages = {}
    with local(model, settings, output, cpus) as client:
        for doc, text in sources.items():
            if doc == LOG:
                continue
            client.measurement_stage = f'discovery:{doc}'
            before = len(client.records)
            print(model, folder.name, doc, flush=True)
            found = discover(client, text, prompt, kinds, args, client.save_history, {})
            requests = client.records[before:]
            stages[doc] = {**found, 'http_seconds': sum(row['http_wall_seconds'] for row in requests),
                           'requests': len(requests),
                           'source': {'kind': 'fresh', 'journal': 'non-log/transports.json'}}
    return stages


def run(model, label, cpus, fixture):
    folder = OUTPUT / model / label
    if (folder / 'result.json').exists():
        return
    old, _ = legacy_inputs(model, fixture[0])
    direct, donor = donor_stages(model)
    option = (0, -1, 'chat-grammar') if label == CONFIRM else OPTIONS[model][label]
    settings = BASE['profile_for'](model, (label, *option), 'full')[1]
    settings.update(context_tokens=8192, output_tokens=2048, retry_output_tokens=3072, transport_timeout_seconds=900)
    if label == CONFIRM:
        settings.update(context_tokens=4096, output_tokens=1600, retry_output_tokens=1600)
    if label == 'granite-log-low128-t0':
        settings['template_kwargs']['low_effort'] = True
    profile = {'log': settings, 'non_log_profile': donor, 'cpus': cpus, 'runtime_sha256': file_sha(RUNTIME),
               'artifact': FILES[model], 'binary_sha256': file_sha(BINARY)}
    folder.mkdir(parents=True, exist_ok=False)
    atomic_json(folder / 'plan.json', profile)
    with local(model, settings, folder, cpus) as client:
        log = measure_log(client, old, folder, fixture[0][LOG])
    if label == CONFIRM:
        direct = fresh_nonlog(model, donor, folder, cpus, fixture[0])
    apply(profile, model, folder, fixture, {**direct, LOG: log})


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('model', choices=OPTIONS)
    parser.add_argument('--profile')
    parser.add_argument('--cpu-start', type=int)
    parser.add_argument('--archive-only', action='store_true')
    parser.add_argument('--combine-first-fragment', action='store_true')
    args = parser.parse_args()
    fixture = BASE['helpers']['corpus']()
    archived_combo(args.model, fixture)
    if args.archive_only:
        return
    if args.combine_first_fragment:
        require(args.model == NANBEIGE, 'first_fragment_recipe_is_nanbeige')
        for label in OPTIONS[args.model]:
            first_fragment_combo(args.model, label, fixture)
        return
    require(args.profile != CONFIRM or args.model == GRANITE, 'fresh_confirmation_is_granite')
    start = args.cpu_start if args.cpu_start is not None else (0 if args.model == GRANITE else 2)
    cpus = sorted(os.sched_getaffinity(0))[start:start+2]
    require(len(cpus) == 2, 'need_two_worker_cpus')
    os.sched_setaffinity(0, cpus)
    BASE['verify_inputs'](args.model)
    labels = [args.profile] if args.profile else OPTIONS[args.model]
    for label in labels:
        run(args.model, label, cpus, fixture)


if __name__ == '__main__':
    main()
