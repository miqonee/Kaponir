"""Apply combinations of recorded masks to the same documents without running a model."""

import gzip
from pathlib import Path

from apply_measured_privacy import apply_documents
from apply_scheme_masks import select_masks
from check_learning_corpus import load_corpus
from native_retest_baselines import base_scheme_source
from render_kaponir_user_table import search_minutes
from report_complete_research import legacy_summary
from report_native_model_retest import verified_application
from run_native_model_retest import DEFAULT_STUDY
from run_privacy_policy_suite import atomic_json, file_sha
from summarize_privacy_policy import require, strict_json


MODELS = ('lfm2.5-1.2b-instruct', 'tiny-aya-global', 'qwen3.5-4b', 'spark-x2.6-4b', 'gemma4-e4b-qat')
ROOT = DEFAULT_STUDY
OUTPUT = Path(__file__).parent / 'kaponir-hybrid-pilot' / 'archive-combinations'
BINARY = ROOT / 'build/release/kaponir'
METRICS = ('private_spans_fully_covered', 'private_spans_partly_covered',
           'private_spans_untouched', 'public_occurrences_lost')


def load_stage(model, method, sources, binary_sha, *, baseline=False):
    if baseline:
        path, archived = base_scheme_source(ROOT, model)
        application = ROOT / 'baseline-application' / model / method
    else:
        path = ROOT / 'schemes' / model / 'result.json'
        archived = False
        application = ROOT / 'application/schemes' / model / method
    measured = legacy_summary(path, archived)
    require(measured['model'] == model and measured['status'] == 'completed', 'hybrid_source_not_complete')
    raw = path.read_bytes()
    state = strict_json(gzip.decompress(raw) if archived else raw)
    stage = state['stages'][method]
    candidates, _ = select_masks(stage, sources)
    masks = {(name, row['value']): row for name, rows in candidates.items() for row in rows}
    protected = {(row['file'], row['value']) for row in stage['candidates'] if row.get('protected') is True}
    require(protected <= masks.keys(), 'hybrid_credential_selection_changed')
    checked = verified_application(application, measured, path, method, binary_sha, archived=archived)
    require(checked is not None and checked['exact_roundtrips'] == 6, 'hybrid_source_application_not_verified')
    document_minutes = {}
    if method == 'current_union':
        minutes = search_minutes(path, archived)
        for row in state['calls']:
            stage_name = row.get('measurement_stage', '')
            if stage_name.startswith('discovery:'):
                name = stage_name.split(':', 1)[1]
                document_minutes[name] = document_minutes.get(name, 0) + row['http_wall_seconds'] / 60
    else:
        calls = [row for row in state['calls'] if row.get('measurement_stage') == method]
        require(calls, 'hybrid_stage_timing_missing')
        minutes = sum(row['http_wall_seconds'] for row in calls) / 60
    return {'masks': masks, 'protected': protected, 'corpus': state['signature']['source_sha256'],
            'metrics': {key: checked[key] for key in METRICS}, 'minutes': minutes,
            'evidence_sha256': measured['result_sha256'], 'document_minutes': document_minutes}


def apply_pair(label, model, search, records, mode, sources, private, public):
    require(search['corpus'] == records['corpus'], 'hybrid_source_cohort_changed')
    combined = {**search['masks'], **records['masks']}
    minutes = search['minutes'] + records['minutes']
    if mode == 'agreement':
        keys = search['masks'].keys() & records['masks'].keys()
        keys |= search['protected'] | records['protected']
        combined = {key: value for key, value in combined.items() if key in keys}
    elif mode == 'route':
        # In this call search is the original profile, records the native search.
        keys = {key for key in search['masks'] if key[0].endswith('.log')}
        keys |= {key for key in records['masks'] if not key[0].endswith('.log')}
        keys |= search['protected'] | records['protected']
        combined = {key: value for key, value in combined.items() if key in keys}
        times = [(search if name.endswith('.log') else records)['document_minutes'].get(name)
                 for name in search['corpus']]
        minutes = sum(times) if all(value is not None for value in times) else None
    selected = {}
    for (name, _), row in combined.items():
        selected.setdefault(name, []).append(row)
    output = apply_documents(BINARY, OUTPUT / model / label, search['corpus'], sources, private, public, selected,
        {'label': label, 'model': model, 'source_results_sha256':
            [search['evidence_sha256'], records['evidence_sha256']]})
    rows = [row for row in output['documents'] if row['mode'] == 'model_masks_added']
    require(output['exact_roundtrips'] == 6 and output['new_inference_calls'] == 0,
            'hybrid_application_not_verified')
    return {'metrics': {key: sum(row[key] for row in rows) for key in METRICS},
            'source_minutes_sum': minutes,
            'exact_roundtrips': output['exact_roundtrips']}


def main():
    status = strict_json((ROOT / 'status.json').read_text())
    binary_sha = file_sha(BINARY)
    require(binary_sha == status['binary_sha256'], 'mask_binary_hash_changed')
    _, expected, public, sources, _ = load_corpus()
    private = {}
    for name, value in expected:
        private.setdefault(name, []).append(value)
    OUTPUT.mkdir(parents=True, exist_ok=False)
    results = {}
    qwen_search = None
    for model in MODELS:
        original = load_stage(model, 'current_union', sources, binary_sha, baseline=True)
        native = load_stage(model, 'current_union', sources, binary_sha)
        records = load_stage(model, 'regions', sources, binary_sha)
        row = {}
        for label, stage in [('original_search', original), ('native_search', native), ('native_records', records)]:
            row[label] = {'metrics': stage['metrics'], 'minutes': stage['minutes']}
        for label, search, mode in (
                ('original_plus_records', original, 'union'),
                ('original_confirmed_by_records', original, 'agreement'),
                ('native_plus_records', native, 'union')):
            row[label] = apply_pair(label, model, search, records, mode, sources, private, public)
        row['original_for_logs'] = apply_pair(
            'original_for_logs', model, original, native, 'route', sources, private, public)
        results[model] = row
        atomic_json(OUTPUT / 'summary.json', results)
        if model == 'qwen3.5-4b':
            qwen_search = native
        print(model, [(key, value['metrics'][METRICS[0]], value['metrics'][METRICS[3]])
                      for key, value in row.items()], flush=True)
    lfm_records = load_stage('lfm2.5-2.6b', 'regions', sources, binary_sha)
    results['qwen-search-lfm-records'] = apply_pair(
        'combined', 'qwen-search-lfm-records', qwen_search, lfm_records, 'union', sources, private, public)
    atomic_json(OUTPUT / 'summary.json', results)
    print('qwen-search-lfm-records', results['qwen-search-lfm-records'], flush=True)


if __name__ == '__main__':
    main()
