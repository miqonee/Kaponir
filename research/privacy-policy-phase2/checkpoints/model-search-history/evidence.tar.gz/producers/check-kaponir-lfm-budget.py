"""Replay two registered LFM region requests with a smaller reasoning budget."""

import hashlib
from pathlib import Path
from tempfile import TemporaryDirectory
import time

from apply_measured_privacy import apply_documents
from check_learning_corpus import load_corpus, occurrences
from compare_local_models import DOCUMENTS
from evaluate_privacy_policy import RUNTIME_SHA256, decode_transport, parse_response, request_raw
from kaponir_worker import Worker, configuration, http_json
from native_model_profiles import check_thinking
from privacy_expansion_profiles import research_registration
from recover_privacy_transport import wait_for_verified_model
from run_native_model_retest import DEFAULT_STUDY
from run_privacy_policy_suite import SuiteLock, atomic_json, file_sha, runtime_processes
from summarize_privacy_policy import digest, require, strict_json


MODEL = 'lfm2.5-2.6b'
RUN = DEFAULT_STUDY / 'schemes' / MODEL
OUTPUT = Path(__file__).parent / 'kaponir-hybrid-pilot' / 'lfm-budget'
RUNTIME = DEFAULT_STUDY / 'runtime/llama-b12038/llama-server'
BINARY = DEFAULT_STUDY / 'build/release/kaponir'


def choose(journal, sources, private, public):
    """First region <= 600 characters with >= 3 private values and >= 1 public control per document."""
    targets = DOCUMENTS[:2]
    selected = {}
    for index, entry in enumerate(journal['requests']):
        if entry['record']['measurement_stage'] != 'regions':
            continue
        body = strict_json(entry['request']['messages'][-1]['content'])
        text = body['source']
        documents = [name for name in DOCUMENTS if text in sources[name]]
        require(len(documents) == 1, 'ambiguous_region_source')
        name = documents[0]
        own = {value for value in private[name] if occurrences(text, value)}
        controls = {value for value in public.get(name, []) if occurrences(text, value)}
        if name in targets and name not in selected and len(text) <= 600 and len(own) >= 3 and controls:
            selected[name] = (index, text, own, controls, entry)
    require(set(selected) == set(targets), 'missing_prespecified_regions')
    return selected


def proposals(entry, text):
    response, error = parse_response(entry)
    require(error is None and list(response) == ['candidates'], 'invalid_region_reply')
    schema = entry['request']['response_format']['json_schema']['schema']['properties']['candidates']
    rows = response['candidates']
    require(isinstance(rows, list) and len(rows) < schema['maxItems'], 'region_reply_requires_split')
    types = schema['items']['properties']['kind']['enum']
    found, invalid = {}, 0
    for row in rows:
        value = row.get('value') if isinstance(row, dict) else None
        if (isinstance(value, str) and 3 <= len(value.encode()) <= 512 and value.strip() == value and value in text
                and row.get('kind') in types and row.get('scope') in ('personal', 'team', 'global')):
            found.setdefault(value, {'value': value, 'kind': 'CUSTOM'})
        else:
            invalid += 1
    return found, invalid


def timing(entry, reasoning_tokens):
    return {'seconds': entry['record']['http_wall_seconds'], 'reasoning_tokens': reasoning_tokens,
            'output_tokens': entry['raw_reply']['usage']['completion_tokens']}


def main():
    plan = strict_json((RUN / 'scheme-plan.json').read_text())
    source = strict_json((RUN / 'result.json').read_text())
    journal_path = RUN / 'transports.json'
    require(file_sha(journal_path) == source['transport_journal_sha256'], 'original_transport_hash_changed')
    journal = strict_json(journal_path.read_text())
    profile = plan['profile']
    require(journal['profile'] == profile and profile['reasoning_budget'] == 2048, 'unexpected_original_budget')
    require(file_sha(RUNTIME) == plan['expected_runtime_sha256'] == RUNTIME_SHA256, 'runtime_hash_changed')
    model_name, model_size, model_sha, _ = plan['model_artifact']
    model_path = DEFAULT_STUDY / 'models' / model_name
    require(model_path.stat().st_size == model_size and file_sha(model_path) == model_sha, 'model_hash_changed')
    suite = strict_json((DEFAULT_STUDY / 'status.json').read_text())
    require(file_sha(BINARY) == suite['binary_sha256'], 'mask_binary_hash_changed')
    _, expected, public, sources, _ = load_corpus()
    private = {name: [value for file, value in expected if file == name] for name in DOCUMENTS}
    require(all(hashlib.sha256(sources[name].encode()).hexdigest() == sha
                for name, sha in plan['source_sha256'].items()), 'corpus_hash_changed')
    choices = choose(journal, sources, private, public)
    OUTPUT.mkdir(parents=True, exist_ok=False)
    run = {'model': MODEL, 'runtime_sha256': RUNTIME_SHA256, 'model_sha256': model_sha,
           'before_budget': 2048, 'after_budget': 1024, 'threads': 2,
           'original_transport_sha256': file_sha(journal_path), 'status': 'running', 'cases': {}}
    after_profile = {**profile, 'reasoning_budget': 1024}
    comparison = {2048: {}, 1024: {}}
    excerpts, evidence = {}, {}
    atomic_json(OUTPUT / 'result.json', run)
    with SuiteLock(DEFAULT_STUDY / '.native-retest.lock'), research_registration(MODEL), \
            TemporaryDirectory(prefix='kaponir-budget-pilot-') as location:
        require(not runtime_processes(RUNTIME), 'runtime_busy')
        home = Path(location)
        worker = Worker(home, configuration(home, {'model_dir': str(DEFAULT_STUDY / 'models'),
            'runtime': str(RUNTIME), 'threads': 2, 'ocr_timeout_seconds': 1200}), 'unused')
        try:
            wait_for_verified_model(worker, MODEL, timeout=120)
            job = worker.submit('evaluate', model=MODEL)
            worker.start_runtime(job['id'], MODEL, 1, context_tokens=profile['context_tokens'],
                reasoning=profile['reasoning'], reasoning_format=profile['reasoning_format'], reasoning_budget=1024)
            require(worker.process_supports_json_schema is not False, 'unexpected_json_schema_mode')
            for name, (index, text, own, controls, original) in choices.items():
                old_items, old_invalid = proposals(original, text)
                request = original['request']
                require(digest(request) == original['request_sha256'], 'stored_request_digest_changed')
                rendered = http_json(worker.ocr_base + '/apply-template', {
                    'messages': request['messages'], 'chat_template_kwargs': request['chat_template_kwargs'],
                    'add_generation_prompt': True})['prompt']
                require(hashlib.sha256(rendered.encode()).hexdigest() == original['rendered_prompt_sha256'],
                        'replayed_template_changed')
                require(worker.count_text_tokens(rendered) == original['record']['input_tokens'], 'prompt_length_changed')
                entry = {'request': request, 'request_sha256': original['request_sha256'], 'status': 'pending'}
                evidence[name] = entry
                atomic_json(OUTPUT / 'transports.json', evidence)
                print(name, 'replaying request', index, flush=True)
                started = time.monotonic()
                entry['raw_transport'] = request_raw(worker.ocr_base + '/v1/chat/completions', request, timeout=180)
                entry.update(status='received', record={'http_wall_seconds': time.monotonic() - started})
                decode_transport(entry)
                atomic_json(OUTPUT / 'transports.json', evidence)
                new_items, new_invalid = proposals(entry, text)
                new_thought = check_thinking(entry['raw_reply'], after_profile, worker.count_text_tokens)
                excerpts[name] = text
                comparison[2048][name], comparison[1024][name] = list(old_items.values()), list(new_items.values())
                case = {'archived_request_index': index, 'private_targets': len(own), 'public_controls': len(controls)}
                for budget, record, items, invalid, thoughts in (
                        (2048, original, old_items, old_invalid, original['record']['reasoning_text_tokens']),
                        (1024, entry, new_items, new_invalid, new_thought)):
                    case[str(budget)] = {'private_found': len(own & items.keys()), 'public_found': len(controls & items.keys()),
                                         'invalid_proposals': invalid, **timing(record, thoughts)}
                run['cases'][name] = case
                atomic_json(OUTPUT / 'result.json', run)
        finally:
            worker.stop_runtime()
    require(not runtime_processes(RUNTIME), 'runtime_cleanup_missing')
    hashes = {name: hashlib.sha256(text.encode()).hexdigest() for name, text in excerpts.items()}
    for budget, masks in comparison.items():
        applied = apply_documents(BINARY, OUTPUT / f'apply-{budget}', hashes, excerpts, private, public, masks,
                                  {'model': MODEL, 'reasoning_budget': budget})
        docs = [doc for doc in applied['documents'] if doc['mode'] == 'model_masks_added']
        run.setdefault('api', {})[str(budget)] = {
            key: sum(doc[key] for doc in docs) for key in
            ('private_occurrence_spans', 'private_spans_fully_covered', 'public_occurrences_before', 'public_occurrences_lost')
        }
        run['api'][str(budget)]['exact_roundtrips'] = applied['exact_roundtrips']
    run.update(status='completed', new_measurement_requests=len(choices))
    atomic_json(OUTPUT / 'result.json', run)
    print('complete', len(choices), flush=True)


if __name__ == '__main__':
    main()
