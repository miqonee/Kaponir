"""Build chart presets from the checked Kaponir run and API receipts."""

from html import escape
import json
from math import ceil
from pathlib import Path

from native_retest_baselines import base_scheme_source
from render_kaponir_user_table import ABCD_MEDIAN_MINUTES, BASELINE, reference_edits, score, search_minutes
from report_native_model_retest import DEFAULT_STUDY, build
from run_tiny_aya_context_supplement import SUPPLEMENT
from summarize_privacy_policy import load_run


WORK = Path(__file__).resolve().parent
FRAGMENT = WORK / 'kaponir-retest.html'
RESULTS = DEFAULT_STUDY
BEFORE = 'Исходный профиль'
AFTER = 'По рекомендациям'
WITHOUT = 'До нормализации'
WITH = 'С нормализацией'

MODELS = {
    'gemma4-e4b-qat': 'Gemma E4B QAT',
    'gemma4-e4b-it-q4km': 'Gemma E4B Q4_K_M',
    'lfm2.5-1.2b-instruct': 'LFM 2.5 1.2B',
    'lfm2.5-2.6b': 'LFM 2.5 2.6B',
    'lfm2.5-8b-a1b': 'LFM 2.5 8B-A1B',
    'qwen3.5-4b': 'Qwen3.5-4B',
    'spark-x2.6-4b': 'Spark X2.6 4B',
    'tiny-aya-global': 'Tiny Aya Global',
}
SCHEMES = {
    'current_union': 'Добавляющий поиск',
    'regions': 'Перепоиск записей',
    'point': 'Проверка списка',
    'union_point': 'Проверка объединения',
    'double': 'Два прохода',
    'detector_proposals': 'Детекторы',
}
METRICS = {
    'covered': ('Полностью скрыто', 'Приватных вхождений из 193', 193, 0),
    'loss': ('Публичные потери', 'Потерь из 87 публичных контролей', 20, 0),
    'search_time': ('Время HTTP', 'Минуты добавляющего поиска', 35, 2),
    'search_score': ('Балл поиска', 'Баллы из 100', 100, 2),
    'technical': ('Непригодные решения', 'Число непригодных решений', 120, 0),
    'abcd_score': ('Балл A–D', 'Баллы из 100', 100, 1),
    'mask': ('Верные MASK', 'Приватных целей из 16', 16, 0),
    'keep': ('Верные KEEP', 'Публичных целей из 16', 16, 0),
    'abcd_time': ('Время HTTP', 'Минуты выбранного варианта A–D', None, 2),
}


def chart(scenario, metric, title, description, measures, rows, *, maximum=None):
    label, axis, domain, digits = METRICS[metric]
    bound = domain if maximum is None else maximum
    assert bound and all(0 <= value <= bound for row in rows for value in row[1:] if value is not None)
    assert len({row[0] for row in rows}) == len(rows)
    return scenario, metric, label, {
        'id': 'kaponir-retest-results', 'title': f'{title} · {label}',
        'description': description, 'showHeader': False,
        'summary': f'{title}. {axis}. {description}',
        'height': 370 if len(rows) == 8 else 246,
        'spec': {
            'type': 'horizontalBar',
            'x': measures if len(measures) > 1 else measures[0],
            'y': 'Модель', 'xLabel': axis, 'xDomain': [0, bound],
            'showValues': True, 'showLegend': len(measures) > 1,
            'valueFormat': {'style': 'decimal', 'maximumFractionDigits': digits},
        },
        'columns': ['Модель', *measures],
        'rows': rows,
    }


def search_data(runs):
    archived_table = {r[0]: r for r in BASELINE}
    by_model = {}
    for model, run in runs.items():
        scheme = run['schemes']['current_union']
        assert scheme['native']['applied'] and not run['discovery_snapshot']
        native = scheme['native']
        minutes = search_minutes(RESULTS / 'schemes' / model / 'result.json')
        new_score = score(minutes, native['private_full'], native['public_control_losses'], reference_edits(native))
        old_minutes = old_score = None
        if scheme['paired']:
            path, archived = base_scheme_source(RESULTS, model)
            old_minutes = search_minutes(path, archived)
            base = scheme['base']
            old_score = score(old_minutes, base['private_full'], base['public_control_losses'], reference_edits(base))
            assert round(old_minutes, 2) == archived_table[model][3]
            assert round(old_score, 2) == archived_table[model][2]
        by_model[model] = {
            'search_time': [minutes, old_minutes], 'search_score': [new_score, old_score],
        }
    assert sum(row['search_time'][1] is not None for row in by_model.values()) == 5
    return by_model


def scheme_presets(runs):
    search = search_data(runs)
    related = {'covered': 'private_full', 'loss': 'public_control_losses', 'technical': 'technical_review'}
    description = 'Три документа. Исходные столбцы показаны для пяти моделей с сопоставимыми замерами.'
    presets = []
    for method, label in SCHEMES.items():
        metrics = ['covered', 'loss']
        if method == 'current_union':
            metrics += ['search_time', 'search_score']
        elif method != 'detector_proposals':
            metrics.append('technical')
        for metric in metrics:
            rows = []
            for model, name in MODELS.items():
                scheme = runs[model]['schemes'][method]
                native = scheme['native']
                assert native['applied'] and sum(native[key] for key in
                    ('private_full', 'private_partial', 'private_untouched')) == 193
                if metric in related:
                    key = related[metric]
                    base = scheme['base'][key] if scheme['paired'] else None
                    values = [native[key], base]
                else:
                    values = search[model][metric]
                rows.append([name, *values])
            note = description
            if metric == 'search_time':
                note += ' Сумма времени HTTP-запросов этой схемы.'
            elif metric == 'search_score':
                note += ' Балл учитывает покрытие, потери и время.'
            presets.append(chart(method, metric, label, note, [AFTER, BEFORE], rows))
    return presets


def abcd_presets(runs):
    data = {}
    for model, run in runs.items():
        root = RESULTS / SUPPLEMENT if run['context_supplement'] else RESULTS
        original = load_run(root / 'abcd' / model)
        assert original['run_status'] == 'completed'
        assert original['result_sha256'] == run['abcd_status']['result_sha256']
        data[model] = {}
        for row in original['rows']:
            variant = row['variant']
            assert row['protocol_complete'] and row['outcome_evidence']['all_generation_outcomes_observed']
            elapsed = row['performance']['http_wall_seconds_including_retries'] / 60
            m, k = (row['quality'][name] for name in ('private_mask', 'public_keep'))
            application = run['abcd'][variant]['native']['application']
            assert application['exact_roundtrips'] == 6
            data[model][variant] = {
                'abcd_score': 50 * m / 16 + 20 * k / 16 + 30 * ABCD_MEDIAN_MINUTES / (ABCD_MEDIAN_MINUTES + elapsed),
                'mask': m, 'keep': k, 'abcd_time': elapsed,
                'covered': application['private_spans_fully_covered'],
                'loss': application['public_occurrences_lost'],
            }
    best = {model: max(variants, key=lambda key: variants[key]['abcd_score']) for model, variants in data.items()}
    assert best['gemma4-e4b-it-q4km'] == 'D' and best['qwen3.5-4b'] == 'C'
    assert data['gemma4-e4b-it-q4km']['D']['mask'] == data['gemma4-e4b-it-q4km']['D']['keep'] == 16
    assert all(details['mask'] == 0 for details in data['tiny-aya-global'].values())
    maximum_time = 10 * ceil(max(row['abcd_time'] for values in data.values() for row in values.values()) / 10)
    presets = []
    for variant in ('best', 'A', 'B', 'C', 'D'):
        label = 'A–D · лучший вариант по баллу' if variant == 'best' else f'Вариант {variant}'
        note = 'Повторный прогон. В каждом варианте 16 приватных и 16 публичных целей.'
        model_order = list(MODELS)
        if variant == 'best':
            model_order.sort(key=lambda model: -data[model][best[model]]['abcd_score'])
        for metric in ('abcd_score', 'mask', 'keep', 'covered', 'loss', 'abcd_time'):
            rows = []
            for model in model_order:
                name = MODELS[model]
                chosen = best[model] if variant == 'best' else variant
                label_for_model = f'{name} · {chosen}' if variant == 'best' else name
                rows.append([label_for_model, data[model][chosen][metric]])
            presets.append(chart(variant, metric, label, note, [AFTER], rows,
                                 maximum=maximum_time if metric == 'abcd_time' else None))
    return presets


def validator_presets():
    runs = json.loads((WORK / 'kaponir-normalization-api-check.json').read_text())
    assert len(runs) == 4 and all(run['variant'] == 'B' for run in runs)
    assert sum(run['additional_masks'] for run in runs) == 6
    assert sum(run['diagnostic'][0] - run['measured'][0] for run in runs) == 7
    assert all(run['diagnostic'][3] == run['measured'][3] for run in runs)
    note = 'Четыре прогона B с восстановленными MASK. Повторное применение масок через API.'
    return [chart('validator', metric, 'Нормализация цитат в B', note, [WITH, WITHOUT],
                  [[MODELS[run['model']], run['diagnostic'][index], run['measured'][index]] for run in runs])
            for metric, index in [('covered', 0), ('loss', 3)]]


def profile_rows(runs):
    items = []
    for key, name in MODELS.items():
        row = runs[key]
        settings = row['profile']['settings']
        sampling = ' / '.join(str(settings[key]) for key in ('temperature', 'top_p', 'top_k'))
        budget = settings['reasoning_budget']
        effort = settings['template_kwargs'].get('reasoning_effort')
        mode = f'{effort or "thinking"} {budget}' if budget > 0 else 'без рассуждений'
        penalties = [f'{key}={value}' for key, value in settings['extra_sampling'].items()]
        details = [*penalties, mode]
        if row['context_supplement']:
            output = row['context_supplement']['provenance']['output_tokens']
            details.append(f'окно {settings["context_tokens"]}, выход A–D {output}')
        items.append(f'      <div><dt>{escape(name)}</dt><dd><code>{escape(sampling)}</code> · '
                     f'{escape(" · ".join(details))}</dd></div>')
    return '\n'.join(items)


def insert(text, start, end, value):
    left, tail = text.split(start, 1)
    _, right = tail.split(end, 1)
    return left + start + '\n' + value + '\n  ' + end + right


def main():
    runs = {row['model']: row for row in build(RESULTS)}
    assert set(runs) == set(MODELS)
    presets = scheme_presets(runs) + abcd_presets(runs) + validator_presets()
    blocks = []
    for scenario, metric, label, config in presets:
        data = json.dumps(config, ensure_ascii=False, separators=(',', ':')).replace('<', r'\u003c')
        blocks.append(f'  <script type="application/json" data-viz-chart data-scenario="{scenario}" '
                      f'data-metric="{metric}" data-label="{escape(label, quote=True)}">{data}</script>')
    text = FRAGMENT.read_text(encoding='utf-8')
    text = insert(text, '<!-- PROFILE_ROWS_START -->', '<!-- PROFILE_ROWS_END -->', profile_rows(runs))
    text = insert(text, '<!-- CHART_CONFIGS_START -->', '<!-- CHART_CONFIGS_END -->', '\n'.join(blocks))
    FRAGMENT.write_text(text, encoding='utf-8')
    print(f'{len(presets)} presets, {len(text.encode())} bytes')


if __name__ == '__main__':
    main()
