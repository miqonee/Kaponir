"""Compare one additional reasoning limit for each of the larger LFM models."""

import argparse
import os
from pathlib import Path
import runpy
import subprocess
import sys

from native_model_profiles import catalog_for
from privacy_expansion_profiles import research_registration
from run_privacy_policy_suite import SuiteLock, atomic_json, file_sha, runtime_processes
from summarize_privacy_policy import require


HERE = Path(__file__).resolve().parent
tuning = runpy.run_path(str(HERE / 'check-kaponir-lfm-tuning.py'))
matrix, read = tuning['matrix'], tuning['read']
SOURCE_PLAN = tuning['OUTPUT'] / 'plan.json'
OUTPUT = tuning['PILOT'] / 'lfm-budget-followup'
BUDGETS = {tuning['LFM26']: 384, tuning['LFM8B']: 768}
RUNTIME = tuning['RUNTIME']


def measure(model, cpus):
    os.sched_setaffinity(0, cpus)
    plan = read(SOURCE_PLAN)
    trial = read(OUTPUT / 'plan.json')
    profile = trial['profiles'][model]
    name, size, sha, _ = plan['profiles'][model]['artifact']
    weights = tuning['ROOT'] / 'models' / name
    require(weights.stat().st_size == size and file_sha(weights) == sha, 'tuning_weights_changed')
    label = f'budget-{profile["reasoning_budget"]}'
    folder = OUTPUT / model
    with research_registration(model, catalog_for(model)):
        evidence = matrix['measure'](model, label, {'settings': profile},
                                     plan['fixture'], folder / label)
    archive = read(tuning['MATRIX'] / model / 'recommended/transports.json')
    current = read(folder / label / 'transports.json')
    require(len(archive['requests']) == len(current['requests']) == 2
            and current['profile']['reasoning_budget'] == BUDGETS[model], 'missing_tuning_comparison')
    for before, after in zip(archive['requests'], current['requests'], strict=True):
        require(before['request'] == after['request']
                and before['rendered_prompt_sha256'] == after['rendered_prompt_sha256'],
                'budget_probe_changed_request')
    require(all(row['ok'] for row in evidence.values()), 'budget_probe_incomplete')
    result = tuning['apply_variant'](model, label, plan, evidence, folder)
    atomic_json(folder / 'result.json', {'budget': BUDGETS[model], **result})
    print(model, 'budget', BUDGETS[model], 'application checked', flush=True)


def run():
    plan = read(SOURCE_PLAN)
    require(not OUTPUT.exists() and file_sha(RUNTIME) == plan['fixture']['runtime_sha256']
            and file_sha(tuning['BINARY']) == plan['fixture']['binary_sha256'], 'changed_followup_inputs')
    profiles = {model: {**plan['profiles'][model]['baseline'], 'reasoning_budget': budget}
                for model, budget in BUDGETS.items()}
    with SuiteLock(tuning['ROOT'] / '.native-retest.lock'):
        require(not runtime_processes(RUNTIME), 'runtime_already_running')
        atomic_json(OUTPUT / 'plan.json', {'original_plan_sha256': file_sha(SOURCE_PLAN),
            'script_sha256': file_sha(Path(__file__)), 'profiles': profiles, 'budgets': BUDGETS})
        launch = [subprocess.Popen([sys.executable, '-Bu', __file__, '--model', model,
                                    '--cpus', ','.join(map(str, cpus))])
                  for model, cpus in zip(BUDGETS, plan['cpu_affinities'], strict=True)]
        codes = [process.wait() for process in launch]
        require(not runtime_processes(RUNTIME), 'runtime_not_cleaned_up')
    results = {m: read(OUTPUT / m / 'result.json') for m in BUDGETS if (OUTPUT / m / 'result.json').is_file()}
    atomic_json(OUTPUT / 'summary.json', {'model_exit_codes': dict(zip(BUDGETS, codes, strict=True)), 'models': results})
    print('budget followup checked', len(results), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--model')
    parser.add_argument('--cpus')
    args = parser.parse_args()
    if args.model:
        measure(args.model, [int(cpu) for cpu in args.cpus.split(',')])
    else:
        run()
