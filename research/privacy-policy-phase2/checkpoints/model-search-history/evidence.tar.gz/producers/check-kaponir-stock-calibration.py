"""Paired short Kaponir calibration on the frozen privacy-search pilot."""

from argparse import ArgumentParser, Namespace
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
from tempfile import TemporaryDirectory
import time

from evaluate_model_schemes import scheme_profile
from evaluate_validation_schemes import detector_pool_from_export
from experiment_inference import discover, prompts_and_kinds
from kaponir_worker import FILES, Worker, configuration
from privacy_expansion_profiles import GEMMA_IT_CATALOG, research_registration
from run_privacy_policy_suite import SuiteLock, atomic_json, file_sha, runtime_processes
from summarize_privacy_policy import require


HERE = Path(__file__).resolve().parent
MATRIX_SCRIPT = HERE / 'check-kaponir-fresh-matrix.py'
LFM_SCRIPT = HERE / 'check-kaponir-lfm-same-search-tuning.py'
matrix, lfm = (runpy.run_path(str(p)) for p in (MATRIX_SCRIPT, LFM_SCRIPT))
read, root, runtime = (matrix[k] for k in ('read', 'ROOT', 'RUNTIME'))
senior, large, log = (lfm[k] for k in ('senior', 'large', 'LOG'))
output = matrix['PILOT'] / 'stock-calibration-v1'
granite, qwen, e2b, qat = 'granite42-3b', 'qwen3.5-4b', 'gemma4-e2b-it-q4km', 'gemma4-e4b-qat'
LFM26, LFM8 = (senior[k] for k in ('LFM26', 'LFM8'))
LFM_FOLLOWUPS = ('lfm26-log-ids', 'lfm8-budget-768')
CHOICES = {
    granite: ('template_kwargs', 'enable_thinking', False),
    qwen: ('extra_sampling', 'presence_penalty', 0.0),
    e2b: ('temperature', None, 0.25),
    qat: ('template_kwargs', 'enable_thinking', False),
}
REQUEST_FIELD = {'extra_sampling': 'presence_penalty', 'template_kwargs': 'chat_template_kwargs',
                 'temperature': 'temperature'}


def catalog(model):
    return GEMMA_IT_CATALOG if model == e2b else matrix['catalog_for'](model)


def four_profiles(old_plan):
    stock = {m: old_plan['profiles'][m]['recommended'] for m in (qwen, qat)}
    for model in (granite, e2b):
        settings = scheme_profile(model, 'native', catalog(model))
        settings.update(max_candidates=24, template_kwargs={'enable_thinking': model == granite})
        with research_registration(model, catalog(model)):
            stock[model] = {'artifact': FILES[model], 'settings': settings}
    profiles = {}
    for model, baseline in stock.items():
        candidate = deepcopy(baseline)
        candidate.pop('recorded_request', None)
        field, nested, value = CHOICES[model]
        old_value = baseline['settings'][field] if nested is None else baseline['settings'][field][nested]
        require(old_value != value, 'no_parameter_change')
        if nested is None:
            candidate['settings'][field] = value
        else:
            candidate['settings'][field][nested] = value
        profiles[model] = {'stock': baseline, 'candidate': candidate,
                           'changed': REQUEST_FIELD[field], 'from': old_value, 'to': value}
    return profiles


def short_test(model, folder, plan):
    spec = plan['profiles'][model]
    filename, size, sha, _ = spec['stock']['artifact']
    weights = root / 'models' / filename
    require(weights.stat().st_size == size and file_sha(weights) == sha, 'weight_verification_failed')
    folder.mkdir()
    fixture = plan['fixture']
    historic = plan['reuse_stock'].get(model)
    sources = {}
    evidence = {}
    with research_registration(model, catalog(model)):
        for variant in ('stock', 'candidate'):
            previous = Path(historic['directory']) if historic and variant == 'stock' else None
            if previous:
                result_path = previous / 'result.json'
                require(file_sha(result_path) == historic['result_sha256'], 'archived_stock_changed')
                evidence[variant] = read(result_path)['measurements']['recommended']
                sources[variant] = previous / 'recommended' / 'transports.json'
                require(file_sha(sources[variant]) == historic['transport_sha256'], 'stock_transport_changed')
            else:
                evidence[variant] = matrix['measure'](model, variant, spec[variant], fixture, folder / variant)
                sources[variant] = folder / variant / 'transports.json'
    journals = {label: read(path) for label, path in sources.items()}
    requests = {label: {row['record']['measurement_stage']: row for row in journal['requests']}
                for label, journal in journals.items()}
    for name in fixture['sources']:
        stage = f'discovery:{name}'
        before, after = (requests[l][stage] for l in ('stock', 'candidate'))
        stock_request, changed_request = (row['request'] for row in (before, after))
        require(set(stock_request) == set(changed_request), 'transport_shape_changed')
        diffs = {key for key in stock_request if stock_request[key] != changed_request[key]}
        require(diffs == {spec['changed']}, 'request_differs_beyond_one_parameter')
        require(json.loads(stock_request['messages'][-1]['content'])['source'] == fixture['sources'][name],
                'paired_document_changed')
        same_render = before['rendered_prompt_sha256'] == after['rendered_prompt_sha256']
        require(same_render == (spec['changed'] != 'chat_template_kwargs'), 'template_changes_unexpectedly')
    require({k for k in journals['stock']['profile']
             if journals['stock']['profile'][k] != journals['candidate']['profile'][k]}
            == {CHOICES[model][0]}, 'runtime_profile_changed')
    fresh = runpy.run_path(str(matrix['PREVIOUS_SCRIPT']))
    pool, _ = detector_pool_from_export(read(matrix['PREVIOUS'] / 'detectors.json'), fixture['sources'])
    scoring_fixture = {**fixture, 'route': {}}
    applications = matrix['apply'](model, scoring_fixture, folder, evidence, pool, fresh['select_search_masks'])
    applications.pop('hybrid')
    report = {'model': model, 'stock_evidence_reused': bool(historic), 'settings_difference': spec['changed'],
              'old': spec['from'], 'new': spec['to'], 'measurements': evidence, 'applications': applications}
    atomic_json(folder / 'result.json', report)
    print(model, 'compared', flush=True)


def lfm_test(job, folder, plan):
    spec = plan['lfm'][job]
    model = spec['model']
    source, private, public, pool = large['corpus']()
    base = large['originals'](model, source, plan['binary_sha256'])
    profile = lfm['settings_from'](base['profile'], spec['generation'])
    filename, size, sha, _ = base['artifact']
    weights = root / 'models' / filename
    require(weights.stat().st_size == size and file_sha(weights) == sha, 'weight_verification_failed')
    journal_path = Path(spec['reference'])
    require(file_sha(journal_path) == spec['reference_sha256'], 'archived_lfm_transport_changed')
    entries = read(journal_path)['requests']
    fragments = [json.loads(entry['request']['messages'][-1]['content']) for entry in entries]
    require(fragments == plan['lfm_fragments'], 'lfm_fragments_differ')
    require(''.join(fragment['source'] for fragment in fragments) == source[log], 'lfm_input_differ')
    source_sha = hashlib.sha256(source[log].encode()).hexdigest()
    require(source_sha == plan['lfm_source_sha256'], 'lfm_source_differ')
    _, _, kinds = prompts_and_kinds()
    folder.mkdir()
    save_search = folder / 'search'
    save_search.mkdir()
    results, history, cancelled = {}, [], False

    def apply(name, measure):
        return large['apply_stage'](model, name, {log: senior['sum_fragments'](measure)},
                                    {log: source[log]}, private, public,
                                    [row for row in pool if row.file == log], {log: source_sha}, folder / name)

    with research_registration(model, catalog(model)), TemporaryDirectory(prefix='kaponir-lfm-stock-') as temp:
        home = Path(temp)
        worker = Worker(home, configuration(home, {'model_dir': str(root / 'models'), 'runtime': str(runtime),
            'threads': 2, 'ocr_timeout_seconds': profile['worker_configuration_timeout_seconds']}), 'unused')
        try:
            sampling = {k: profile[k] for k in ('temperature', 'top_p', 'top_k', 'min_p', 'seed')}
            client = senior['SameFragmentClient'](worker, model, profile['context_tokens'], profile['output_tokens'],
                profile['response_format'], sampling, profile, save_search, history)
            for i, (fragment, baseline) in enumerate(zip(fragments, entries, strict=True), 1):
                client.fragment_context = fragment['context']
                client.measurement_stage = baseline['record']['measurement_stage']
                args = Namespace(**profile, candidate_mode='typed', strategy='fixed', target_input_tokens=0,
                                 fixed_bytes=len(fragment['source'].encode()), fixed_overlap_bytes=0)
                print(job, 'fragment', i, 'running', flush=True)
                found = discover(client, fragment['source'], spec['prompt'], kinds, args, client.save_history)
                require(len(history) == i and not found['errors'], 'lfm_fragment_incomplete')
                row = history[-1]
                expected = deepcopy(baseline['request'])
                expected['messages'][0]['content'] = spec['prompt']
                require(row['request'] == expected and row['record']['finish_reason'] == 'stop', 'lfm_request_differ')
                if spec['generation']:
                    require(baseline['rendered_prompt_sha256'] == row['rendered_prompt_sha256'], 'lfm_prompt_differ')
                r = row['record']
                results[str(i)] = {**found, 'requests': 1, 'http_seconds': r['http_wall_seconds'],
                    'reasoning_tokens': [r['reasoning_text_tokens']], 'output_tokens': [r['usage']['completion_tokens']],
                    'raw_candidates': r['candidate_count']}
                atomic_json(folder / 'fragments.json', results)
                print(job, 'fragment', i, 'done', len(found['values']), r['reasoning_text_tokens'],
                      round(r['http_wall_seconds'], 2), flush=True)
                if i == 1 and spec['first_fragment_gate']:
                    preview = apply('first-fragment', results)
                    atomic_json(folder / 'first-fragment.json', preview)
                    if preview['application'][log]['public_occurrences_lost']:
                        cancelled = True
                        break
        finally:
            worker.stop_runtime()
    require(cancelled or len(results) == len(entries), 'incomplete_lfm_comparison')
    applied = apply('checked', results)
    atomic_json(folder / 'result.json', {**applied, 'complete': not cancelled, 'fragments': results})
    row = applied['application'][log]
    print(job, 'checked', len(results), row['private_spans_fully_covered'], row['public_occurrences_lost'], flush=True)


def make_plan():
    old = matrix['OUTPUT']
    old_plan = read(old / 'plan.json')
    fixture = read(matrix['PREVIOUS'] / 'plan.json')
    require(fixture == old_plan['fixture'] and file_sha(runtime) == matrix['RUNTIME_SHA256'], 'fixture_or_runtime_differ')
    require(fixture['script_sha256'] == file_sha(matrix['PREVIOUS_SCRIPT']), 'fixture_producer_changed')
    require(all(hashlib.sha256(text.encode()).hexdigest() == fixture['source_sha256'][name]
                for name, text in fixture['sources'].items()), 'corpus_hashes_differ')
    reuse = {}
    for model in (qwen, qat):
        directory = old / model
        reuse[model] = {'directory': str(directory), 'result_sha256': file_sha(directory / 'result.json'),
                       'transport_sha256': file_sha(directory / 'recommended' / 'transports.json')}
    prior = read(lfm['WORK'] / 'prompt-only' / 'plan.json')
    prompt = prior['prompt']
    refined = prompt.replace('Leave public HTTP methods and statuses,',
        'Preserve routine per-request, retry, trace, and span correlation IDs used only to follow a diagnostic '
        'operation. Mask private customer, account, order, or business IDs even when they appear in diagnostics. '
        'Decide by the ID’s role in the record. Leave public HTTP methods and statuses,')
    require(refined != prompt and prior['overrides'] == {}, 'instruction_producer_changed')
    references = {LFM26: lfm['journals'](LFM26),
                  LFM8: lfm['WORK'] / 'prompt-only' / LFM8 / 'transports.json'}
    lfm_profiles = {LFM_FOLLOWUPS[0]: {'model': LFM26, 'prompt': refined, 'first_fragment_gate': True, 'generation': {}},
                    LFM_FOLLOWUPS[1]: {'model': LFM8, 'prompt': prompt, 'first_fragment_gate': False,
                                       'generation': {'reasoning_budget': 768}}}
    for spec in lfm_profiles.values():
        path = references[spec['model']]
        spec.update(reference=str(path), reference_sha256=file_sha(path))
    binary_sha = file_sha(matrix['BINARY'])
    require(prior['binary_sha256'] == binary_sha, 'mask_binary_changed')
    return {'fixture': fixture, 'profiles': four_profiles(old_plan), 'reuse_stock': reuse, 'lfm': lfm_profiles,
            'lfm_source_sha256': prior['source_sha256'], 'lfm_fragments': prior['fragments'],
            'runtime_sha256': matrix['RUNTIME_SHA256'], 'binary_sha256': binary_sha,
            'script_sha256': file_sha(Path(__file__)), 'detector_sha256': file_sha(matrix['PREVIOUS'] / 'detectors.json'),
            'producer_sha256': {p.name: file_sha(p) for p in (MATRIX_SCRIPT, LFM_SCRIPT)}}


def suite(jobs):
    cpu = sorted(os.sched_getaffinity(0))
    slots = (cpu[:2], cpu[2:4])
    require(len(cpu) >= 4 and not output.exists(), 'calibration_resources_unavailable')
    queues = [[j for j in jobs if j in (qwen, granite, e2b)],
              [j for j in jobs if j in (qat, *LFM_FOLLOWUPS)]]
    with SuiteLock(root / '.native-retest.lock'):
        require(not runtime_processes(runtime), 'runtime_busy')
        atomic_json(output / 'plan.json', make_plan())
        running, exit_codes = {}, {}
        while any(queues) or running:
            for slot, (job, process) in tuple(running.items()):
                code = process.poll()
                if code is not None:
                    exit_codes[job] = code
                    del running[slot]
            for slot, queue in enumerate(queues):
                if queue and slot not in running:
                    job = queue.pop(0)
                    command = [sys.executable, '-Bu', __file__, '--job', job, '--cpus', ','.join(map(str, slots[slot]))]
                    running[slot] = job, subprocess.Popen(command)
            if running:
                time.sleep(0.5)
        require(not runtime_processes(runtime), 'runtime_not_cleaned_up')
    results = {job: read(output / job / 'result.json') for job in jobs if (output / job / 'result.json').is_file()}
    atomic_json(output / 'summary.json', {'results': results, 'exit_codes': exit_codes})
    print('Calibration completed', exit_codes, flush=True)


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('--job')
    parser.add_argument('--cpus')
    parser.add_argument('--jobs', nargs='+', default=(qwen, granite, e2b, LFM_FOLLOWUPS[0], qat, LFM_FOLLOWUPS[1]))
    args = parser.parse_args()
    if args.job is None:
        suite(args.jobs)
    else:
        os.sched_setaffinity(0, [int(v) for v in args.cpus.split(',')])
        plan = read(output / 'plan.json')
        folder = output / args.job
        if args.job in CHOICES:
            short_test(args.job, folder, plan)
        else:
            lfm_test(args.job, folder, plan)
