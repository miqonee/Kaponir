"""Check whether Spark's recommended sampler returns a short log mask with reasoning off."""

from pathlib import Path
import runpy

from apply_measured_privacy import apply_documents
from evaluate_validation_schemes import detector_pool_from_export
from privacy_expansion_profiles import research_registration
from run_privacy_policy_suite import SuiteLock, atomic_json, file_sha, runtime_processes
from summarize_privacy_policy import require


here = Path(__file__).resolve().parent
runner = runpy.run_path(str(here / 'check-kaponir-fresh-matrix.py'))
load = runner['read']
matrix = runner['OUTPUT']
plan = load(matrix / 'plan.json')
fixture = plan['fixture']
model = 'spark-x2.6-4b'
log = next(name for name, label in fixture['route'].items() if label == 'original')
profile = plan['profiles'][model]['recommended']['settings']
off = {**profile, 'reasoning': 'off', 'reasoning_budget': -1,
       'thinking_mode': 'native_no_thinking', 'template_kwargs': {'enable_thinking': False}}
folder = runner['PILOT'] / 'spark-off-log'
binary = runner['BINARY']
runtime = runner['RUNTIME']
weights, size, checksum, _ = plan['profiles'][model]['recommended']['artifact']
model_path = runner['ROOT'] / 'models' / weights
require(file_sha(binary) == fixture['binary_sha256'] and file_sha(runtime) == fixture['runtime_sha256']
        and model_path.stat().st_size == size and file_sha(model_path) == checksum,
        'spark_off_artifact_changed')
require(not folder.exists(), 'existing_spark_off_probe')
source_only = {log: fixture['sources'][log]}
with SuiteLock(runner['ROOT'] / '.native-retest.lock'), research_registration(model):
    require(not runtime_processes(runtime), 'spark_off_runtime_busy')
    atomic_json(folder / 'plan.json', {'model': model, 'document': log,
        'source_sha256': fixture['source_sha256'][log], 'settings': off,
        'reference_plan_sha256': file_sha(matrix / 'plan.json')})
    measured = runner['measure'](model, 'recommended-off', {'settings': off},
                                 {**fixture, 'sources': source_only}, folder / 'off')
    require(not runtime_processes(runtime), 'spark_off_runtime_cleanup_failed')
measurement = measured[log]
before = load(matrix / model / 'recommended' / 'transports.json')['requests'][0]['request']
after = load(folder / 'off/transports.json')['requests'][0]['request']
require({key: value for key, value in before.items() if key != 'chat_template_kwargs'}
        == {key: value for key, value in after.items() if key != 'chat_template_kwargs'},
        'spark_off_request_changed_except_reasoning')
result = {'model': model, 'measurement': measurement}
if measurement['ok']:
    pool, _ = detector_pool_from_export(load(runner['PREVIOUS'] / 'detectors.json'), fixture['sources'])
    select = runpy.run_path(str(runner['PREVIOUS_SCRIPT']))['select_search_masks']
    masks = select(pool, measured)
    application = apply_documents(binary, folder / 'apply', {log: fixture['source_sha256'][log]},
        source_only, fixture['private_values'], fixture['public_values'], masks,
        {'model': model, 'variant': 'recommended-off'})
    result['application'] = next(row for row in application['documents'] if row['mode'] == 'model_masks_added')
    result['exact_roundtrips'] = application['exact_roundtrips']
atomic_json(folder / 'result.json', result)
print('Spark off', measurement['ok'], round(measurement['http_seconds'] or 0, 2), flush=True)
