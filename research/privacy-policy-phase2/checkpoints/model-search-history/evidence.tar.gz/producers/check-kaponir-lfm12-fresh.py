"""Compare two LFM1.2B profiles on new synthetic documents, using Kaponir's adding search."""

from argparse import Namespace
import hashlib
import json
from pathlib import Path
from tempfile import TemporaryDirectory

from apply_measured_privacy import apply_documents, span_coverage
from apply_scheme_masks import select_masks
from check_learning_corpus import load_corpus, occurrences
from evaluate_model_schemes import MeasuredClient
from evaluate_privacy_policy import RUNTIME_SHA256
from evaluate_validation_schemes import detector_pool
from experiment_inference import discover, extraction_schema, prompts_and_kinds
from kaponir_worker import Worker, configuration
from native_retest_baselines import base_scheme_source
from privacy_expansion_profiles import research_registration
from run_native_model_retest import DEFAULT_STUDY
from run_privacy_policy_suite import SuiteLock, atomic_json, file_sha, runtime_processes
from summarize_privacy_policy import digest, require, strict_json
from validation_pipeline import Candidate, opaque_id


MODEL = 'lfm2.5-1.2b-instruct'
ROOT = DEFAULT_STUDY
WORK = Path(__file__).parent / 'kaponir-hybrid-pilot' / 'fresh-lfm12'
RUNTIME = ROOT / 'runtime/llama-b12038/llama-server'
BINARY = ROOT / 'build/release/kaponir'
DETECTORS = ROOT / 'build/release/examples/detector_candidates'
LOG = 'delivery-retry.log'
PUBLIC = 'open-visitor-reference.md'
SOURCES = {
    LOG: '''2026-11-20T03:14:07Z INFO PostgreSQL health=ok telemetry=OpenTelemetry
2026-11-20T03:14:08Z INFO delivery customer="Берестяной Кварц" project="Тихий Меридиан" case=INC-RIL-74216
2026-11-20T03:14:09Z INFO operator="Лина Ветроградова" account=lv_ops7 contact=lina.42@cedar-inbox.example
2026-11-20T03:14:12Z WARN upstream=ops-mes-17.svc.lab.test service=amber-shuttle response="HTTP 503" reference="RFC 9110"
2026-11-20T03:14:16Z INFO spool=/var/lib/dispatch/fogcache/retry.ndjson payload_encoding=UTF-8
2026-11-20T03:14:18Z INFO note="Для Лины Ветроградовой открыт повтор по Тихому Меридиану" owner=lv_ops7
2026-11-20T03:14:21Z INFO project="Тихий Меридиан" customer="Берестяной Кварц" result="HTTP 202"
''',
    PUBLIC: '''# Открытая справка для посетителей

Эти сведения организатор публикует на афише и сайте. Их можно распространять.

Организатор — АНО «Линия Листопада». Дата встречи — 24 ноября 2026 года.
Открытая площадка — зал «Маяк», время работы с 10:00 до 18:00.
Официальный сайт — https://leafline-events.example.
Публичная почта для обращений — hello@leafline-events.example.
Билет для посетителей — 850,00 ₽, правила возврата доступны всем.

Техническая справка. Вместо заявки можно открыть афишу в PDF, а сайт использует HTTPS.
''',
}
PRIVATE_VALUES = {
    LOG: ['Берестяной Кварц', 'Тихий Меридиан', 'INC-RIL-74216',
          'Лина Ветроградова', 'lv_ops7', 'lina.42@cedar-inbox.example',
          'ops-mes-17.svc.lab.test', 'amber-shuttle', '/var/lib/dispatch/fogcache/retry.ndjson',
          'Лины Ветроградовой', 'Тихому Меридиану'],
    PUBLIC: [],
}
PUBLIC_VALUES = {
    LOG: ['PostgreSQL', 'OpenTelemetry', 'HTTP', 'RFC 9110', 'UTF-8'],
    PUBLIC: ['АНО «Линия Листопада»', '24 ноября 2026 года', 'зал «Маяк»',
             '10:00', '18:00', 'https://leafline-events.example', 'hello@leafline-events.example',
             '850,00 ₽', 'PDF', 'HTTPS'],
}
ROUTE = {LOG: 'original', PUBLIC: 'recommended'}


def load_references():
    original, archived = base_scheme_source(ROOT, MODEL)
    require(not archived, 'expected_restored_original_profile')
    reference_paths = {'original': original, 'recommended': ROOT / 'schemes' / MODEL / 'result.json'}
    prompt, _, kinds = prompts_and_kinds()
    sources = {}
    for label, path in reference_paths.items():
        plan_path = path.with_name('scheme-plan.json')
        journal_path = path.with_name('transports.json')
        plan, state, journal = [strict_json(p.read_text()) for p in (plan_path, path, journal_path)]
        profile = plan['profile']
        require(state['status'] == 'completed' and plan['model'] == journal['model'] == MODEL
                and profile == journal['profile'] and file_sha(journal_path) == state['transport_journal_sha256'],
                'reference_evidence_changed')
        request = next(row['request'] for row in journal['requests']
                       if row['record']['measurement_stage'].startswith('discovery:'))
        require(request['messages'][0]['content'] == prompt
                and request['response_format']['json_schema']['schema'] ==
                    extraction_schema(kinds, 'typed', profile['max_candidates']),
                'reference_discovery_prompt_or_schema_changed')
        sources[label] = {'plan': plan, 'first_request': request,
                          'plan_sha256': file_sha(plan_path), 'journal_sha256': file_sha(journal_path)}
    return sources, prompt, kinds


def measure(label, reference, prompt, kinds):
    profile = reference['plan']['profile']
    folder = WORK / label
    folder.mkdir()
    history, outcomes = [], {}
    settings = Namespace(**profile, candidate_mode='typed', strategy='auto', target_input_tokens=0)
    with TemporaryDirectory(prefix='kaponir-fresh-lfm12-') as location:
        home = Path(location)
        worker = Worker(home, configuration(home, {'model_dir': str(ROOT / 'models'),
            'runtime': str(RUNTIME), 'threads': 2,
            'ocr_timeout_seconds': profile['worker_configuration_timeout_seconds']}), 'unused')
        try:
            generation = {name: profile[name] for name in ('temperature', 'top_p', 'top_k', 'min_p', 'seed')}
            client = MeasuredClient(worker, MODEL, profile['context_tokens'], profile['output_tokens'],
                                    profile['response_format'], generation, profile, folder, history)
            require(client.output_mode == 'grammar', 'reference_discovery_format_changed')
            for name, source in SOURCES.items():
                client.measurement_stage = f'discovery:{name}'
                first = len(history)
                print(label, name, 'running', flush=True)
                stage = discover(client, source, prompt, kinds, settings, client.save_history)
                entries = history[first:]
                for entry in entries:
                    actual = entry['request']
                    expected = reference['first_request']
                    require({k: v for k, v in actual.items() if k not in ('messages', 'max_tokens')} ==
                            {k: v for k, v in expected.items() if k not in ('messages', 'max_tokens')}
                            and actual['messages'][0] == expected['messages'][0],
                            'request_settings_changed')
                rejected = 0
                for entry in entries:
                    record = entry['record']
                    if entry.get('parse_error') or entry['status'] != 'received':
                        continue
                    source_fragment = json.loads(entry['request']['messages'][-1]['content'])['source']
                    raw = json.loads(entry['raw_reply']['choices'][0]['message']['content'])['candidates']
                    rejected += sum(not (isinstance(row.get('value'), str)
                        and 3 <= len(row['value'].encode()) <= 512
                        and row['value'].strip() == row['value'] and row['value'] in source_fragment)
                        for row in raw)
                values = {row['value'] for row in stage['values']}
                outcomes[name] = {**stage, 'requests': len(entries),
                    'http_seconds': sum(row['record']['http_wall_seconds'] for row in entries),
                    'returned_literal_private': len(values.intersection(PRIVATE_VALUES[name])),
                    'returned_literal_public': len(values.intersection(PUBLIC_VALUES[name])),
                    'rejected_as_ungrounded': rejected,
                    'request_error_count': sum(bool(row['record'].get('error')) for row in entries),
                    'native_thinking_tokens': sum(row['record'].get('reasoning_text_tokens', 0) for row in entries)}
                atomic_json(folder / 'discovery.json', outcomes)
                print(label, name, 'done', len(entries), round(outcomes[name]['http_seconds'], 2), flush=True)
        finally:
            worker.stop_runtime()
    require(not runtime_processes(RUNTIME), 'model_runtime_cleanup_failed')
    return outcomes


def select_search_masks(pool, discovery):
    union = {(case.file, case.value): case for case in pool}
    for name, stage in discovery.items():
        text = SOURCES[name]
        for row in stage['values']:
            value = row['value']
            offset = text.index(value)
            union.setdefault((name, value), Candidate(opaque_id(name, value), name, value,
                offset, offset + len(value), row['kind'], origin='discovery_llm'))
    stage = {'candidates': [case.json() for case in union.values()],
             'decisions': {case.id: {'valid': True, 'verdict': 'mask'} for case in union.values()}}
    return select_masks(stage, SOURCES)[0]


def apply(label, hashes, masks):
    folder = WORK / f'apply-{label}'
    method = 'detector_proposals' if label == 'detector_proposals' else 'current_union'
    report = apply_documents(BINARY, folder, hashes, SOURCES, PRIVATE_VALUES, PUBLIC_VALUES, masks,
                             {'model': MODEL, 'variant': label, 'stage': method})
    result = {'exact_roundtrips': report['exact_roundtrips'], 'documents': {}}
    for index, (name, source) in enumerate(SOURCES.items(), start=1):
        row = next(row for row in report['documents'] if row['file'] == name
                   and row['mode'] == 'model_masks_added')
        data = strict_json((folder / 'model_masks_added' / f'{index:02d}-{Path(name).stem}'
                            / 'mask.json').read_text())
        full = []
        incomplete = []
        for value in PRIVATE_VALUES[name]:
            spans = span_coverage(source, [value], data['replacements'], data['text'])
            (full if spans['private_occurrence_spans'] == spans['private_spans_fully_covered']
             else incomplete).append(value)
        public_lost = [value for value in PUBLIC_VALUES[name]
                       if len(occurrences(data['text'], value)) < len(occurrences(source, value))]
        result['documents'][name] = {**row, 'private_values_fully_covered': full,
                                     'private_values_incomplete': incomplete, 'public_values_lost': public_lost}
    return result


def main():
    references, prompt, kinds = load_references()
    binary_sha = file_sha(BINARY)
    status = strict_json((ROOT / 'status.json').read_text())
    require(binary_sha == status['binary_sha256'], 'application_binary_changed')
    artifact = references['original']['plan']['model_artifact']
    require(artifact == references['recommended']['plan']['model_artifact'], 'model_artifacts_differ')
    model_path = ROOT / 'models' / artifact[0]
    require(model_path.stat().st_size == artifact[1] and file_sha(model_path) == artifact[2],
            'model_artifact_changed')
    require(file_sha(RUNTIME) == RUNTIME_SHA256 ==
            references['original']['plan']['expected_runtime_sha256'] ==
            references['recommended']['plan']['expected_runtime_sha256'], 'runtime_changed')
    _, _, _, earlier_sources, _ = load_corpus()
    hashes = {name: hashlib.sha256(text.encode()).hexdigest() for name, text in SOURCES.items()}
    for name, text in SOURCES.items():
        require(text not in earlier_sources.values()
                and all(occurrences(text, value) for value in PRIVATE_VALUES[name] + PUBLIC_VALUES[name])
                and all(value not in old for old in earlier_sources.values() for value in PRIVATE_VALUES[name]),
                'new_fixture_or_annotations_not_verified')
    WORK.mkdir(parents=True, exist_ok=False)
    atomic_json(WORK / 'plan.json', {'model': MODEL, 'script_sha256': file_sha(Path(__file__)),
        'source_sha256': hashes, 'sources': SOURCES, 'private_values': PRIVATE_VALUES, 'public_values': PUBLIC_VALUES,
        'model_sha256': artifact[2], 'runtime_sha256': RUNTIME_SHA256, 'binary_sha256': binary_sha,
        'detector_exporter_sha256': file_sha(DETECTORS), 'threads': 2, 'route': ROUTE,
        'references': {label: {key: value for key, value in reference.items() if key.endswith('_sha256')}
                       for label, reference in references.items()},
        'switch_log_condition': 'original fully covers more private spans without extra public losses',
        'switch_public_condition': 'recommended loses no additional public spans and is faster',
        'hybrid_success_condition': 'no full private coverage loss or extra public losses vs original and faster'})
    pool, exported = detector_pool(DETECTORS, SOURCES)
    atomic_json(WORK / 'detectors.json', exported)
    with SuiteLock(ROOT / '.native-retest.lock'), research_registration(MODEL):
        require(not runtime_processes(RUNTIME), 'model_runtime_already_running')
        measurements = {label: measure(label, reference, prompt, kinds) for label, reference in references.items()}
    masks = {label: select_search_masks(pool, value) for label, value in measurements.items()}
    masks['hybrid'] = {name: masks[label].get(name, []) for name, label in ROUTE.items()}
    masks['detector_proposals'] = select_search_masks(pool, {})
    atomic_json(WORK / 'selected-masks.json', masks)
    applications = {label: apply(label, hashes, selected) for label, selected in masks.items()}
    for name, label in ROUTE.items():
        require(applications['hybrid']['documents'][name] == applications[label]['documents'][name],
                'hybrid_application_mismatch')
    report = {'status': 'completed', 'model': MODEL, 'route': ROUTE,
              'measurements': measurements, 'applications': applications,
              'model_requests': sum(row['requests'] for docs in measurements.values() for row in docs.values()),
              'hybrid_http_seconds': sum(measurements[label][name]['http_seconds'] for name, label in ROUTE.items()),
              'exact_roundtrips': sum(row['exact_roundtrips'] for row in applications.values())}
    atomic_json(WORK / 'summary.json', report)
    print('complete', report['model_requests'], 'model requests', report['exact_roundtrips'], 'round trips', flush=True)


if __name__ == '__main__':
    main()
