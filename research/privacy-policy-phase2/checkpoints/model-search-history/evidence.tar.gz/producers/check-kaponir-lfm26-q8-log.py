"""Replay one LFM 2.6B log fragment with official Q8_0 weights."""

from argparse import Namespace
import json
from pathlib import Path
import runpy
from tempfile import TemporaryDirectory

from experiment_inference import discover, prompts_and_kinds
from kaponir_worker import FILES, Worker, configuration
from native_model_profiles import catalog_for
from privacy_expansion_profiles import research_registration
from run_privacy_policy_suite import SuiteLock, atomic_json, file_sha, runtime_processes
from summarize_privacy_policy import require


here = Path(__file__).resolve().parent
senior = runpy.run_path(str(here / 'check-kaponir-lfm-senior-log.py'))
large, read = senior['large'], senior['read']
model, log = senior['LFM26'], senior['LOG']
root, runtime, binary, baseline_root = (senior[k] for k in ('ROOT', 'RUNTIME', 'BINARY', 'WORK'))
out = baseline_root.parent / 'lfm26-q8-log'
filename = 'LFM2.5-2.6B-Q8_0.gguf'
revision = 'e7caca5d835a3901a8e0d63e94009429bafafdfc'
artifact = (filename, 2874779648, '1e22128dfa128bdfb684da167e74e072d0a056baa7d06d9f280291e2839b0fc9',
            f'https://huggingface.co/LiquidAI/LFM2.5-2.6B-GGUF/resolve/{revision}/{filename}')
weights = out / 'weights' / filename
require(weights.is_file() and weights.stat().st_size == artifact[1] and file_sha(weights) == artifact[2],
        'downloaded_q8_weights_changed')
plan = read(baseline_root / 'plan.json')
require(file_sha(binary) == plan['binary_sha256'] and file_sha(runtime) == plan['runtime_sha256'],
        'baseline_artifact_changed')
sources, private, public, pool = large['corpus']()
base = large['originals'](model, sources, plan['binary_sha256'])
require('/resolve/' + revision + '/' in base['artifact'][3], 'q4_and_q8_have_different_revisions')
baseline = read(baseline_root / model / 'result.json')['same-four-fragments']
q4_journal = baseline_root / model / 'same-four-fragments/transports.json'
q4 = read(q4_journal)['requests'][0]
fragment = json.loads(q4['request']['messages'][-1]['content'])
require(fragment == plan['fragments'][0], 'reference_fragment_changed')
profile = base['profile']
prompt, _, kinds = prompts_and_kinds()
response_path = out / 'fragment'
require(not response_path.exists(), 'existing_q8_probe')

with SuiteLock(root / '.native-retest.lock'), research_registration(model, catalog_for(model)):
    require(not runtime_processes(runtime), 'runtime_active')
    FILES[model] = artifact
    atomic_json(out / 'plan.json', {'q8_artifact':artifact, 'q4_artifact':base['artifact'],
        'q4_reference_journal_sha256':file_sha(q4_journal), 'fragment':1, 'profile':profile,
        'runtime_sha256':plan['runtime_sha256'], 'script_sha256':file_sha(Path(__file__))})
    response_path.mkdir()
    history = []
    with TemporaryDirectory(prefix='kaponir-lfm-q8-probe-') as temporary:
        home = Path(temporary)
        worker = Worker(home, configuration(home, {
            'model_dir':str(weights.parent), 'runtime':str(runtime),'threads':2,
            'ocr_timeout_seconds':profile['worker_configuration_timeout_seconds']}), 'unused')
        try:
            generation = {k:profile[k] for k in ('temperature','top_p','top_k','min_p','seed')}
            client = senior['SameFragmentClient'](worker, model, profile['context_tokens'], profile['output_tokens'],
                profile['response_format'], generation, profile, response_path, history)
            client.fragment_context = fragment['context']
            client.measurement_stage = q4['record']['measurement_stage']
            settings = Namespace(**profile, candidate_mode='typed', strategy='fixed', target_input_tokens=0,
                                 fixed_bytes=len(fragment['source'].encode()), fixed_overlap_bytes=0)
            print('2.6B Q8_0 replay running', flush=True)
            stage = discover(client, fragment['source'], prompt, kinds, settings, client.save_history)
            require(len(history) == 1 and not stage['errors'], 'q8_probe_incomplete')
            entry = history[0]
            require(entry['request'] == q4['request']
                    and entry['rendered_prompt_sha256'] == q4['rendered_prompt_sha256'],
                    'q8_changed_request_or_template')
            record = entry['record']
            stage.update(requests=1, input_tokens=record['input_tokens'],
                         reasoning_tokens=[record['reasoning_text_tokens']],
                         output_tokens=[record['usage']['completion_tokens']],
                         http_seconds=record['http_wall_seconds'])
        finally:
            worker.stop_runtime()
    require(not runtime_processes(runtime), 'q8_runtime_not_cleaned_up')
patched = {**baseline['fragments'], '1':stage}
variant = {**baseline['discovery'],log:senior['sum_fragments'](patched)}
applied = large['apply_stage'](model,'q8-first-fragment',variant,sources,private,public,pool,base['source_sha256'],out)
atomic_json(out/'result.json',{'q8_fragment':stage,**applied})
row = applied['application'][log]
print('Q8_0 fragment applied',row['private_spans_fully_covered'],row['public_occurrences_lost'],
      round(stage['http_seconds'],2),flush=True)
