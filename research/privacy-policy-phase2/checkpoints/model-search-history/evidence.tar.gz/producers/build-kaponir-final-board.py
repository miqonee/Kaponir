"""Assemble published model selections from the stored search runs, settings, and separate A–D table."""
import csv
import gzip
import hashlib
import json
import re
import tarfile
from decimal import Decimal as D
from pathlib import Path

repo=Path('/workspace/Kaponir')
docs=repo/'docs/experiments'
ck=repo/'research/privacy-policy-phase2/checkpoints'
summary=docs/'MODEL_RESEARCH_SUMMARY.md'
leaderboard=docs/'model-search-summary-60-30-15.csv'
speedfile=docs/'model-search-speed.csv'
def csvrows(path):
    with path.open(newline='') as fp:return list(csv.DictReader(fp))
def decode(path):
    content=path.read_bytes()
    return json.loads(gzip.decompress(content) if path.name.endswith('.gz') else content)
def tar_json(path,name):
    with tarfile.open(path) as f:return json.load(f.extractfile(name))
def local(p):return str(p.relative_to(repo))
def ru(value,n=2):return f'{D(str(value)):.{n}f}'.replace('.',',')
def short(v):return format(D(str(v)).normalize(),'f').replace('.',',') if v!='' else '—'
def fmt(cells):return '| '+' | '.join(map(str,cells))+' |'
names={
 'gemma4-e4b-qat':('Gemma 4 E4B QAT','Gemma 4 E4B QAT'),
 'nanbeige42-3b':('Nanbeige 4.2 3B','Nanbeige 4.2 3B'),
 'lfm2.5-1.2b-instruct':('LFM 2.5 1.2B Instruct','LFM 2.5 1.2B'),
 'qwen3.5-2b':('Qwen3.5-2B','Qwen3.5-2B'),
 'lfm2.5-2.6b':('LFM 2.5 2.6B','LFM 2.5 2.6B'),
 'qwen3.5-4b':('Qwen3.5-4B','Qwen3.5-4B'),
 'qwen3.5-0.8b':('Qwen3.5-0.8B','Qwen3.5-0.8B'),
 'granite42-3b':('Granite 4.2 3B','Granite 4.2 3B'),
 'minicpm5-2b':('MiniCPM5-2B','MiniCPM5-2B'),
 'tiny-aya-global':('Tiny Aya Global','Tiny Aya Global'),
 'gemma4-e4b-it-q4km':('Gemma 4 E4B-it Q4_K_M','Gemma 4 E4B-it¹'),
 'huihui-qwen3.5-2b-abliterated':('Huihui Qwen3.5-2B','Huihui Qwen3.5-2B'),
 'gemma4-e2b-it-q4km':('Gemma 4 E2B-it','Gemma 4 E2B-it'),
 'spark-x2.6-4b':('Spark X2.6 4B','Spark X2.6 4B'),
 'lfm2.5-8b-a1b':('LFM 2.5 8B-A1B','LFM 2.5 8B-A1B'),
}
history=summary.read_text()
table=history.split('## Все 15 моделей на исходных документах',1)[1].split('\n\n¹',1)[0]
abcd={}
for line in table.splitlines():
    cells=[v.strip() for v in line.strip('|').split('|')]
    if len(cells)==8 and re.fullmatch(r'[A-D] · \d+,\d+',cells[-1]):
        abcd[cells[0]]=cells[-1].split(' · ')
assert len(abcd)==15

records=csvrows(leaderboard)
archive={(r['model'],r['series'],r['profile']):r for r in records}
speed={r['model']:r for r in csvrows(speedfile) if r['decision']=='selected' and r['sample']=='full'}
assert len(speed)==3
primary={k:('original','search') for k in names}
primary.update({'gemma4-e4b-qat':('fresh_tuning','short-thought384-long-direct'),
                'lfm2.5-1.2b-instruct':('calibrated','log-chunks-full-confirmation'),
                'gemma4-e4b-it-q4km':('recommended','search'),'lfm2.5-8b-a1b':('recommended','search')})
for k,v in speed.items():primary[k]=('speed',v['trial'])

oldfiles={'qwen3.5-2b':'qwen','qwen3.5-0.8b':'qwen08','huihui-qwen3.5-2b-abliterated':'huihui',
          'granite42-3b':'granite','minicpm5-2b':'minicpm'}
speeds={'nanbeige42-3b':'nano','qwen3.5-4b':'qwen','lfm2.5-2.6b':'lfm'}
fourd=ck/'four-models-fresh-tuning'
speedd=ck/'three-models-speed'
four=decode(fourd/'manifest.json')
selection=decode(speedd/'manifest.json')['selection']['recommended']
modes={
 'gemma4-e4b-qat':'До 1 024 токенов исходного текста — рассуждения до 384, выше — прямой ответ.',
 'nanbeige42-3b':'Прямой ответ, JSON Schema через /completion. Лог до 2 304 токенов, остальные документы целиком.',
 'lfm2.5-1.2b-instruct':'Прямой ответ. Лог до 2 432 токенов, четыре фрагмента. repeat_penalty 1,05.',
 'lfm2.5-2.6b':'Рассуждения 384. Лог до 1 536 токенов без подсказки, repeat_penalty 1,0. На обычном тексте подсказка 256 и штраф 1,1.',
 'qwen3.5-4b':'Прямой ответ. Все документы до 2 432 токенов на запрос, presence_penalty 0, repeat_penalty 1.',
 'qwen3.5-2b':'Исходный режим с JSON Schema.','qwen3.5-0.8b':'Исходный режим с JSON Schema.',
 'huihui-qwen3.5-2b-abliterated':'Исходный режим с JSON Schema.',
 'granite42-3b':'Исходный режим auto, сервер выбрал JSON Schema.',
 'minicpm5-2b':'Исходный архив содержит лимиты контекста и ответа. Семплирование и режим JSON не записаны.',
 'tiny-aya-global':'Исходный прямой ответ, JSON Schema.',
 'gemma4-e4b-it-q4km':'JSON Schema, рассуждения до 2 048. Проверенный GGUF Q4_K_M.',
 'gemma4-e2b-it-q4km':'Историческая строка. Настройки полного прогона и точный GGUF не подтверждены.',
 'spark-x2.6-4b':'Исходный прямой ответ, JSON Schema.',
 'lfm2.5-8b-a1b':'JSON Schema, рассуждения до 1 024, repeat_penalty 1,05.'}
rows=[]
for model,(title,legacy_title) in names.items():
    series,profile=primary[model]
    orig=archive.get((model,'original','search'),{}).get('score_60_30_15_100','')
    vendor=archive.get((model,'recommended','search'),{}).get('score_60_30_15_100','')
    vendor_profile='recommended/search' if vendor else ''
    if model=='granite42-3b':
        ibm=archive[model,'calibrated','direct-card']
        vendor=ibm['score_60_30_15_100'];vendor_profile='calibrated/direct-card'
        assert hashlib.sha256((repo/ibm['application_or_table']).read_bytes()).hexdigest()==ibm['application_sha256']
    p={}; read_cpu=gen_cpu=''; log_t=None; route=''; tuning=''; source_member=''; result_source=''
    if series=='speed':
        r=speed[model];h,pub,guide=[int(r[k]) for k in ['private_hidden','public_lost','public_guide_replacements']]
        k=speeds[model]; assert selection[k]==profile
        source=speedd/'evidence.tar.gz';source_member=f'runs/{k}/{profile}/plan.json';plan=tar_json(source,source_member);p=plan['profile']
        read_cpu,gen_cpu=r['prompt_threads'],r['generation_threads'];result_source=local(speedd/'manifest.json')
        if k=='nano': log_t=p['temperature'];p={**p,'temperature':0}
        route=p['route']; tuning='измерен на полном и коротком корпусах'
    else:
        r=archive[model,series,profile];h,pub,guide=[int(r[k]) for k in ['private_full_193','public_lost_87','guide_replacements']]
        app=repo/r['application_or_table']
        if r['application_sha256']:assert hashlib.sha256(app.read_bytes()).hexdigest()==r['application_sha256']
        result_source=local(app)
        if model in oldfiles:
            source=repo/'benchmark/data/validation'/(oldfiles[model]+'-calibration--result.json.gz');old=decode(source)
            assert old['signature']['model']==model
            p={**old['signature']['settings'],**(old.get('generation') or {})}
            route=old.get('structured_output','')
            tuning='исходный архив поиска'
        elif model=='gemma4-e4b-qat':
            source=fourd/'evidence.tar.gz';source_member=four['selected_profiles'][model]['plan_member']
            plan=tar_json(source,source_member);p=plan['profile'];read_cpu=gen_cpu=plan['threads'];route=p['route']
            tuning='измерен на полном и коротком корпусах'
        elif model=='lfm2.5-1.2b-instruct':
            source=ck/'lfm12-chunked-search-full'/'manifest.json';plan=decode(source)['parameters'];p=plan['profile']
            assert plan['log_target_input_tokens']==2432 and len(plan['cpu_affinity'])==2
            read_cpu=gen_cpu=2;route=p['response_format'];tuning='полный подтверждающий прогон'
        elif model=='gemma4-e2b-it-q4km':
            source=docs/'NEW_MODELS_RESULTS.md';tuning='историческая строка без исходного журнала полного поиска'
        else:
            group={'tiny-aya-global':'2026-11-17-tiny-aya-auto','spark-x2.6-4b':'2026-11-18-spark-auto'}.get(model,'native-retest-'+model)
            source=ck/group/'evidence.tar.gz';result_source=local(ck/group/'manifest.json')
            with tarfile.open(source) as tar:
                source_member=next(n for n in tar.getnames() if n.endswith('/scheme-plan.json'))
                p=json.load(tar.extractfile(source_member))['profile']
                execution=next(n for n in tar.getnames() if n.endswith('/execution.json'))
                argv=json.load(tar.extractfile(execution))['last_runtime_argv']
                read_cpu=argv[argv.index('-tb')+1];gen_cpu=argv[argv.index('-t')+1]
            route='grammar';tuning='исходный полный прогон' if series=='original' else 'полный прогон с настройками производителя'
    if log_t is None:log_t=p.get('temperature','')
    minutes=D(r['http_minutes']);score=D(r['score_60_30_15_100'])
    value=(60*D(h)/193+25*(87-D(pub))/87+5/(1+D(guide))+15*D('11.55')/(D('11.55')+minutes))/D('1.05')
    assert abs(value-score)<D('.00501'),model
    variant,ad=abcd[legacy_title]
    rows.append(dict(model=model,display_name=title,score_60_30_15_100=f'{score:.2f}',original_score_100=orig,
                     vendor_score_100=vendor,vendor_comparison_profile=vendor_profile,http_minutes=r['http_minutes'],private_full_193=h,public_lost_87=pub,
                     guide_replacements=guide,best_abcd_variant=variant,best_abcd_score_100=ad.replace(',','.'),
                     series=series,profile=profile,temperature_text=p.get('temperature',''),temperature_log=log_t,
                     top_p=p.get('top_p',''),top_k=p.get('top_k',''),min_p=p.get('min_p',''),seed=p.get('seed') if p.get('seed') is not None else '',
                     context_tokens=p.get('context_tokens',''),primary_output_tokens=p.get('output_tokens',''),
                     prompt_threads=read_cpu,generation_threads=gen_cpu,structured_output=route,
                     settings=modes[model],evidence_kind=tuning,settings_source=local(source),archive_member=source_member,
                     result_source=result_source))
rows.sort(key=lambda r:-D(r['score_60_30_15_100']))
fields=['rank',*rows[0]]
with (docs/'model-search-final.csv').open('w',newline='') as fp:
    out=csv.DictWriter(fp,fields,lineterminator='\n');out.writeheader()
    for i,r in enumerate(rows,1):out.writerow({'rank':i,**r})
start='<!-- final-search-profiles -->';end='<!-- /final-search-profiles -->'
parts=[start,'## Итоговые профили поиска для 15 моделей','',
       '22 ноября 2026 года. Для каждой модели выбран один профиль поиска по трём документам. У Qwen3.5-4B, Nanbeige и LFM 2.5 2.6B взяты ускоренные режимы, сохранившие все прежние маски и публичные вхождения на основном и коротком корпусах. Места определяет итоговый балл 60:30:15. Время каждой строки относится к собственному проходу соответствующей модели. Для исторической Gemma E2B-it доступна опубликованная итоговая строка.','',
       'В «Исх. / рек.» приведены баллы исходного и проверенного рекомендованного пресета на той же шкале. У Granite использован полный прогон прямого пресета IBM из отдельной калибровки. Потери — затронутые вхождения из 87 публичных, замены — все замены в публичной справке. Колонка A–D показывает лучший балл модели в отдельной проверке готовых целей на 16 приватных и 16 публичных примерах. Балл A–D рассчитан отдельно, параметры этого теста могут отличаться от поисковых.','',
       fmt(['Место','Модель','Исх. / рек.','Итог /100','Мин','Скрыто /193','Потери / замены','Лучший A–D','T / top_p / top_k','Настройки поиска']),
       '|---:|---|---:|---:|---:|---:|---:|---|---|---|']
for i,r in enumerate(rows,1):
    k=r['model']
    temps=short(r['temperature_text'])
    if r['temperature_text']!=r['temperature_log']:temps+=' текст, '+short(r['temperature_log'])+' лог'
    sampler=' / '.join((temps,short(r['top_p']),short(r['top_k']))) if r['temperature_text']!='' else '—'
    ctx=(f" Окно {int(r['context_tokens']):_}, выход {int(r['primary_output_tokens']):_}.".replace('_',' ')
         if r['context_tokens']!='' else '')
    cpu=f" Потоки {r['prompt_threads']}/{r['generation_threads']}." if r['prompt_threads']!='' else ''
    name=r['display_name']+('¹' if k=='gemma4-e4b-it-q4km' else ('²' if k=='gemma4-e2b-it-q4km' else ''))
    parts.append(fmt([i,name,(ru(r['original_score_100']) if r['original_score_100'] else '—')+' / '+(ru(r['vendor_score_100']) if r['vendor_score_100'] else '—'),
                      '**'+ru(r['score_60_30_15_100'])+'**',ru(r['http_minutes']),r['private_full_193'],
                      f"{r['public_lost_87']} / {r['guide_replacements']}",r['best_abcd_variant']+' · '+ru(r['best_abcd_score_100'],1),
                      sampler,r['settings']+ctx+cpu]))
parts.extend(['','T — температура. Окно и первичный лимит ответа даны в токенах. Предел фрагмента учитывает инструкцию и структурную подсказку, а порог 1 024 у Gemma QAT относится к исходному тексту. Потоки указаны в порядке чтение входа / генерация. У трёх ускоренных моделей llama.cpp запускался с §-t 2 -tb 4 -np 1§. Числа потоков приведены там, где их подтверждает профиль или журнал запуска. Разные серии работали при разной нагрузке на CPU.','',
       '¹ У Gemma E4B-it исторический исходный замер дал 73,80/100 и 150/193 за 20,36 минуты. Для итоговой строки взят прогон с подтверждёнными весами Q4_K_M. В отдельном D этот пресет принял все 32 решения верно. ² Для Gemma E2B-it балл пересчитан по опубликованным числам. Привязка исторического прогона к конкретным весам и настройкам остаётся открытой. У MiniCPM5-2B подтверждены окно и выход, поля семплирования отсутствуют в исходном журнале.','',
       'У Gemma QAT полностью прямой ответ при температуре 0 дал те же 190/193 за 11,31 минуты, с десятью публичными потерями и семью заменами в справке. У выбранного режима 12,26 минуты, пять потерь и две замены. У LFM 2.6B вариант с бюджетами 192/384 набрал 83,10 и закрыл 164/193 за 6,48 минуты. Он добавил семь скрытий и открыл четыре прежних, поэтому в итог взят профиль на 82,16 с сохранением каждой прежней маски. У Nanbeige вариант на 192/193 дал пять публичных потерь и 32,91 минуты, у выбранного — три потери и 22,05 минуты.','',
       'Итоговый балл равен §(60 × H/193 + 25 × (87 − P)/87 + 5/(1 + R) + 15 × 11,55/(11,55 + t)) / 1,05§. H — полностью скрытые приватные вхождения после применения через API, P — публичные потери, R — замены в справке, t — минуты HTTP-поиска по смете, журналу и справке.','',
       'У Nanbeige лучший A–D получен на другом пресете, восемь целей остались без ответа по тайм-ауту. [Проверка Nanbeige и пресет IBM](MODEL_SETTINGS_RESEARCH.md#подбор-пресетов-granite-и-nanbeige)','',
       '[Финальная таблица с параметрами в CSV](model-search-final.csv) · [Все исходные и подобранные профили](model-search-summary-60-30-15.csv) · [Парные замеры CPU](THREE_MODEL_SPEED.md) · [Четыре калиброванных пресета](FOUR_MODEL_TUNING.md) · [Архив исходных параметров](../../benchmark/data/validation/manifest.json) · [Проверки A–D](NATIVE_MODEL_RETEST.md#abcd)',end])
block='\n'.join(parts).replace('§',chr(96))
if start in history: history=re.sub(re.escape(start)+'.*?'+re.escape(end),lambda _:block,history,count=1,flags=re.S)
else:
    first,rest=history.split('\n\n',1)
    history=first+'\n\n'+block+'\n\n'+rest
if 'Историческое сравнение в этом разделе использует прежние веса' not in history:
    history=history.replace('Первые три числовых столбца — **баллы поиска из 100**.','Историческое сравнение в этом разделе использует прежние веса 50:20:30. Первые три числовых столбца — **баллы поиска из 100**.')
summary.write_text(history)
print('Wrote',len(rows),'ranked models and',len(abcd),'separate A–D results.')
