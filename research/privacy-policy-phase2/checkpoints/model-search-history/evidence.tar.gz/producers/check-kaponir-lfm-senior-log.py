"""Compare LFM context splitting and reasoning limits on the same annotated log."""

from argparse import ArgumentParser, Namespace
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
from tempfile import TemporaryDirectory

from evaluate_model_schemes import MeasuredClient
from experiment_inference import discover, prompts_and_kinds
from kaponir_worker import Worker, configuration
from native_model_profiles import catalog_for
from privacy_expansion_profiles import research_registration
from run_privacy_policy_suite import SuiteLock, atomic_json, file_sha, runtime_processes
from summarize_privacy_policy import digest, require


HERE = Path(__file__).resolve().parent
LARGE_RUNNER = HERE / 'check-kaponir-lfm-large.py'
large = runpy.run_path(str(LARGE_RUNNER))
read = large['read']
ROOT, LOG, RUNTIME, BINARY = (large[key] for key in ('ROOT', 'LOG', 'RUNTIME', 'BINARY'))
LFM12, LFM26, LFM8 = (large[key] for key in ('LFM12', 'LFM26', 'LFM8'))
PREVIOUS = large['WORK']
WORK = PREVIOUS.parent / 'lfm-senior-log'
SPLIT_JOURNAL = PREVIOUS / LFM12 / 'log-chunks/transports.json'
HIGHER_8B = 1536


class SameFragmentClient(MeasuredClient):
    """Use the same recorded source and context for all models."""

    def infer(self, prompt, value, schema, output_tokens):
        return super().infer(prompt, {**value, 'context': self.fragment_context}, schema, output_tokens)


def collect_split(model, base, fixture, output, budget=None, indices=None):
    profile = dict(base['profile'])
    if budget is not None:
        profile['reasoning_budget'] = budget
    fragments = fixture['fragments']
    indices = range(len(fragments)) if indices is None else indices
    prompt, _, kinds = prompts_and_kinds()
    output.mkdir(parents=True)
    history, fragments_found = [], {}
    expected = base['requests'][LOG]['request']
    with TemporaryDirectory(prefix='kaponir-lfm-fixed-fragments-') as location:
        home = Path(location)
        worker = Worker(home, configuration(home, {'model_dir': str(ROOT / 'models'), 'runtime': str(RUNTIME),
            'threads': 2, 'ocr_timeout_seconds': profile['worker_configuration_timeout_seconds']}), 'unused')
        try:
            generation = {key: profile[key] for key in ('temperature', 'top_p', 'top_k', 'min_p', 'seed')}
            client = SameFragmentClient(worker, model, profile['context_tokens'], profile['output_tokens'],
                                         profile['response_format'], generation, profile, output, history)
            for index in indices:
                fragment = fragments[index]
                source = fragment['source']
                client.fragment_context = fragment['context']
                client.measurement_stage = f'discovery:{LOG}:fragment:{index+1}'
                settings = Namespace(**profile, candidate_mode='typed', strategy='fixed', target_input_tokens=0,
                                    fixed_bytes=len(source.encode()), fixed_overlap_bytes=0)
                first = len(history)
                print(model, output.name, 'fragment', index+1, 'running', flush=True)
                stage = discover(client, source, prompt, kinds, settings, client.save_history)
                calls = history[first:]
                require(len(calls) >= 1 and calls[0]['request']['max_tokens'] == expected['max_tokens'],
                        'fixed_fragment_not_measured')
                for entry in calls:
                    request = entry['request']
                    require({key: value for key, value in request.items() if key not in ('messages', 'max_tokens')}
                            == {key: value for key, value in expected.items() if key not in ('messages', 'max_tokens')}
                            and request['messages'][0] == expected['messages'][0]
                            and json.loads(request['messages'][-1]['content']) == fragment
                            and digest(request) == entry['request_sha256'],
                            'fixed_fragment_settings_changed')
                records = [entry['record'] for entry in calls]
                fragments_found[str(index+1)] = {**stage, 'requests': len(calls),
                    'input_tokens': records[0]['input_tokens'],
                    'reasoning_tokens': [r.get('reasoning_text_tokens') for r in records],
                    'output_tokens': [r.get('usage', {}).get('completion_tokens') for r in records],
                    'http_seconds': sum(r['http_wall_seconds'] for r in records),
                    'candidate_ceiling_hit': len(stage['values']) >= profile['max_candidates'],
                    'budget_reached': any((r.get('reasoning_text_tokens') or 0) >= profile['reasoning_budget'] - 4
                                           for r in records)}
                atomic_json(output / 'fragments.json', fragments_found)
                print(model, output.name, 'fragment', index+1, 'done', len(stage['values']),
                      fragments_found[str(index+1)]['reasoning_tokens'],
                      round(fragments_found[str(index+1)]['http_seconds'], 2), flush=True)
        finally:
            worker.stop_runtime()
    return fragments_found


def sum_fragments(fragments):
    values = {}
    for part in fragments.values():
        for row in part['values']:
            values.setdefault(row['value'], row)
    return {'values': list(values.values()),
            'errors': [error for part in fragments.values() for error in part['errors']],
            'fragments': len(fragments),
            'requests': sum(part['requests'] for part in fragments.values()),
            'http_seconds': sum(part['http_seconds'] for part in fragments.values()),
            'reasoning_tokens': sum(n for part in fragments.values() for n in part['reasoning_tokens'] if n is not None),
            'output_tokens': sum(n for part in fragments.values() for n in part['output_tokens'] if n is not None)}


def original_discovery(base):
    return {name: {**found, 'reused': True, 'requests': 1,
            'http_seconds': base['requests'][name]['record']['http_wall_seconds'],
            'reasoning_tokens': base['requests'][name]['record']['reasoning_text_tokens'],
            'output_tokens': base['requests'][name]['record']['usage']['completion_tokens']}
            for name, found in base['discovery'].items()}


def run_model(model, cpus):
    os.sched_setaffinity(0, cpus)
    fixture = read(WORK / 'plan.json')
    sources, private, public, pool = large['corpus']()
    original = large['originals'](model, sources, fixture['binary_sha256'])
    require(original['journal_sha256'] == fixture['reference_journal_sha256'][model], 'archived_journal_changed')
    name, size, sha, _ = original['artifact']
    gguf = ROOT / 'models' / name
    require(gguf.stat().st_size == size and file_sha(gguf) == sha, 'model_artifact_changed')
    old = original_discovery(original)
    experiments = {'whole-recommended': {'application': original['application'], 'discovery': old,
        'http_seconds': sum(row['http_seconds'] for row in old.values()), 'exact_roundtrips': 6}}
    folder = WORK / model
    with research_registration(model, catalog_for(model)):
        if model == LFM8:
            label = f'whole-{HIGHER_8B}'
            output = folder / label
            change = {'reasoning_budget': HIGHER_8B}
            measured = large['explore'](model, original, {LOG: sources[LOG]},
                                         {**original['profile'], **change}, output, change)
            experiments[label] = large['apply_stage'](model, label, {**old, **measured}, sources, private,
                                                      public, pool, original['source_sha256'], output)
            atomic_json(folder / 'result.json', experiments)
        label = 'same-four-fragments'
        output = folder / label
        fragments = collect_split(model, original, fixture, output)
        combined = sum_fragments(fragments)
        require(not combined['errors'] and len(fragments) == 4, 'fixed_fragments_not_completed')
        experiments[label] = {**large['apply_stage'](model, label, {**old, LOG: combined}, sources, private,
                                                     public, pool, original['source_sha256'], output),
                              'fragments': fragments}
        atomic_json(folder / 'result.json', experiments)
    print(model, 'log measured and applied', flush=True)


def run():
    require(not WORK.exists() and file_sha(RUNTIME) == large['RUNTIME_SHA256'], 'existing_run_or_wrong_runtime')
    previous = read(PREVIOUS / 'summary.json')
    prior_plan = read(PREVIOUS / 'plan.json')
    require(previous['status'] == 'completed' and previous['plan_sha256'] == file_sha(PREVIOUS / 'plan.json')
            and file_sha(BINARY) == prior_plan['binary_sha256'], 'previous_log_run_changed')
    sources, _, _, _ = large['corpus']()
    entries = read(SPLIT_JOURNAL)['requests']
    fragments = [json.loads(row['request']['messages'][-1]['content']) for row in entries]
    require(len(fragments) == 4 and ''.join(row['source'] for row in fragments) == sources[LOG]
            and all(row['record']['finish_reason'] == 'stop'
                    and row['request_sha256'] == digest(row['request']) for row in entries),
            'lfm12_log_fragments_changed')
    checks = {m: large['originals'](m, sources, prior_plan['binary_sha256']) for m in (LFM26, LFM8)}
    cores = sorted(os.sched_getaffinity(0))
    slots = [cores[i:i+2] for i in range(0, min(len(cores), 4) - 1, 2)]
    require(slots, 'not_enough_threads_for_replay')
    with SuiteLock(ROOT / '.native-retest.lock'):
        require(not runtime_processes(RUNTIME), 'another_model_run_is_active')
        atomic_json(WORK / 'plan.json', {'previous_run_plan_sha256': previous['plan_sha256'],
            'script_sha256': file_sha(Path(__file__)), 'runner_sha256': file_sha(LARGE_RUNNER),
            'binary_sha256': prior_plan['binary_sha256'], 'runtime_sha256': file_sha(RUNTIME),
            'source_sha256': prior_plan['source_sha256'][LOG], 'fragment_journal_sha256': file_sha(SPLIT_JOURNAL),
            'reference_journal_sha256': {m: row['journal_sha256'] for m, row in checks.items()},
            'log': LOG, 'fragments': fragments, 'test_whole_8b_budget': HIGHER_8B, 'cpu_affinities': slots})
        commands = [[sys.executable, '-Bu', __file__, '--model', model, '--cpus',
                     ','.join(map(str, slots[i % len(slots)]))] for i, model in enumerate(checks)]
        if len(slots) >= len(commands):
            children = [subprocess.Popen(command) for command in commands]
            codes = [child.wait() for child in children]
        else:
            codes = [subprocess.run(command, check=False).returncode for command in commands]
        require(not runtime_processes(RUNTIME), 'model_runtime_not_cleaned_up')
    effective = {m: read(WORK / m / 'result.json') for m in checks if (WORK / m / 'result.json').is_file()}
    atomic_json(WORK / 'summary.json', {'models': effective, 'exit_codes': dict(zip(checks, codes, strict=True)),
        'plan_sha256': file_sha(WORK / 'plan.json')})
    print('senior LFM comparison complete', dict(zip(checks, codes, strict=True)), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('--model')
    parser.add_argument('--cpus')
    args = parser.parse_args()
    if args.model:
        run_model(args.model, [int(cpu) for cpu in args.cpus.split(',')])
    else:
        run()
