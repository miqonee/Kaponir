"""Reapply three single-setting LFM probes and a small log-chunking experiment."""

from argparse import ArgumentParser, Namespace
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
from tempfile import TemporaryDirectory
import time

from apply_measured_privacy import apply_documents
from evaluate_validation_schemes import detector_pool_from_export
from experiment_inference import discover, prompts_and_kinds
from kaponir_worker import Worker, configuration
from native_model_profiles import catalog_for
from privacy_expansion_profiles import research_registration
from run_privacy_policy_suite import SuiteLock, atomic_json, file_sha, runtime_processes
from summarize_privacy_policy import require


HERE = Path(__file__).resolve().parent
MATRIX_SCRIPT = HERE / 'check-kaponir-fresh-matrix.py'
matrix = runpy.run_path(str(MATRIX_SCRIPT))
read = matrix['read']
ROOT, RUNTIME, BINARY = (matrix[key] for key in ('ROOT', 'RUNTIME', 'BINARY'))
PILOT = matrix['PILOT']
OUTPUT = PILOT / 'lfm-tuning'
MATRIX = matrix['OUTPUT']
LFM12 = 'lfm2.5-1.2b-instruct'
LFM26 = 'lfm2.5-2.6b'
LFM8B = 'lfm2.5-8b-a1b'
CHANGES = {
    LFM12: {'temperature': 0.0},
    LFM26: {'reasoning_budget': 512},
    LFM8B: {'reasoning_budget': 512},
}
CHUNK_INPUT_TOKENS = 330


def apply_variant(model, label, plan, discovery, folder):
    fixture = plan['fixture']
    pool, _ = detector_pool_from_export(read(matrix['PREVIOUS'] / 'detectors.json'), fixture['sources'])
    helper = runpy.run_path(str(matrix['PREVIOUS_SCRIPT']))
    require(helper['SOURCES'] == fixture['sources'], 'changed_tuning_fixture')
    selected = helper['select_search_masks'](pool, discovery)
    observed = apply_documents(BINARY, folder / label / 'apply', fixture['source_sha256'], fixture['sources'],
        fixture['private_values'], fixture['public_values'], selected, {'model': model, 'variant': label})
    masks = {row['file']: row for row in observed['documents'] if row['mode'] == 'model_masks_added'}
    return {'measurements': discovery, 'applications': masks, 'exact_roundtrips': observed['exact_roundtrips'],
        'http_seconds': sum(row['http_seconds'] for row in discovery.values()),
        'selected_masks': selected}


def compare_request(model, plan, folder, changed):
    previous = matrix['PREVIOUS'] if model == LFM12 else MATRIX / model
    reference = read(previous / 'recommended/transports.json')
    recorded = read(folder / 'single-change/transports.json')
    require(len(reference['requests']) == len(recorded['requests']) == 2, 'expected_one_request_per_document')
    key, value = next(iter(changed.items()))
    require(recorded['profile'][key] == value
            and reference['profile'][key] == plan['profiles'][model]['baseline'][key],
            'tuning_setting_mismatch')
    for old, new in zip(reference['requests'], recorded['requests'], strict=True):
        expected_request = dict(old['request'])
        if key == 'temperature':
            expected_request[key] = value
        require(new['request'] == expected_request
                and new['rendered_prompt_sha256'] == old['rendered_prompt_sha256']
                and new['record']['measurement_stage'] == old['record']['measurement_stage'],
                'tuning_request_changed_outside_parameter')


def log_chunks(plan, folder):
    label = 'short-log-chunks'
    fixture = plan['fixture']
    log = next(name for name, mode in fixture['route'].items() if mode == 'original')
    public = next(name for name in fixture['sources'] if name != log)
    source = fixture['sources'][log]
    profile = {**plan['profiles'][LFM12]['baseline'], 'transport_timeout_seconds': 180}
    settings = Namespace(**{**profile, 'max_fragments': 8}, candidate_mode='typed',
                         strategy='auto', target_input_tokens=CHUNK_INPUT_TOKENS)
    output = folder / label
    output.mkdir()
    prompt, _, kinds = prompts_and_kinds()
    with TemporaryDirectory(prefix='kaponir-lfm-split-') as location:
        home = Path(location)
        worker = Worker(home, configuration(home, {'model_dir': str(ROOT / 'models'), 'runtime': str(RUNTIME),
            'threads': 2, 'ocr_timeout_seconds': 180}), 'unused')
        try:
            client = matrix['ShortClient'](worker, LFM12, profile, output)
            client.measurement_stage = f'discovery:{log}'
            print(LFM12, label, 'running', flush=True)
            stage = discover(client, source, prompt, kinds, settings, client.save_history)
            requests = client.history
            require(not stage['errors'] and all(r['record']['finish_reason'] == 'stop' for r in requests),
                    'log_split_incomplete')
            covered = ''.join(json.loads(row['request']['messages'][-1]['content'])['source'] for row in requests)
            require(covered == source and len(requests) >= 2
                    and all(r['record']['input_tokens'] <= CHUNK_INPUT_TOKENS for r in requests),
                    'log_split_not_as_planned')
            stage.update(requests=len(requests), ok=True,
                         http_seconds=sum(r['record']['http_wall_seconds'] for r in requests),
                         input_tokens_by_request=[r['record']['input_tokens'] for r in requests])
        finally:
            worker.stop_runtime()
    before = read(matrix['PREVIOUS'] / 'summary.json')['measurements']['recommended'][public]
    result = apply_variant(LFM12, label, plan, {log: stage, public: {**before, 'reused': True}}, folder)
    print(LFM12, label, 'application checked', flush=True)
    return result


def run_model(model, cpu_ids):
    os.sched_setaffinity(0, cpu_ids)
    plan = read(OUTPUT / 'plan.json')
    experiment = plan['profiles'][model]
    model_file, size, checksum, _ = experiment['artifact']
    gguf = ROOT / 'models' / model_file
    require(gguf.stat().st_size == size and file_sha(gguf) == checksum, 'tuning_weights_changed')
    folder = OUTPUT / model
    folder.mkdir(exist_ok=False)
    with research_registration(model, catalog_for(model)):
        discovery = matrix['measure'](model, 'single-change', {'settings': experiment['candidate']},
                                      plan['fixture'], folder / 'single-change')
        compare_request(model, plan, folder, CHANGES[model])
        require(all(row['ok'] for row in discovery.values()), 'tuned_profile_did_not_complete_both')
        output = {'single-change': apply_variant(model, 'single-change', plan, discovery, folder)}
        atomic_json(folder / 'result.json', output)
        if model == LFM12:
            output['short-log-chunks'] = log_chunks(plan, folder)
            atomic_json(folder / 'result.json', output)
    print(model, 'tuning checked', flush=True)


def run_tuning():
    prior = read(MATRIX / 'plan.json')
    baseline = read(MATRIX / 'summary.json')
    require(not OUTPUT.exists() and baseline['status'] == 'completed'
            and baseline['matrix_profile_plan_sha256'] == file_sha(MATRIX / 'plan.json')
            and file_sha(BINARY) == prior['fixture']['binary_sha256']
            and file_sha(RUNTIME) == prior['fixture']['runtime_sha256'],
            'tuning_references_changed_or_output_exists')
    profiles = {}
    for model, changed in CHANGES.items():
        source = prior['profiles'][model]['recommended']
        profiles[model] = {'baseline': source['settings'], 'candidate': {**source['settings'], **changed},
                           'artifact': source['artifact'], 'change': changed}
    cores = sorted(os.sched_getaffinity(0))
    slots = [cores[offset:offset + 2] for offset in range(0, min(4, len(cores)) - 1, 2)]
    require(slots, 'not_enough_cpu_for_tuning')
    jobs = list(CHANGES)
    with SuiteLock(ROOT / '.native-retest.lock'):
        require(not runtime_processes(RUNTIME), 'model_runtime_already_running')
        atomic_json(OUTPUT / 'plan.json', {'fixture': prior['fixture'], 'profiles': profiles,
            'matrix_plan_sha256': file_sha(MATRIX / 'plan.json'), 'script_sha256': file_sha(Path(__file__)),
            'matrix_summary_sha256': file_sha(MATRIX / 'summary.json'), 'chunk_input_tokens': CHUNK_INPUT_TOKENS,
            'cpu_affinities': slots,
            'selection': 'compare full privacy coverage, public occurrences lost and measured request seconds'})
        active, errors = {}, {}
        while jobs or active:
            for index, (model, process) in list(active.items()):
                status = process.poll()
                if status is not None:
                    if status:
                        errors[model] = status
                    del active[index]
            for index, cpus in enumerate(slots):
                if jobs and index not in active:
                    model = jobs.pop(0)
                    process = subprocess.Popen([sys.executable, '-Bu', __file__, '--model', model,
                                                '--cpus', ','.join(map(str, cpus))])
                    active[index] = (model, process)
            if active:
                time.sleep(0.5)
        require(not runtime_processes(RUNTIME), 'tuning_runtime_not_cleaned_up')
    results = {model: read(OUTPUT / model / 'result.json') for model in profiles
               if (OUTPUT / model / 'result.json').exists()}
    atomic_json(OUTPUT / 'summary.json', {'status': 'partial' if errors else 'completed',
        'models': results, 'errors': errors, 'plan_sha256': file_sha(OUTPUT / 'plan.json')})
    print('LFM tuning checked', len(results), errors, flush=True)


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('--model')
    parser.add_argument('--cpus')
    args = parser.parse_args()
    if args.model:
        run_model(args.model, [int(cpu) for cpu in args.cpus.split(',')])
    else:
        run_tuning()
