"""Compare measured A–D decisions with offline validator counterfactuals."""

from collections import Counter
import json
import unicodedata

from experiment_inference import prompts_and_kinds
from native_model_profiles import MODEL_ORDER
from privacy_policy_experiment import validate
from run_native_model_retest import DEFAULT_STUDY
from run_tiny_aya_context_supplement import SUPPLEMENT
from summarize_privacy_policy import load_run, strict_json
from validation_pipeline import Candidate


def normalized(text):
    return ' '.join(unicodedata.normalize('NFC', text).split())


def quoted_in_context(evidence, context):
    if not isinstance(evidence, str):
        return False
    text = normalized(evidence)
    forms = [text]
    for left, right in [('"', '"'), ("'", "'"), ('«', '»'), ('“', '”'), ('`', '`')]:
        if text.startswith(left) and text.endswith(right) and len(text) > 2:
            forms.append(text[1:-1].strip())
    return any(form and form in normalized(context[key]) for form in forms for key in ('record', 'context'))


def add_verdict(counter, private, verdict):
    if verdict in ('mask', 'keep'):
        counter[('private_' if private else 'public_') + verdict] += 1
    elif verdict == 'review':
        counter['review'] += 1


def counterfactuals(raw, candidate, context, kinds, variant):
    def check(row):
        return validate({'decisions': [row]}, [candidate], {candidate.id: context}, kinds, variant)[candidate.id]['valid']

    isolated = check(raw)
    normalize_valid = ignore_quote_valid = isolated
    evidence = raw.get('evidence')
    if (variant != 'D' and not isolated and raw['verdict'] in ('mask', 'keep')
            and isinstance(evidence, str) and len(evidence) <= 160):
        # Supply a known in-document excerpt only to test the other conditions.
        # This never changes an observed decision or enters the scored report.
        substitute = candidate.value[:160]
        assert substitute.strip() and substitute in context['context']
        ignore_quote_valid = check({**raw, 'evidence': substitute})
        normalize_valid = ignore_quote_valid and quoted_in_context(evidence, context)
    return isolated, normalize_valid, ignore_quote_valid


def audit(model, kinds):
    root = DEFAULT_STUDY / SUPPLEMENT if model == 'tiny-aya-global' else DEFAULT_STUDY
    path = root / 'abcd' / model
    run = load_run(path)
    state = strict_json((path / 'result.json').read_text())
    labels = {case['id']: case['reference_private'] for case in run['case_transitions']}
    result = {}
    for measured in run['rows']:
        variant = measured['variant']
        if not measured['outcome_evidence']['all_generation_outcomes_observed']:
            continue
        counts = {key: Counter() for key in ('official', 'per_item', 'normalize_evidence', 'ignore_quote', 'raw')}
        accepted_masks = {key: [] for key in counts}
        issues = Counter()
        for entry in state['responses'].values():
            if entry['variant'] != variant or entry['status'] != 'received':
                continue
            content = entry['raw_reply']['choices'][0]['message']['content']
            try:
                decoded = strict_json(content)
            except (TypeError, ValueError):
                issues['non_json_cases'] += len(entry['case_ids'])
                continue
            if not isinstance(decoded, dict) or set(decoded) != {'decisions'} or not isinstance(decoded['decisions'], list):
                issues['unexpected_root_cases'] += len(entry['case_ids'])
                continue
            rows = [row for row in decoded['decisions'] if isinstance(row, dict) and isinstance(row.get('id'), str)]
            index = Counter(row['id'] for row in rows)
            expected = set(entry['case_ids'])
            issues['repeated_ids'] += sum(index[ident] > 1 for ident in expected)
            issues['omitted_ids'] += len(expected - index.keys())
            issues['unknown_ids'] += len(index.keys() - expected)
            payload = strict_json(entry['request']['messages'][-1]['content'])
            items = {item['id']: item for item in payload['items']}
            assert set(items) == expected
            for row in rows:
                ident = row['id']
                if ident not in expected or index[ident] != 1:
                    continue
                item = items[ident]
                value = item['value']
                candidate = Candidate(ident, '', value, 0, len(value))
                context = {'record': item['record'], 'context': payload['document']}
                private = labels[ident]
                verdict = row.get('verdict')
                add_verdict(counts['raw'], private, verdict)
                if verdict == 'mask':
                    accepted_masks['raw'].append(ident)
                if verdict is None:
                    continue
                for name, valid in zip(('per_item', 'normalize_evidence', 'ignore_quote'),
                                       counterfactuals(row, candidate, context, kinds, variant)):
                    if valid:
                        add_verdict(counts[name], private, verdict)
                        if verdict == 'mask':
                            accepted_masks[name].append(ident)
        stored = measured['quality']
        for name in ('private_mask', 'private_keep', 'public_mask', 'public_keep'):
            counts['official'][name] = stored[name]
        counts['official']['review'] = stored['explicit_review']
        accepted_masks['official'] = [case['id'] for case in run['case_transitions']
            if (decision := case['variants'].get(variant, {})).get('valid') and decision['verdict'] == 'mask']
        assert all(all(a[key] <= b[key] for key in a)
                   for a, b in zip(counts.values(), tuple(counts.values())[1:]))
        result[variant] = {'counts': counts, 'issues': issues, 'accepted_masks': accepted_masks}
    return result


def main():
    _, _, kinds = prompts_and_kinds()
    print(json.dumps({model: audit(model, kinds) for model in MODEL_ORDER}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
