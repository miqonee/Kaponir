"""Select a feasible input-token cap with the tokenizer, then measure LFM1.2's split log."""

from argparse import Namespace
import json
from pathlib import Path
import runpy
from tempfile import TemporaryDirectory

from experiment_inference import discover, extraction_schema, prompts_and_kinds
from kaponir_inference import document_hint, plan_text
from kaponir_worker import Worker, configuration
from native_model_profiles import catalog_for
from privacy_expansion_profiles import research_registration
from run_privacy_policy_suite import SuiteLock, atomic_json, file_sha, runtime_processes
from summarize_privacy_policy import require


here = Path(__file__).resolve().parent
tuning = runpy.run_path(str(here / 'check-kaponir-lfm-tuning.py'))
matrix, read, model = tuning['matrix'], tuning['read'], tuning['LFM12']
runtime = tuning['RUNTIME']
plan_file = tuning['OUTPUT'] / 'plan.json'
plan = read(plan_file)
fixture = plan['fixture']
log = next(name for name, pick in fixture['route'].items() if pick == 'original')
public = next(name for name in fixture['sources'] if name != log)
source = fixture['sources'][log]
profile = {**plan['profiles'][model]['baseline'], 'transport_timeout_seconds': 180}
work = tuning['PILOT'] / 'lfm12-chunk-tuning'
output = work / 'short-log-chunks'
require(not work.exists(), 'existing_chunk_tuning_output')
require(file_sha(runtime) == fixture['runtime_sha256']
        and file_sha(tuning['BINARY']) == fixture['binary_sha256'], 'changed_chunk_tuning_artifact')
weights, size, sha, _ = plan['profiles'][model]['artifact']
path = tuning['ROOT'] / 'models' / weights
require(path.stat().st_size == size and file_sha(path) == sha, 'changed_chunk_tuning_weights')
prompt, _, kinds = prompts_and_kinds()
schema = extraction_schema(kinds, 'typed', profile['max_candidates'])
with SuiteLock(tuning['ROOT'] / '.native-retest.lock'), research_registration(model, catalog_for(model)), \
        TemporaryDirectory(prefix='kaponir-log-chunk-tune-') as temporary:
    require(not runtime_processes(runtime), 'chunk_tuning_runtime_busy')
    output.mkdir(parents=True)
    home = Path(temporary)
    worker = Worker(home, configuration(home, {'model_dir': str(tuning['ROOT'] / 'models'),
        'runtime': str(runtime), 'threads': 2, 'ocr_timeout_seconds': 180}), 'unused')
    try:
        client = matrix['ShortClient'](worker, model, profile, output)
        client.measurement_stage = f'discovery:{log}'
        client.planning_schema = schema
        hints, counts = {}, {}

        def context(offset):
            if offset not in hints:
                hints[offset] = document_hint(source, offset, profile['hint_tokens'], client.token_count)
            return hints[offset]

        def input_count(fragment, hint):
            key = (fragment, hint)
            if key not in counts:
                counts[key] = client.input_tokens(prompt, {'context': hint, 'source': fragment})
            return counts[key]

        full = input_count(source, context(0))
        checked = []
        for candidate in range(full - 1, full - 82, -10):
            try:
                pieces = plan_text(source, lambda fragment, hint: input_count(fragment, hint) <= candidate,
                                   context, strategy='auto', max_fragments=8)
            except ValueError:
                continue
            lengths = [input_count(source[row['start']:row['end']], row['context']) for row in pieces]
            checked.append((candidate, lengths))
        feasible = [(cap, lengths) for cap, lengths in checked if 2 <= len(lengths) <= 3]
        require(feasible, 'no_feasible_short_split')
        limit, _ = min(feasible)
        config = {'model': model, 'source_sha256': fixture['source_sha256'][log], 'settings': profile,
                  'whole_log_input_tokens': full, 'target_input_tokens': limit,
                  'tokenizer_preflight': checked, 'tuning_plan_sha256': file_sha(plan_file)}
        atomic_json(work / 'plan.json', config)
        settings = Namespace(**{**profile, 'max_fragments': 8}, candidate_mode='typed', strategy='auto',
                             target_input_tokens=limit)
        stage = discover(client, source, prompt, kinds, settings, client.save_history)
        requests = client.history
        require(not stage['errors'] and 2 <= len(requests) <= 3
                and all(r['record']['finish_reason'] == 'stop' for r in requests),
                'log_split_incomplete')
        fragments = [json.loads(row['request']['messages'][-1]['content'])['source'] for row in requests]
        require(''.join(fragments) == source
                and all(row['record']['input_tokens'] <= limit for row in requests), 'log_split_changed')
        stage.update(requests=len(requests), ok=True,
                     http_seconds=sum(row['record']['http_wall_seconds'] for row in requests),
                     input_tokens_by_request=[row['record']['input_tokens'] for row in requests])
    finally:
        worker.stop_runtime()
    require(not runtime_processes(runtime), 'chunk_tuning_runtime_not_cleaned_up')
before = read(matrix['PREVIOUS'] / 'summary.json')['measurements']['recommended'][public]
record = tuning['apply_variant'](model, 'short-log-chunks', plan,
                                 {log: stage, public: {**before, 'reused': True}}, work)
atomic_json(work / 'result.json', record)
print('log split', limit, stage['input_tokens_by_request'], round(stage['http_seconds'], 2), flush=True)
