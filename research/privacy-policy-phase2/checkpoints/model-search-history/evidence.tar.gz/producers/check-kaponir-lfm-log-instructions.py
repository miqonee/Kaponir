"""Change only the instructions on the first stored log fragment for two LFM models."""

from argparse import ArgumentParser, Namespace
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
from tempfile import TemporaryDirectory

from experiment_inference import discover, prompts_and_kinds
from kaponir_worker import Worker, configuration
from native_model_profiles import catalog_for
from privacy_expansion_profiles import research_registration
from run_privacy_policy_suite import SuiteLock, atomic_json, file_sha, runtime_processes
from summarize_privacy_policy import require


HERE = Path(__file__).resolve().parent
SENIOR_SCRIPT = HERE / 'check-kaponir-lfm-senior-log.py'
senior = runpy.run_path(str(SENIOR_SCRIPT))
read, large = senior['read'], senior['large']
WORK, RUNTIME, ROOT, LOG = (senior[k] for k in ('WORK', 'RUNTIME', 'ROOT', 'LOG'))
OUTPUT = WORK / 'log-instructions'
MODELS = (senior['LFM26'], senior['LFM8'])
ADDENDUM = (' For application logs, include non-public service and host names, user handles, '
            'opaque customer or internal identifiers, and private local file paths. Copy the complete '
            'value from input.source, including the whole path when it is a path. List each distinct '
            'qualifying value once. Field labels and public infrastructure terms stay excluded.')


def measure(model, cpus):
    os.sched_setaffinity(0, cpus)
    fixture = read(OUTPUT / 'plan.json')
    sources, private, public, pool = large['corpus']()
    anchor = large['originals'](model, sources, fixture['binary_sha256'])
    model_file, model_bytes, model_sha, _ = anchor['artifact']
    weights = ROOT / 'models' / model_file
    require(weights.stat().st_size == model_bytes and file_sha(weights) == model_sha, 'probe_gguf_changed')
    profile = anchor['profile']
    prompt, _, kinds = prompts_and_kinds()
    require(prompt + ADDENDUM == fixture['prompt'], 'probe_prompt_changed')
    log_result = read(WORK / model / 'result.json')['same-four-fragments']
    reference_journal = WORK / model / 'same-four-fragments/transports.json'
    require(file_sha(reference_journal) == fixture['baseline_journals'][model], 'baseline_fragment_changed')
    expected_entry = read(reference_journal)['requests'][0]
    old_request = expected_entry['request']
    fragment = json.loads(old_request['messages'][-1]['content'])
    require(fragment == read(WORK / 'plan.json')['fragments'][0], 'first_fragment_changed')
    folder = OUTPUT / model
    response_dir = folder / 'fragment'
    response_dir.mkdir(parents=True)
    history = []
    with research_registration(model, catalog_for(model)), TemporaryDirectory(prefix='kaponir-lfm-log-prompt-') as temp:
        home = Path(temp)
        worker = Worker(home, configuration(home, {'model_dir': str(ROOT / 'models'), 'runtime': str(RUNTIME),
            'threads': 2, 'ocr_timeout_seconds': profile['worker_configuration_timeout_seconds']}), 'unused')
        try:
            sampling = {k: profile[k] for k in ('temperature', 'top_p', 'top_k', 'min_p', 'seed')}
            client = senior['SameFragmentClient'](worker, model, profile['context_tokens'], profile['output_tokens'],
                profile['response_format'], sampling, profile, response_dir, history)
            client.fragment_context = fragment['context']
            client.measurement_stage = expected_entry['record']['measurement_stage']
            args = Namespace(**profile, candidate_mode='typed', strategy='fixed', target_input_tokens=0,
                              fixed_bytes=len(fragment['source'].encode()), fixed_overlap_bytes=0)
            print(model, 'log instructions running', flush=True)
            part = discover(client, fragment['source'], fixture['prompt'], kinds, args, client.save_history)
            require(len(history) == 1 and not part['errors'], 'probe_fragment_incomplete')
            received = history[0]
            expected = {**old_request, 'messages': [
                {**old_request['messages'][0], 'content': fixture['prompt']},
                *old_request['messages'][1:],
            ]}
            require(received['request'] == expected, 'probe_changed_more_than_system_instruction')
            record = received['record']
            part.update(requests=1, input_tokens=record['input_tokens'],
                        reasoning_tokens=[record['reasoning_text_tokens']],
                        output_tokens=[record['usage']['completion_tokens']],
                        http_seconds=record['http_wall_seconds'],
                        candidate_ceiling_hit=record['candidate_count'] >= profile['max_candidates'])
        finally:
            worker.stop_runtime()
    fragments = {**log_result['fragments'], '1': part}
    variant = {**log_result['discovery'], LOG: senior['sum_fragments'](fragments)}
    results = large['apply_stage'](model, 'log-instructions-first-fragment', variant, sources, private, public, pool,
                                   anchor['source_sha256'], folder)
    atomic_json(folder / 'result.json', {'fragment': 1, 'probe': part, **results})
    print(model, 'applied, log fully covered', results['application'][LOG]['private_spans_fully_covered'], flush=True)


def run():
    require(not OUTPUT.exists(), 'existing_log_instruction_probe')
    plan = read(WORK / 'plan.json')
    previous = read(WORK / 'summary.json')
    require(not any(previous['exit_codes'].values()) and previous['plan_sha256'] == file_sha(WORK / 'plan.json')
            and plan['binary_sha256'] == file_sha(senior['BINARY'])
            and plan['runtime_sha256'] == file_sha(RUNTIME), 'reference_artifacts_changed')
    prompt, _, _ = prompts_and_kinds()
    slots = plan['cpu_affinities']
    with SuiteLock(ROOT / '.native-retest.lock'):
        require(not runtime_processes(RUNTIME), 'runtime_already_active')
        atomic_json(OUTPUT / 'plan.json', {'fragment': 1, 'prompt': prompt+ADDENDUM,
            'binary_sha256': plan['binary_sha256'], 'script_sha256': file_sha(Path(__file__)),
            'baseline_journals': {model:file_sha(WORK / model / 'same-four-fragments/transports.json')
                                  for model in MODELS}, 'comparison': 'change only the system instruction'})
        commands = [[sys.executable, '-Bu', __file__, '--model', model,
                     '--cpus', ','.join(map(str, slots[i % len(slots)]))] for i, model in enumerate(MODELS)]
        if len(slots) >= 2:
            children = [subprocess.Popen(command) for command in commands]
            codes = [child.wait() for child in children]
        else:
            codes = [subprocess.run(command, check=False).returncode for command in commands]
        require(not runtime_processes(RUNTIME), 'runtime_not_cleaned_up')
    results = {m:read(OUTPUT/m/'result.json') for m in MODELS if (OUTPUT/m/'result.json').is_file()}
    atomic_json(OUTPUT / 'summary.json', {'models': results, 'exit_codes': dict(zip(MODELS, codes, strict=True))})
    print('Instruction probes finished', dict(zip(MODELS, codes, strict=True)), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('--model')
    parser.add_argument('--cpus')
    args = parser.parse_args()
    if args.model:
        measure(args.model, [int(x) for x in args.cpus.split(',')])
    else:
        run()
