"""One adding-search request per profile and document in the Kaponir retest."""

import argparse
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
from tempfile import TemporaryDirectory
import time

from apply_measured_privacy import apply_documents
from evaluate_model_schemes import MeasuredClient, scheme_profile
from evaluate_privacy_policy import RUNTIME_SHA256
from evaluate_validation_schemes import detector_pool_from_export
from experiment_inference import discover, extraction_schema, prompts_and_kinds, sampling_settings
from kaponir_worker import Worker, configuration, http_json
from native_model_profiles import MODEL_ORDER, catalog_for, thought_text
from native_retest_baselines import base_scheme_source
from privacy_expansion_profiles import research_registration
from recover_privacy_transport import wait_for_verified_model
from run_native_model_retest import DEFAULT_STUDY
from run_privacy_policy_suite import SuiteLock, atomic_json, file_sha, runtime_processes
from scheme_reference import profile_from_reference, reference
from summarize_privacy_policy import require, strict_json


HERE = Path(__file__).resolve().parent
PILOT = HERE / 'kaponir-hybrid-pilot'
PREVIOUS = PILOT / 'fresh-lfm12'
OUTPUT = PILOT / 'fresh-matrix'
ROOT = DEFAULT_STUDY
RUNTIME = ROOT / 'runtime/llama-b12038/llama-server'
BINARY = ROOT / 'build/release/kaponir'
PREVIOUS_SCRIPT = HERE / 'check-kaponir-lfm12-fresh.py'
LFM12, LFM8 = 'lfm2.5-1.2b-instruct', 'lfm2.5-8b-a1b'
HEAVY = {'spark-x2.6-4b', 'gemma4-e4b-qat', 'gemma4-e4b-it-q4km'}
QUEUE = ('spark-x2.6-4b', 'gemma4-e4b-qat', 'gemma4-e4b-it-q4km',
         'lfm2.5-8b-a1b', 'lfm2.5-2.6b', 'qwen3.5-4b', 'tiny-aya-global')
REQUEST_TIMEOUT = 300


def read(path):
    return strict_json(Path(path).read_text())


def recorded_profile(path, model):
    plan_path = path.with_name('scheme-plan.json')
    journal_path = path.with_name('transports.json')
    plan, state, journal = read(plan_path), read(path), read(journal_path)
    prompt, _, kinds = prompts_and_kinds()
    request = next(row['request'] for row in journal['requests']
                   if row['record']['measurement_stage'].startswith('discovery:'))
    settings = plan['profile']
    require(state['status'] == 'completed' and model == plan['model'] == journal['model']
            and settings == journal['profile']
            and state['transport_journal_sha256'] == file_sha(journal_path),
            'recorded_profile_mismatch')
    require(plan['expected_runtime_sha256'] == RUNTIME_SHA256
            and request['messages'][0]['content'] == prompt
            and request['response_format']['json_schema']['schema'] ==
                extraction_schema(kinds, 'typed', settings['max_candidates']),
            'recorded_extraction_protocol_mismatch')
    return {'settings': settings, 'artifact': plan['model_artifact'], 'source': str(plan_path),
            'plan_sha256': file_sha(plan_path), 'journal_sha256': file_sha(journal_path),
            'recorded_request': request, 'historical_adding_search': True}


def profiles_for_run(model):
    native = recorded_profile(ROOT / 'schemes' / model / 'result.json', model)
    path, archived = base_scheme_source(ROOT, model)
    if path is not None and not archived:
        original = recorded_profile(path, model)
        require(original['artifact'] == native['artifact'], 'profile_artifact_mismatch')
    else:
        settings = scheme_profile(model, 'common', catalog_for(model))
        binding = profile_from_reference(settings, 'gemma4-e4b-qat')
        state, _ = reference('gemma4-e4b-qat')
        require(state['signature']['runtime_sha256'] == RUNTIME_SHA256, 'original_runtime_mismatch')
        if path is not None:
            require(state['signature']['artifact'] == native['artifact'], 'qat_original_artifact_mismatch')
        original = {'settings': settings, 'artifact': native['artifact'], 'source': binding,
                    'historical_adding_search': path is not None}
    return {'original': original, 'recommended': native}


class ShortClient(MeasuredClient):
    def __init__(self, worker, model, profile, folder):
        self.worker, self.model = worker, model
        self.context_tokens, self.output_tokens = profile['context_tokens'], profile['output_tokens']
        self.profile, self.output, self.history = profile, folder, []
        self.records, self.planning_schema = [], {}
        self.sampling = sampling_settings({k: profile[k] for k in
                                          ('temperature', 'top_p', 'top_k', 'min_p', 'seed')})
        wait_for_verified_model(worker, model, timeout=120)
        job = worker.submit('evaluate', model=model)
        worker.start_runtime(job['id'], model, 1, context_tokens=self.context_tokens,
            reasoning=profile['reasoning'], reasoning_format=profile['reasoning_format'],
            reasoning_budget=profile['reasoning_budget'])
        require(worker.process_supports_json_schema is True, 'pilot_requires_archived_schema_format')
        self.output_mode = 'grammar' if profile['response_format'] == 'auto' else profile['response_format']
        rendered = http_json(worker.ocr_base + '/apply-template', {
            'messages': [{'role': 'user', 'content': 'Public reference text. Return JSON.'}],
            'chat_template_kwargs': profile['template_kwargs'], 'add_generation_prompt': True})['prompt']
        self.template_probe = {'requested': profile['template_kwargs'],
                               'ends_with_think_prefix': rendered.rstrip().endswith('<think>')}

    def infer(self, prompt, value, schema, output_tokens):
        # Preserve legacy off requests even when the template forces reasoning.
        # Keep a failed response as evidence instead of retrying other fragments.
        try:
            return self.one(prompt, value, schema, output_tokens)
        except json.JSONDecodeError as exc:
            raise ValueError('invalid_json_from_model') from exc
        except ValueError as exc:
            if str(exc) == 'model_response_truncated':
                raise ValueError('truncated_single_request') from exc
            raise


def measure(model, label, reference_profile, fixture, folder):
    folder.mkdir(parents=True, exist_ok=False)
    profile = {**reference_profile['settings'], 'transport_timeout_seconds': REQUEST_TIMEOUT}
    settings = argparse.Namespace(**{**profile, 'max_fragments': 1},
                                  candidate_mode='typed', strategy='auto', target_input_tokens=0)
    prompt, _, kinds = prompts_and_kinds()
    outcomes = {}
    with TemporaryDirectory(prefix='kaponir-matrix-') as location:
        home = Path(location)
        worker = Worker(home, configuration(home, {'model_dir': str(ROOT / 'models'), 'runtime': str(RUNTIME),
            'threads': 2, 'ocr_timeout_seconds': REQUEST_TIMEOUT}), 'unused')
        try:
            client = ShortClient(worker, model, profile, folder)
            for name, text in fixture['sources'].items():
                client.measurement_stage = f'discovery:{name}'
                start = len(client.history)
                print(model, label, name, 'running', flush=True)
                try:
                    stage = discover(client, text, prompt, kinds, settings, client.save_history)
                except ValueError as exc:
                    if str(exc) != 'document_fragment_limit':
                        raise
                    stage = {'values': [], 'errors': [{'code': 'single_request_fragment_limit'}]}
                entries = client.history[start:]
                require(len(entries) <= 1, 'unexpected_pilot_retry')
                entry = entries[0] if entries else {}
                record = entry.get('record', {})
                request = entry.get('request', {})
                if request:
                    expected = reference_profile.get('recorded_request')
                    require(json.loads(request['messages'][-1]['content'])['source'] == text,
                            'pilot_document_not_sent_whole')
                    if expected:
                        require({k: v for k, v in request.items() if k != 'messages'} ==
                                {k: v for k, v in expected.items() if k != 'messages'}
                                and request['messages'][0] == expected['messages'][0],
                                'request_settings_changed')
                response = entry.get('raw_reply', {})
                choice = next(iter(response.get('choices', [])), {})
                usage = response.get('usage') or {}
                thought = thought_text(choice.get('message', {}))
                reasoning = record.get('reasoning_text_tokens', 0) or (client.token_count(thought) if thought else 0)
                values = {row['value'] for row in stage['values']}
                outcome = {**stage, 'ok': len(entries) == 1 and not stage['errors']
                    and record.get('finish_reason') == 'stop' and not record.get('error'),
                    'requests': len(entries), 'http_seconds': record.get('http_wall_seconds'),
                    'finish_reason': choice.get('finish_reason'), 'parse_error': entry.get('parse_error'),
                    'input_tokens': usage.get('prompt_tokens'), 'output_tokens': usage.get('completion_tokens'),
                    'reasoning_tokens': reasoning, 'template_requested_off_still_thinks': (
                        not profile['template_kwargs']['enable_thinking'] and
                        (client.template_probe['ends_with_think_prefix'] or reasoning > 0)),
                    'returned_literal_private': len(values.intersection(fixture['private_values'][name])),
                    'returned_literal_public': len(values.intersection(fixture['public_values'][name])),
                    'rejected_or_duplicate_candidates': record.get('candidate_count', 0) -
                        record.get('unique_grounded_count', 0)}
                outcomes[name] = outcome
                atomic_json(folder / 'discovery.json', outcomes)
                print(model, label, name, 'ok' if outcome['ok'] else 'failed',
                      round(outcome['http_seconds'] or 0, 2), outcome['finish_reason'], flush=True)
        finally:
            worker.stop_runtime()
    return outcomes


def apply(model, fixture, folder, evidence, pool, select):
    masks, outcomes = {}, {}
    for label, docs in evidence.items():
        successful = {name: value for name, value in docs.items() if value['ok']}
        selected = select(pool, successful)
        masks[label] = {name: selected.get(name, []) for name in successful}
        outcomes[label] = successful
    route = fixture['route']
    masks['hybrid'] = {name: masks[label][name] for name, label in route.items() if name in masks[label]}
    outcomes['hybrid'] = {name: evidence[label][name] for name, label in route.items() if name in masks['hybrid']}
    atomic_json(folder / 'selected-masks.json', masks)
    applications = {}
    for label, selected in masks.items():
        if not selected:
            applications[label] = {'documents': {}, 'exact_roundtrips': 0}
            continue
        sources = {name: fixture['sources'][name] for name in selected}
        hashes = {name: fixture['source_sha256'][name] for name in selected}
        report = apply_documents(BINARY, folder / f'apply-{label}', hashes, sources, fixture['private_values'],
            fixture['public_values'], selected, {'model': model, 'variant': label, 'stage': 'current_union'})
        rows = {row['file']: row for row in report['documents'] if row['mode'] == 'model_masks_added'}
        complete = len(rows) == len(fixture['sources'])
        applications[label] = {'documents': rows, 'exact_roundtrips': report['exact_roundtrips'],
            'complete': complete, 'http_seconds': (sum(row['http_seconds'] for row in outcomes[label].values())
                if complete else None)}
    for name, row in applications['hybrid']['documents'].items():
        require(row == applications[route[name]]['documents'][name], 'hybrid_effect_changed')
    return applications


def run_model(model, cpus):
    os.sched_setaffinity(0, cpus)
    root_plan = read(OUTPUT / 'plan.json')
    fixture = root_plan['fixture']
    folder = OUTPUT / model
    folder.mkdir(exist_ok=False)
    profiles = root_plan['profiles'][model]
    model_file, expected_size, expected_sha, _ = profiles['recommended']['artifact']
    model_path = ROOT / 'models' / model_file
    require(model_path.stat().st_size == expected_size and file_sha(model_path) == expected_sha,
            'pilot_model_checksum_mismatch')
    prior_script = runpy.run_path(str(PREVIOUS_SCRIPT))
    require(prior_script['SOURCES'] == fixture['sources'], 'fixture_producer_changed')
    pool, _ = detector_pool_from_export(read(PREVIOUS / 'detectors.json'), fixture['sources'])
    with research_registration(model, catalog_for(model)):
        evidence = {label: measure(model, label, setting, fixture, folder / label)
                    for label, setting in profiles.items()}
    for name in fixture['sources']:
        requests = [
            next((row for row in read(folder / label / 'transports.json')['requests']
                  if row['record']['measurement_stage'] == f'discovery:{name}'), None)
            for label in profiles if (folder / label / 'transports.json').is_file()
        ]
        if len(requests) == 2 and all(requests):
            first, second = requests
            require(first['request']['messages'] == second['request']['messages']
                    and first['request']['response_format'] == second['request']['response_format'],
                    'paired_prompt_or_schema_differs')
    result = {'model': model, 'status': 'completed', 'cpu_affinity': cpus,
              'measurement_requests': sum(row['requests'] for docs in evidence.values() for row in docs.values()),
              'historical_adding_search': profiles['original']['historical_adding_search'],
              'measurements': evidence, 'applications': apply(model, fixture, folder, evidence, pool,
                                                             prior_script['select_search_masks'])}
    atomic_json(folder / 'result.json', result)
    print(model, 'application checked', flush=True)


def run_matrix():
    require(not OUTPUT.exists(), 'matrix_output_exists')
    fixture = read(PREVIOUS / 'plan.json')
    require(fixture['script_sha256'] == file_sha(PREVIOUS_SCRIPT)
            and fixture['runtime_sha256'] == file_sha(RUNTIME) == RUNTIME_SHA256
            and fixture['binary_sha256'] == file_sha(BINARY), 'known_pilot_or_binary_changed')
    original = read(PREVIOUS / 'summary.json')
    require(original['status'] == 'completed' and original['model'] == LFM12
            and original['model_requests'] == 4, 'previous_lfm12_pilot_incomplete')
    workload = list(QUEUE)
    require(set(workload) == set(MODEL_ORDER) - {LFM12}, 'matrix_bucket_incomplete')
    cores = sorted(os.sched_getaffinity(0))
    require(len(cores) >= 2, 'pilot_requires_two_cores')
    slots = [cores[offset:offset+2] for offset in range(0, min(len(cores), 4) - 1, 2)]
    plan = {'fixture': fixture, 'source_fixture': str(PREVIOUS / 'plan.json'),
            'detector_export_sha256': file_sha(PREVIOUS / 'detectors.json'),
            'profiles': {model: profiles_for_run(model) for model in MODEL_ORDER},
            'order': MODEL_ORDER, 'request_timeout_seconds': REQUEST_TIMEOUT,
            'parallel_cpu_affinities': slots, 'one_measured_request_per_document_and_profile': True}
    with SuiteLock(ROOT / '.native-retest.lock'):
        require(not runtime_processes(RUNTIME), 'model_runtime_already_running')
        atomic_json(OUTPUT / 'plan.json', plan)
        workers, errors = {}, {}
        while workload or workers:
            for index, (model, process) in list(workers.items()):
                status = process.poll()
                if status is not None:
                    if status:
                        errors[model] = status
                    del workers[index]
            for index, cpus in enumerate(slots):
                if index in workers:
                    continue
                active = {entry[0] for entry in workers.values()}
                candidates = [model for model in workload
                              if not (model == LFM8 and active & HEAVY or model in HEAVY and LFM8 in active)]
                if candidates:
                    model = candidates[0]
                    workload.remove(model)
                    process = subprocess.Popen([sys.executable, '-Bu', __file__, '--model', model,
                                                '--cpus', ','.join(map(str, cpus))])
                    workers[index] = (model, process)
            if workers:
                time.sleep(1)
        require(not runtime_processes(RUNTIME), 'pilot_runtime_cleanup_failed')
    results = {LFM12: {**original, 'reused_verified_fresh_measurement': True,
                       'measurement_requests': original['model_requests'], 'historical_adding_search': True}}
    for model in QUEUE:
        path = OUTPUT / model / 'result.json'
        if path.is_file():
            results[model] = read(path)
    atomic_json(OUTPUT / 'summary.json', {'status': 'completed' if not errors else 'partial',
        'models': results, 'process_errors': errors, 'matrix_profile_plan_sha256': file_sha(OUTPUT / 'plan.json')})
    print('matrix complete', len(results), 'models', 'worker errors', errors, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--model')
    parser.add_argument('--cpus')
    args = parser.parse_args()
    if args.model:
        run_model(args.model, [int(cpu) for cpu in args.cpus.split(',')])
    else:
        run_matrix()
