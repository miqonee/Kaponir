"""Replay the same LFM holdout outputs with a literal same-document context rule."""

from copy import deepcopy
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import runpy
import tarfile

from jsonschema import Draft202012Validator
from evaluate_validation_schemes import detector_pool_from_export
from run_privacy_policy_suite import atomic_json, file_sha
from summarize_privacy_policy import strict_json

HERE = Path(__file__).resolve().parent
ROOT = Path('/workspace/Kaponir')
PILOT = HERE/'kaponir-hybrid-pilot'
OBS = PILOT/'lfm-final-speed-v1'
OUT = PILOT/'lfm-context-grounding-v1'
PRIOR = ROOT/'research/privacy-policy-phase2/checkpoints/lfm-cpu-latency'
DEST = ROOT/'research/privacy-policy-phase2/checkpoints/lfm-context-grounding'
SIZES = ('12','26','8')


def read(path):
    return strict_json(path.read_text())


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def skinny(row):
    return {k:row[k] for k in ('private_spans_fully_covered','private_spans_partly_covered','private_spans_untouched','public_occurrences_lost','replacements')}


def main():
    os.sched_setaffinity(0, sorted(os.sched_getaffinity(0))[:1])
    manifest=read(PRIOR/'manifest.json')
    assert file_sha(PRIOR/'evidence.tar.gz')==manifest['archive']['sha256']
    with tarfile.open(PRIOR/'evidence.tar.gz') as tar:
        src={f.name:tar.extractfile(f).read() for f in tar.getmembers() if f.isfile()}
    json_member=lambda n:strict_json(src[n].decode())
    plan=read(OBS/'plan.json')
    assert file_sha(OBS/'holdout-detectors.json')==plan['holdout_export_sha256']
    labels=json_member('measurement/annotations.json')
    documents=plan['holdout_sources']
    assert all(labels['sources'][k]==t for k,t in documents.items())
    private={k:labels['private'][k] for k in documents};public={k:labels['public'][k] for k in documents}
    pool,_=detector_pool_from_export(read(OBS/'holdout-detectors.json'),documents)
    hashes={k:sha(t.encode()) for k,t in documents.items()}
    large=runpy.run_path(str(HERE/'check-kaponir-lfm-large.py'))
    senior=runpy.run_path(str(HERE/'check-kaponir-lfm-senior-log.py'))
    assert file_sha(large['BINARY'])==manifest['application_sha256']
    OUT.mkdir()
    rule={'archive_sha256':file_sha(PRIOR/'evidence.tar.gz'),'source_sha256':hashes,'detector_sha256':plan['holdout_export_sha256'],
          'binary_sha256':manifest['application_sha256'],'producer_sha256':file_sha(Path(__file__)),
          'new_inference_calls':0,'profiles':list(SIZES),
          'change':'Add a previously rejected candidate only if explicitly returned in a schema-valid row, it is literal in the context sent for that request and in the same full source document, and passes the existing length/whitespace checks. No help from annotations.'}
    atomic_json(OUT/'plan.json',rule)
    compared={};messages={};summary={}
    for key in SIZES:
        profile=key+'-fresh-reference-2t'
        meta=manifest['verified_profiles'][profile]
        model=meta['settings']['model']
        start='runs/'+profile+'/'
        frags=json_member(start+'fragments.json')
        original={doc:senior['sum_fragments'](parts) for doc,parts in frags.items()}
        improved=deepcopy(original); additions={doc:{} for doc in documents}
        unique={doc:{r['value'] for r in v['values']} for doc,v in original.items()}
        requests={}
        for filename in sorted(f for f in src if f.startswith(start+'journal-') and f.endswith('.json')):
            for row in json_member(filename)['requests']:
                stage=row['record']['measurement_stage']; doc=stage.split(':')[1]
                req=row['request']; user=json.loads(req['messages'][-1]['content'])
                sliced,context=user['source'],user['context']
                assert sliced in documents[doc] and isinstance(context,str)
                requests[stage]=(req['messages'],req['response_format'],req['max_tokens'],req['seed'])
                schema=req['response_format']['json_schema']['schema']['properties']['candidates']['items']
                validator=Draft202012Validator(schema)
                for candidate in strict_json(row['raw_reply']['choices'][0]['message']['content'])['candidates']:
                    val=candidate.get('value')
                    if not validator.is_valid(candidate) or len(val.encode()) not in range(3,513) or val.strip()!=val:
                        continue
                    if val in sliced or val not in context or val not in documents[doc] or val in unique[doc]:
                        continue
                    additions[doc].setdefault(val,candidate)
        if messages: assert requests==messages
        else:messages=requests
        for doc,extra in additions.items():
            improved[doc]['values'].extend(extra.values())
        comparison={}
        for label,data in [('original',original),('literal-in-context',improved)]:
            result=large['apply_stage'](model,label,data,documents,private,public,pool,hashes,OUT/profile/label)
            assert result['exact_roundtrips']==4
            score={doc:skinny(d) for doc,d in result['application'].items()}
            if label=='original':assert score=={doc:skinny(meta['documents'][doc]) for doc in documents}
            comparison[label]=score
        compared[model]={'source_profile':profile,'added_literals':{doc:list(vals) for doc,vals in additions.items()},'applications':comparison}
        for label,ds in comparison.items():
            summary.setdefault(model,{})[label]={'private_full':sum(d['private_spans_fully_covered'] for d in ds.values()),
                'public_lost':sum(d['public_occurrences_lost'] for d in ds.values()),
                'guide_replacements':ds['public-protocol-guide.log']['replacements']}
        print(model,summary[model],compared[model]['added_literals'],flush=True)
    atomic_json(OUT/'comparison.json',{'plan_sha256':file_sha(OUT/'plan.json'),'results':compared,'summary':summary,'exact_restores':24,'new_inference_calls':0})
    files={'plan.json':(OUT/'plan.json').read_bytes(),'comparison.json':(OUT/'comparison.json').read_bytes(),'producer.py':Path(__file__).read_bytes()}
    for p in OUT.glob('*/*/apply/result.json'): files[str(p.relative_to(OUT))]=p.read_bytes()
    for pattern in ('*/*/apply/*/*/mask.json','*/*/apply/*/*/restore.json'):
        for p in OUT.glob(pattern):files[str(p.relative_to(OUT))]=p.read_bytes()
    assert len(files)==57
    buf=io.BytesIO()
    with gzip.GzipFile(fileobj=buf,filename='',mode='wb',mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w') as tar:
            for name,data in sorted(files.items()):
                f=tarfile.TarInfo(name);f.size=len(data);f.mode=0o644;tar.addfile(f,io.BytesIO(data))
    packed=buf.getvalue();DEST.mkdir(parents=True,exist_ok=False)
    (DEST/'evidence.tar.gz').write_bytes(packed)
    atomic_json(DEST/'comparison.json',{'source_evidence_sha256':rule['archive_sha256'],'archive_sha256':sha(packed),'members':len(files),
        **read(OUT/'comparison.json')})
    print('verified and archived',len(files),'files, 24 exact restores',flush=True)


if __name__=='__main__': main()
