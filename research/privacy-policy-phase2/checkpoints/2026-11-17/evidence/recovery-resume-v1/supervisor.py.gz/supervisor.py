"""Restore the interrupted serial queue without editing frozen producers."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
config = json.loads((ROOT / 'resume-manifest.json').read_text())
sys.path.insert(0, str(Path(config['driver_root']) / 'scripts'))
from run_privacy_policy_suite import SuiteLock, atomic_json, process_identity, runtime_processes, utc


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_inputs():
    for path, expected in config['immutable_files_sha256'].items():
        require(sha(path) == expected, 'resume_input_changed:' + path)


verify_inputs()
require(not (ROOT / 'supervisor-status.json').exists(), 'supervisor_already_attempted_inspect_before_restart')
require(not runtime_processes(config['runtime']), 'runtime_busy_no_parallel_inference')
previous = json.loads(Path(config['previous_status_snapshot']).read_text())
state = copy.deepcopy(previous)
state.update(status='running', controller_pid=__import__('os').getpid(),
             resumed_at_utc=utc(), resume_manifest_sha256=sha(ROOT / 'resume-manifest.json'),
             resume_boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
             previous_controller=previous.get('controller_pid'), runs=config['canonical_rows'])
status_path = Path(config['status_alias'])


def save():
    atomic_json(ROOT / 'supervisor-status.json', state)
    atomic_json(status_path, state)


with SuiteLock(status_path.parent / '.queue.lock'), SuiteLock(Path(config['original_suite']) / '.suite.lock'):
    try:
        save()
        for job in config['jobs']:
            verify_inputs()
            require(not runtime_processes(config['runtime']), 'runtime_busy_no_parallel_inference')
            row = state['runs'][job['index']]
            row.update(status='launching', command=job['command'], started_at_utc=utc())
            state['current_job'] = job['id']
            save()
            log_path = ROOT / (job['id'] + '.log')
            with log_path.open('a') as log:
                child = subprocess.Popen(job['command'], stdin=subprocess.DEVNULL,
                                         stdout=log, stderr=subprocess.STDOUT, start_new_session=True,
                                         cwd=config['repository'])
                row.update(status='running', pid=child.pid, identity=process_identity(child.pid), log=str(log_path))
                save()
                code = child.wait()
            row.update(status='completed' if code == 0 else 'failed', exit_code=code, finished_at_utc=utc())
            save()
            require(not runtime_processes(config['runtime']), 'child_did_not_release_runtime')
        state.update(status='completed_with_failures' if any(row.get('exit_code', 0) for row in state['runs'])
                     else 'completed', finished_at_utc=utc(), current_job=None)
    except BaseException as exc:
        state.update(status='blocked', error=type(exc).__name__, reason=str(exc)[:200])
        raise
    finally:
        save()
