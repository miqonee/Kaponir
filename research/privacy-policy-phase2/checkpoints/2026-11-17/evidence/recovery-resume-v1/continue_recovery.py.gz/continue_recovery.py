"""Continue interrupted read-only inference, retaining confirmed raw responses.

The old checkpoint is immutable. An unfinished send stays unobserved in the
lineage; an explicitly scheduled new attempt never becomes its old response.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--driver-root', type=Path, required=True)
    parser.add_argument('--reader-root', type=Path, required=True)
    parser.add_argument('--parent-result', type=Path, required=True)
    parser.add_argument('--old-pid', type=int, required=True)
    parser.add_argument('--old-start', type=int, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--model-dir', type=Path, required=True)
    parser.add_argument('--runtime', type=Path, required=True)
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    sys.path.insert(0, str(args.driver_root / 'scripts'))
    import recover_privacy_transport as driver
    require(Path(driver.__file__).resolve() == (args.driver_root / 'scripts/recover_privacy_transport.py').resolve(),
            'wrong_frozen_driver')
    identity = driver.process_identity(args.old_pid)
    require(not identity or identity['start_ticks'] != args.old_start or identity['state'] == 'Z',
            'old_measurement_owner_still_alive')
    require(not driver.runtime_processes(args.runtime), 'runtime_busy_no_parallel_inference')
    parent = args.parent_result.resolve()
    parent_plan_path = parent.with_name('recovery-plan.json')
    raw, plan_raw = parent.read_bytes(), parent_plan_path.read_bytes()
    parent_state = driver.strict_json(raw.decode())
    parent_plan = driver.strict_json(plan_raw.decode())
    require(parent_state['status'] in ('running', 'failed'), 'parent_is_not_an_interrupted_supplement')
    # Validate in a separate interpreter, preserving the original producer's
    # module namespace for the actual evaluator and Worker below.
    check = ("import sys,json;sys.path.insert(0,sys.argv[1]);"
             "from summarize_privacy_recovery import load_supplement;"
             "r=load_supplement(sys.argv[2]);"
             "print(json.dumps({'sha':r['result_sha256'],'batches':len(r['supplement_batches'])}))")
    verified = subprocess.run([sys.executable, '-c', check, str(args.reader_root / 'scripts'), str(parent)],
                              capture_output=True, text=True, check=True)
    proof = json.loads(verified.stdout)
    require(proof['sha'] == hashlib.sha256(raw).hexdigest() == sha(parent), 'parent_changed_during_validation')
    require(sha(parent_plan_path) == hashlib.sha256(plan_raw).hexdigest(), 'parent_plan_changed')
    completed = {(row['variant'], row['batch_index']): row for row in parent_state['batches']}
    require(len(completed) == proof['batches'], 'duplicate_parent_batches')
    cached, unobserved = {}, []
    for key in parent_state['calls']:
        entry = parent_state['responses'][key]
        pair = entry['variant'], entry['batch_index']
        if pair in completed:
            require(pair not in cached and entry['status'] != 'pending', 'ambiguous_confirmed_parent_response')
            cached[pair] = key, copy.deepcopy(entry)
        else:
            require(entry['status'] == 'pending' and 'raw_transport' not in entry,
                    'unscored_received_parent_requires_separate_inspection')
            unobserved.append({'response_key': key, 'entry': copy.deepcopy(entry),
                               'previous_outcome': 'unobserved_after_environment_restart'})
    require(set(cached) == set(completed), 'parent_scored_response_missing')
    original_make = driver.make_recovery_plan
    base = original_make(parent_plan['original_result_path'], parent_plan['producer_root'],
                         parent_plan['client_timeout_seconds'])
    for field in ('requests', 'original_signature', 'original_result_sha256', 'original_plan_file_sha256',
                  'original_template_probe', 'original_control_cases', 'original_runtime_libraries'):
        require(base[field] == parent_plan[field], 'continuation_contract_changed:' + field)
    selected = {(row['variant'], row['batch_index']): row for row in base['requests']}
    require(set(cached) < set(selected), 'no_requests_left_to_continue')
    core = driver.load_producer(base['producer_root'])
    _, expected, _, sources, _ = core.load_corpus()
    from validation_pipeline import Candidate
    cases = [Candidate(**row) for row in base['original_control_cases']['candidates']]
    by_id = {case.id: case for case in cases}
    kinds = core.prompts_and_kinds()[2]
    # Replay only parsing and grading, never inference, before admitting any
    # inherited response into the new checkpoint.
    for pair, (_, entry) in cached.items():
        spec = selected[pair]
        require(entry['request'] == spec['request'], 'inherited_request_changed')
        batch = [by_id[ident] for ident in spec['case_ids']]
        reply, error = core.parse_response(entry)
        contexts = core.payload(pair[0], batch, sources)[1]
        decisions = ({case.id: core.technical_review(case, error) for case in batch} if error else
                     core.validate(reply, batch, contexts, kinds, pair[0]))
        require(decisions == completed[pair]['decisions'] and
                core.metrics(batch, decisions, expected, pair[0] != 'D') == completed[pair]['metrics_selected_cases_only'],
                'inherited_grade_changed')
    args.output.mkdir(parents=True, exist_ok=True)
    backup = args.output / 'continuation-source'
    backup.mkdir(exist_ok=True)
    for name, data in [('recovery-result.json', raw), ('recovery-plan.json', plan_raw)]:
        target = backup / name
        require(not target.exists() or target.read_bytes() == data, 'continuation_backup_changed')
        if not target.exists():
            target.write_bytes(data)
    metadata = {'adapter_path': str(Path(__file__).resolve()), 'adapter_sha256': sha(__file__),
                'driver_root': str(args.driver_root.resolve()),
                'source_result_sha256': hashlib.sha256(raw).hexdigest(),
                'source_plan_sha256': hashlib.sha256(plan_raw).hexdigest(),
                'source_relative_directory': 'continuation-source',
                'reused_confirmed_batches': [list(pair) for pair in cached],
                'new_request_batches': [list(pair) for pair in selected if pair not in cached],
                'prior_unobserved_attempts': unobserved,
                'old_owner': {'pid': args.old_pid, 'start_ticks': args.old_start},
                'resume_boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
                'previous_hardware': parent_state.get('hardware'),
                'previous_runtime_starts': parent_state.get('runtime_starts', []),
                'resource_cost_unknown_variants': sorted({row['entry']['variant'] for row in unobserved}),
                'selection_uses_quality': False, 'received_failures_retried': 0}

    def make(*values):
        result = original_make(*values)
        result.pop('recovery_plan_sha256')
        result['continuation_execution'] = metadata
        result['recovery_plan_sha256'] = driver.digest(result)
        return result

    original_perform = core.perform_request
    reused = set()

    def perform(state, save, worker, settings, spec, output_tokens, input_tokens):
        pair = spec['variant'], spec['batch_index']
        if pair not in cached:
            return original_perform(state, save, worker, settings, spec, output_tokens, input_tokens)
        key, entry = cached[pair]
        require(pair not in reused and key not in state['responses'], 'confirmed_entry_reused_twice')
        reused.add(pair)
        state['responses'][key] = copy.deepcopy(entry)
        state['calls'].append(key)
        save()
        return state['responses'][key]

    original_save = driver.atomic_json

    def save(path, state):
        if Path(path).name == 'recovery-result.json':
            state['continuation_execution'] = metadata
            state['reused_transport_batches_without_inference'] = len(reused)
            for batch in state.get('batches', []):
                pair = batch['variant'], batch['batch_index']
                if pair in completed:
                    require(batch == completed[pair], 'confirmed_batch_modified_during_continuation')
            if state.get('status') == 'completed':
                require(reused == set(cached), 'confirmed_batch_not_preserved')
        original_save(path, state)

    driver.make_recovery_plan, driver.atomic_json, core.perform_request = make, save, perform
    run = argparse.Namespace(result=Path(base['original_result_path']), producer_root=Path(base['producer_root']),
                             timeout=base['client_timeout_seconds'], output=args.output,
                             model_dir=args.model_dir, runtime=args.runtime, prepare_only=args.prepare_only)
    driver.run_one(run)
    print(json.dumps({'status': 'prepared' if args.prepare_only else 'finished',
                      'confirmed_batches_reused': len(cached), 'new_request_batches': len(selected) - len(cached),
                      'prior_unobserved_attempts': len(unobserved), 'received_failures_retried': 0}), flush=True)


if __name__ == '__main__':
    main()
