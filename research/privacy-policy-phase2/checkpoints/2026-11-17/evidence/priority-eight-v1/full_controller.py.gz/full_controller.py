"""Serial reordered execution of the same 69 preregistered jobs, after the pilot."""
import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--config', type=Path, required=True)
parser.add_argument('--resume', action='store_true')
parser.add_argument('--check-only', action='store_true')
args = parser.parse_args();config = json.loads(args.config.read_text())
producer = Path(config['reader_root']);sys.path.insert(0, str(producer / 'scripts'))
from run_privacy_policy_suite import SuiteLock, atomic_json, file_sha, process_identity, runtime_processes, utc
from summarize_privacy_policy import require, strict_json
from run_privacy_pilot_suite import snapshot
from report_complete_research import write_reports
from report_policy_clarification import write_reports as policy_reports
import export_privacy_snapshot as snapshots

config_sha = file_sha(args.config)
snapshots.STUDY = HERE.parent
terminal = {'completed', 'completed_technical_incomplete', 'unavailable_context', 'failed'}


def guard():
    require(file_sha(Path(__file__)) == config['controller_sha256'], 'priority_controller_changed')
    require(file_sha(Path(config['adapter'])) == config['adapter_sha256'], 'priority_adapter_changed')
    require(file_sha(args.config) == config_sha, 'priority_configuration_changed')
    require(snapshot(producer) == config['reader_inputs_sha256'], 'priority_frozen_reader_changed')
    require(file_sha(Path(config['diagnostic_config'])) == config['diagnostic_config_sha256']
            and file_sha(Path(config['diagnostic_driver'])) == config['diagnostic_driver_sha256'],
            'registered_nanbeige_diagnostic_changed')
    for owner in config['owners'].values():
        require(file_sha(Path(owner['config'])) == owner['config_sha256'], 'original_owner_config_changed')
    paused = config['paused_recovery_supervisor'];actual = process_identity(paused['pid'])
    require(actual and actual['start_ticks'] == paused['start_ticks'] and actual['state'] == 'T',
            'old_recovery_supervisor_must_remain_paused')


def adapter_command(job):
    owner = config['owners'][job['owner']]
    return [sys.executable, '-u', config['adapter'], '--owner', job['owner'],
            '--config', owner['config'], '--config-sha256', owner['config_sha256'],
            '--job', job['job']['id'], '--scheduler-config', str(args.config.resolve()),
            '--scheduler-config-sha256', config_sha]


def save(status=None):
    if status:
        state['status'] = status
    state['updated_at_utc'] = utc();atomic_json(HERE / 'full-status.json', state)


def wait_child(row, child=None):
    while True:
        actual = process_identity(row['pid'])
        if actual and actual['state'] != 'Z':
            require(actual['start_ticks'] == row['start_ticks'], 'priority_child_pid_reused')
        if child is not None:
            try:
                code = child.wait(timeout=15);break
            except subprocess.TimeoutExpired:
                save();continue
        if not actual or actual['state'] == 'Z':
            code = None;break
        save();time.sleep(15)
    require(not runtime_processes(config['runtime']), 'priority_child_left_live_runtime')
    return code


def stop_idle_original_masters():
    state.setdefault('idle_owner_handoffs', {})
    for name, owner in config['owners'].items():
        if name in state['idle_owner_handoffs']:
            continue
        original = strict_json((Path(owner['output']) / 'status.json').read_text())
        require(not any(row.get('status') in ('running', 'launching') for row in original['jobs'].values()),
                'original_owner_has_active_measurement')
        backup = HERE / 'before-full-priority' / name / 'status.json';backup.parent.mkdir(parents=True, exist_ok=True)
        require(not backup.exists(), 'priority_owner_backup_exists_inspect_before_retry')
        backup.write_bytes((Path(owner['output']) / 'status.json').read_bytes())
        actual = process_identity(owner['old_pid'])
        signalled = False
        if actual and actual['start_ticks'] == owner['old_start_ticks'] and actual['state'] != 'Z':
            os.kill(owner['old_pid'], signal.SIGTERM);signalled = True
            deadline = time.monotonic() + 10
            while time.monotonic() < deadline:
                current = process_identity(owner['old_pid'])
                if not current or current['state'] == 'Z' or current['start_ticks'] != owner['old_start_ticks']:
                    break
                time.sleep(.05)
            current = process_identity(owner['old_pid'])
            require(not current or current['state'] == 'Z' or current['start_ticks'] != owner['old_start_ticks'],
                    'idle_original_owner_did_not_exit')
        state['idle_owner_handoffs'][name] = {'signalled': signalled, 'at_utc': utc(),
                                             'backup_sha256': file_sha(backup)};save()


def reports():
    complete = strict_json(Path(config['owners']['complete-v1']['config']).read_text())
    rows = {}
    for owner in config['owners'].values():
        rows.update(strict_json((Path(owner['output']) / 'status.json').read_text()).get('jobs', {}))
    jobs = [row['job'] for row in config['jobs']]
    settings = {**complete, 'output': str(HERE / 'full-research'), 'expected_models': config['expected_models'],
                'reference_recovery_output': str(Path(config['recovery_queue']).parent)}
    current = {'status': state['status'], 'jobs': rows}
    state['reports'] = write_reports(settings, current, jobs)
    state['policy_reports'] = policy_reports(
        {'output': str(HERE / 'full-policy-comparison'), 'expected_models': config['expected_models']},
        current, [row for row in jobs if row['kind'] == 'policy_clarification'])


if args.check_only:
    guard()
    for name, owner in config['owners'].items():
        selected = next(row for row in config['jobs'] if row['owner'] == name)
        checked = subprocess.run(adapter_command(selected) + ['--check-only'], capture_output=True, text=True)
        require(checked.returncode == 0, 'frozen_original_owner_check_failed:' + name + ':' + checked.stderr[-200:])
    print(json.dumps({'registered_jobs': len(config['jobs']), 'unchanged_commands': True,
                      'new_model_calls': 0, 'new_eight_jobs_first': config['new_eight_jobs_first']}));sys.exit(0)


with SuiteLock(HERE / '.full-priority.lock'):
    path = HERE / 'full-status.json'
    if path.exists():
        require(args.resume, 'existing_priority_queue_requires_explicit_resume')
        state = strict_json(path.read_text());require(state['config_sha256'] == config_sha, 'priority_config_changed')
        previous = state['controller'];actual = process_identity(previous['pid'])
        require(not actual or actual['state'] == 'Z' or actual['start_ticks'] != previous['start_ticks'],
                'previous_priority_controller_alive')
    else:
        state = {'config_sha256': config_sha, 'started_at_utc': utc(), 'jobs': {}, 'planned_jobs': len(config['jobs']),
                 'shadow': True, 'rules_changed': 0, 'new_eight_jobs_first': config['new_eight_jobs_first']}
    identity = process_identity(os.getpid());state['controller'] = {'pid': os.getpid(), 'start_ticks': identity['start_ticks']}
    try:
        guard();save('waiting_eight_model_pilot')
        while True:
            pilot_path = Path(config['pilot_status'])
            if pilot_path.exists():
                pilot = strict_json(pilot_path.read_text())
                require(pilot['status'] != 'blocked', 'pilot_blocked_inspect_before_full_study')
                if pilot['status'] in ('measurements_finished', 'measurements_finished_with_limitations'):
                    require(len(pilot['jobs']) == 8 and all(row['status'] in terminal for row in pilot['jobs'].values()),
                            'pilot_not_all_eight_attempted')
                    owner = pilot['controller'];actual = process_identity(owner['pid'])
                    if not actual or actual['state'] == 'Z' or actual['start_ticks'] != owner['identity']['start_ticks']:
                        break
            guard();save();time.sleep(15)
        if not state.get('idle_owner_handoffs'):
            require(not runtime_processes(config['runtime']), 'pilot_left_active_runtime')
        stop_idle_original_masters()
        if state.get('nanbeige_diagnostic', {}).get('status') != 'completed':
            diagnostic = state.get('nanbeige_diagnostic')
            if diagnostic is None:
                command = [sys.executable, '-u', config['diagnostic_driver'], '--config', config['diagnostic_config']]
                with (HERE / 'nanbeige-diagnostic.log').open('a') as log:
                    child = subprocess.Popen(command, cwd=producer, stdin=subprocess.DEVNULL,
                        stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                    identity = process_identity(child.pid)
                    diagnostic = state['nanbeige_diagnostic'] = {'status': 'running', 'pid': child.pid,
                        'start_ticks': identity['start_ticks'], 'command': command};save('nanbeige_short_diagnostic')
                    code = wait_child(diagnostic, child)
            else:
                code = wait_child(diagnostic)
            result = Path(config['diagnostic_output']) / 'result.json'
            require(result.exists(), 'nanbeige_diagnostic_result_missing')
            measured = strict_json(result.read_text())
            require(measured.get('cleanup_finished_at_utc'), 'nanbeige_diagnostic_cleanup_unknown')
            diagnostic.update(status='completed', measured_status=measured['status'], result_sha256=file_sha(result),
                              exit_code=code);save()
        for registered in config['jobs']:
            guard();ident = registered['owner'] + '/' + registered['job']['id']
            row = state['jobs'].get(ident)
            if row and row['status'] == 'completed':
                owner = config['owners'][registered['owner']]
                current = strict_json((Path(owner['output']) / 'status.json').read_text())['jobs'][registered['job']['id']]
                require(current['status'] == row['source_status'], 'completed_priority_source_status_changed')
                if row.get('result_sha256'):
                    require(file_sha(Path(registered['job']['output']) / 'result.json') == row['result_sha256'],
                            'completed_priority_source_changed')
                continue
            if row:
                require(row['status'] == 'running' and row.get('pid'), 'uncertain_priority_launch_no_replay')
                code = wait_child(row)
            else:
                require(not runtime_processes(config['runtime']), 'runtime_busy_no_parallel_inference')
                command = adapter_command(registered)
                row = state['jobs'][ident] = {'status': 'launching', 'started_at_utc': utc(),
                                              'original_command': registered['job']['command'], 'adapter_command': command}
                state['current_job'] = ident;save('running')
                log_path = HERE / 'full-logs' / (ident.replace('/', '__') + '.log');log_path.parent.mkdir(exist_ok=True)
                with log_path.open('a') as log:
                    child = subprocess.Popen(command, cwd=producer, stdin=subprocess.DEVNULL,
                        stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                    identity = process_identity(child.pid)
                    row.update(status='running', pid=child.pid, start_ticks=identity['start_ticks']);save()
                    code = wait_child(row, child)
            owner = config['owners'][registered['owner']]
            current = strict_json((Path(owner['output']) / 'status.json').read_text())['jobs'].get(registered['job']['id'], {})
            require(current.get('status') in terminal, 'registered_original_job_not_terminal')
            row.update(status='completed', source_status=current['status'], exit_code=code,
                       result_sha256=current.get('result_sha256'), finished_at_utc=utc())
            state['completed_jobs'] = sum(row['status'] == 'completed' for row in state['jobs'].values());save()
            reports()
            destination = HERE / 'full-snapshots' / ('after-' + str(state['completed_jobs']).zfill(2))
            if destination.exists():
                snapshots.verify(destination, rescore=True)
            else:
                archive = snapshots.export(HERE.parent, destination, Path(config['recovery_queue']))
                state['latest_snapshot'] = {'path': str(destination), 'runs': len(archive['runs'])}
            save();print(json.dumps({'utc': utc(), 'job': ident, 'completed': state['completed_jobs']}), flush=True)
        state.pop('current_job', None);save('registered_full_jobs_finished');reports();save()
        # The old supervisor is still at child.wait(). Only after all prioritized
        # jobs release the runtime may it reap Granite and start its unchanged Nanbeige supplement.
        paused = config['paused_recovery_supervisor'];actual = process_identity(paused['pid'])
        require(actual and actual['start_ticks'] == paused['start_ticks'] and actual['state'] == 'T',
                'recovery_resumption_owner_changed')
        require(not runtime_processes(config['runtime']), 'runtime_busy_before_recovery_resumption')
        state['recovery_resumption'] = {'pid': paused['pid'], 'start_ticks': paused['start_ticks'], 'at_utc': utc(),
            'supervisor_finished_time_will_include_scheduling_delay': True,
            'authoritative_granite_measurement_end_is_in_recovery_result': True};save()
        os.kill(paused['pid'], signal.SIGCONT)
        save('full_jobs_finished_original_transport_recovery_resumed')
    except BaseException as error:
        state.update(error=type(error).__name__, blocked_reason=str(error)[:300]);save('blocked');raise
