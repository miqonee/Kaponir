"""Three bounded runtime probes; synthetic calibration diagnostics, not ranking."""
import argparse
import concurrent.futures
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import time
import urllib.request

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--config', type=Path, required=True)
parser.add_argument('--check-only', action='store_true')
args = parser.parse_args();config = json.loads(args.config.read_text())
producer = Path(config['runner_root']);sys.path.insert(0, str(producer / 'scripts'))
from benchmark_resources import ProcessSampler, hardware_snapshot, throughput_metrics
from evaluate_privacy_policy import (decode_transport, observe_runtime_starts, request_raw, worker_pids)
from experiment_inference import schema_prompt
from kaponir_worker import FILES, Worker, configuration
from privacy_policy_experiment import payload, prompts, schema
from recover_privacy_transport import wait_for_verified_model
from run_privacy_policy_suite import atomic_json, file_sha, runtime_processes, utc
from summarize_privacy_policy import require, strict_json
from validation_pipeline import Candidate, opaque_id

MODEL = 'nanbeige42-3b'
output = Path(config['output'])
artifact = FILES[MODEL]
require(file_sha(Path(__file__)) == config['driver_sha256'], 'diagnostic_driver_changed')
require(file_sha(Path(config['runtime'])) == config['runtime_sha256'], 'diagnostic_runtime_changed')
require((Path(config['model_dir']) / artifact[0]).stat().st_size == artifact[1], 'diagnostic_model_size_changed')
if args.check_only:
    print(json.dumps({'conditions': 3, 'max_measured_http_seconds': 900, 'new_inference_calls': 0}));sys.exit(0)
require(not output.exists(), 'diagnostic_output_exists_no_automatic_replay')
require(not runtime_processes(config['runtime']), 'runtime_busy_no_parallel_inference')
require(file_sha(Path(config['model_dir']) / artifact[0]) == artifact[2], 'diagnostic_model_sha_changed')
output.mkdir(parents=True)
state = {'experiment_kind': 'nanbeige-runtime-diagnostic-v1', 'status': 'running', 'started_at_utc': utc(),
         'config_sha256': file_sha(args.config), 'driver_sha256': file_sha(Path(__file__)),
         'model_artifact': list(artifact), 'hardware': hardware_snapshot(), 'shadow': True, 'rules_changed': 0,
         'context_tokens': 8192, 'output_tokens': 256, 'server_reasoning_budget': 512,
         'threads': 2, 'slots': 1, 'gpu_layers': 0, 'server_reasoning_mode': 'auto',
         'server_reasoning_format': 'deepseek',
         'reference_only': True, 'fresh_or_representative_quality': False,
         'capability_probes': [], 'runtime_starts': [], 'conditions': []}


def save():
    atomic_json(output / 'result.json', state)


def source(padding=''):
    return ('Synthetic internal contract. The negotiated contract price is confidential.\n'
            'Private contract price: 740,00 ₽.\n'
            'Public reference example: VAT 20% is general information and is not confidential.\n' + padding)


cases = []
for value in ('740,00 ₽', '20%'):
    start = source().index(value)
    cases.append(Candidate(opaque_id('diagnostic.txt', value), 'diagnostic.txt', value, start, start + len(value)))
contract = schema('D', cases, [])
instruction = schema_prompt(prompts((producer / 'docs/experiments/privacy-policy-v1.txt').read_text())['D'], contract)


def request(text, thinking):
    value, _ = payload('D', cases, {'diagnostic.txt': text})
    return {'model': 'qwen-cpu', 'messages': [{'role': 'system', 'content': instruction},
            {'role': 'user', 'content': json.dumps(value, ensure_ascii=False)}],
            'max_tokens': 256, 'stream': False, 'cache_prompt': False,
            'temperature': 0.0, 'top_p': .95, 'top_k': 40, 'min_p': 0.0, 'seed': 42,
            'chat_template_kwargs': {'enable_thinking': thinking}}


def tokens(worker, body):
    from kaponir_worker import http_json
    rendered = http_json(worker.ocr_base + '/apply-template', {
        'messages': body['messages'], 'chat_template_kwargs': body['chat_template_kwargs'],
        'add_generation_prompt': True})['prompt']
    return worker.count_text_tokens(rendered), hashlib.sha256(rendered.encode()).hexdigest()


def long_source(worker):
    # Only padding length changes; both target records remain byte-identical.
    line = 'Public glossary: Monday Tuesday Wednesday Thursday Friday are ordinary weekday names.\n'
    low, high = 0, 1
    while tokens(worker, request(source(line * high), False))[0] < 4096:
        high *= 2
    while low < high:
        middle = (low + high) // 2
        if tokens(worker, request(source(line * middle), False))[0] < 4096:
            low = middle + 1
        else:
            high = middle
    return source(line * low)


def progress(worker, row, elapsed):
    try:
        with urllib.request.urlopen(worker.ocr_base + '/slots', timeout=3) as response:
            slots = strict_json(response.read().decode())
        row['progress_samples'].append({'elapsed_seconds': round(elapsed, 3), 'slots': [
            {key: slot.get(key) for key in ('id', 'is_processing', 'n_prompt_tokens', 'n_prompt_tokens_processed',
                                           'n_prompt_tokens_cache', 'next_token')} for slot in slots]})
    except Exception as error:
        row['progress_samples'].append({'elapsed_seconds': round(elapsed, 3), 'error': type(error).__name__})
    save()


def measured_http(worker, body):
    started = time.monotonic()
    try:
        return {'raw_transport': request_raw(worker.ocr_base + '/v1/chat/completions', body, 300),
                'http_wall_seconds': time.monotonic() - started}
    except Exception as error:
        return {'error': type(error).__name__, 'http_wall_seconds': time.monotonic() - started}


save()
with tempfile.TemporaryDirectory(prefix='kaponir-nan-diagnostic-') as temporary:
    home = Path(temporary)
    worker = Worker(home, configuration(home, {'model_dir': config['model_dir'], 'runtime': config['runtime'],
                    'threads': 2, 'ocr_timeout_seconds': 300}), 'unused')
    observe_runtime_starts(worker, state['runtime_starts'])
    original_probe = worker.detect_json_schema

    def probe():
        started = time.monotonic()
        try:
            return original_probe()
        finally:
            state['capability_probes'].append({'seconds': time.monotonic() - started,
                'contains_control_data': False, 'physical_generation_requests': 1,
                'supported': worker.process_supports_json_schema})

    worker.detect_json_schema = probe
    session_sampler = ProcessSampler(lambda: worker_pids(worker)).start()
    try:
        wait_started = time.monotonic();wait_for_verified_model(worker, MODEL, 600)
        state['artifact_readiness_seconds'] = time.monotonic() - wait_started
        long_text = None
        for name, thinking, long_input in [('off-short', False, False), ('on-short', True, False),
                                           ('off-long', False, True)]:
            row = {'name': name, 'status': 'preparing', 'enable_thinking': thinking, 'progress_samples': []}
            state['conditions'].append(row);save()
            job = worker.submit('evaluate', model=MODEL)
            worker.start_runtime(job['id'], MODEL, 1, context_tokens=8192,
                                 reasoning='auto', reasoning_format='deepseek', reasoning_budget=512)
            if long_text is None:
                long_text = long_source(worker)
            body = request(long_text if long_input else source(), thinking)
            count, rendered_sha = tokens(worker, body)
            require(count + 256 + 64 <= 8192, 'diagnostic_context_budget_exceeded')
            row.update(request=body, request_sha256=hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest(),
                       input_tokens=count, rendered_prompt_sha256=rendered_sha, status='pending')
            save()  # Unknown sends remain visible if this task is interrupted.
            sampler = ProcessSampler(lambda: worker_pids(worker)).start();started = time.monotonic()
            try:
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    future = pool.submit(measured_http, worker, body)
                    while True:
                        try:
                            measured = future.result(timeout=10);row.update(measured)
                            row['status'] = 'received' if 'raw_transport' in measured else 'failed';break
                        except concurrent.futures.TimeoutError:
                            progress(worker, row, time.monotonic() - started)
                if 'raw_transport' in row:
                    decode_transport(row)
            except Exception as error:
                row.update(status='failed', error=type(error).__name__)
            finally:
                row.setdefault('http_wall_seconds', time.monotonic() - started)
                row['sampled_resources'] = sampler.stop();progress(worker, row, row['http_wall_seconds'])
                reply = row.get('raw_reply') or {}
                row['throughput'] = throughput_metrics(reply, row['http_wall_seconds'])
                choices = reply.get('choices', [])
                message = choices[0].get('message', {}) if choices else {}
                row['finish_reason'] = choices[0].get('finish_reason') if choices else None
                row['reasoning_text_chars'] = len(message.get('reasoning_content') or message.get('reasoning') or '')
                row['final_text_chars'] = len(message.get('content') or '')
                try:
                    row['final_is_json_object'] = isinstance(strict_json(message.get('content') or ''), dict)
                except (ValueError, TypeError):
                    row['final_is_json_object'] = False
                worker.stop_runtime();row['runtime_cleaned_up'] = True;save()
        state.update(status='completed', finished_at_utc=utc(), measured_request_slots=len(state['conditions']),
                     delivered_responses=sum(row['status'] == 'received' for row in state['conditions']))
    except BaseException as error:
        state.update(status='failed', error=type(error).__name__, reason=str(error)[:250]);raise
    finally:
        worker.stop.set();worker.stop_runtime()
        state['sampled_resources'] = session_sampler.stop();state['cleanup_finished_at_utc'] = utc();save()
print(json.dumps({'status': state['status'], 'conditions': len(state['conditions']), 'output': str(output)}))
