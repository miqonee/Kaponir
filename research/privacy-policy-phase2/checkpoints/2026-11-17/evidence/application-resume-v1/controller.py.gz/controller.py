"""Apply the explicitly registered recovery outputs; never run model inference."""
import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
CONFIG = HERE / 'config.json'
config = json.loads(CONFIG.read_text())
producer = Path(config['producer'])
sys.path.insert(0, str(producer / 'scripts'))
from run_privacy_policy_suite import SuiteLock, atomic_json, file_sha, process_identity, utc
from summarize_privacy_policy import require, strict_json
from summarize_privacy_recovery import load_supplement
from report_complete_research import write_reports
from report_policy_clarification import write_reports as policy_reports
from run_complete_research import build_jobs as complete_jobs
from run_policy_clarification import build_jobs as policy_jobs
from run_gemma_it_research import build_jobs as gemma_jobs
import export_privacy_snapshot as snapshots

config_sha = file_sha(CONFIG)
source_manifest = json.loads(Path(config['producer_manifest']).read_text())
cache = {}
# The reader's code/corpus live in a frozen producer; the explicitly registered
# synthetic study remains in the shared task workspace.
require(HERE.parent == Path(config['study']).resolve(), 'unexpected_synthetic_study_root')
snapshots.STUDY = HERE.parent


def guard():
    require(file_sha(CONFIG) == config_sha, 'application_config_changed')
    require(file_sha(Path(__file__)) == config['controller_sha256'], 'application_controller_changed')
    require(file_sha(Path(config['binary'])) == config['binary_sha256'], 'application_binary_changed')
    require(file_sha(Path(config['producer_manifest'])) == config['producer_manifest_sha256'],
            'application_source_manifest_changed')
    for name, expected in source_manifest['tracked_files_sha256'].items():
        require(file_sha(producer / name) == expected, 'application_frozen_source_changed:' + name)
    require(file_sha(Path(config['recovery_queue'])) == config['recovery_queue_sha256'],
            'canonical_recovery_queue_changed')
    for job in config['jobs']:
        require(file_sha(Path(job['original'])) == job['original_sha256'], 'original_measurement_changed')


def source(job):
    path = Path(job['supplement'])
    if not path.exists():
        return None
    raw = strict_json(path.read_text())
    if raw.get('status') != 'completed':
        require(raw.get('status') != 'failed', 'recovery_source_failed:' + job['model'])
        return None
    if not raw.get('finished_at_utc') or type(raw.get('runtime_cleanup_seconds')) not in (int, float):
        return None
    digest = file_sha(path)
    if digest not in cache:
        run = load_supplement(path, job['original'])
        require(run['result_sha256'] == digest, 'supplement_changed_while_reading')
        cache[digest] = run
    return cache[digest]


def bind(job, run):
    folder = Path(job['output'])
    path = folder / 'result.json'
    data = strict_json(path.read_text())
    require(data['status'] == 'completed' and data['binary_sha256'] == config['binary_sha256']
            and data['model'] == job['model'] and data['variant'] == job['variant'],
            'application_identity_or_binary_mismatch')
    require(data['new_inference_calls'] == data['user_rules_changed'] == 0
            and data['model_predicted_type_or_scope_applied'] is False,
            'application_changed_rules_or_called_model')
    require(data['source_result_sha256'] == job['original_sha256']
            and data['transport_supplement_result_sha256'] == run['result_sha256']
            and data['transport_supplement_plan_sha256'] == run['recovery_plan_sha256']
            and data['transport_supplement_plan_file_sha256'] == run['recovery_plan_file_sha256'],
            'application_source_binding_mismatch')
    row = next(row for row in run['effective_rows'] if row['variant'] == job['variant'])
    require(data['measured_decision_quality'] == row['quality'], 'application_quality_view_changed')
    docs = data['documents']
    require(data['exact_roundtrips'] == len(docs) == 6 and all(
        row['restore_exact'] and row['persistent_rules_unchanged'] for row in docs),
        'application_restore_or_rule_invariant_failed')
    evidence = {path.relative_to(folder).as_posix(): file_sha(path) for path in folder.rglob('*')
                if path.is_file() and path.name in ('mask.json', 'restore.json', 'masked.txt')}
    require(len(evidence) == 18, 'application_raw_evidence_missing')
    selected = [row for row in docs if row['mode'] == 'model_masks_added']
    return {'status': 'completed', 'result_sha256': file_sha(path), 'evidence_sha256': evidence,
            'source_sha256': run['result_sha256'], 'exact_roundtrips': 6,
            **{key: sum(row[key] for row in selected) for key in (
                'private_spans_fully_covered', 'private_spans_partly_covered',
                'private_spans_untouched', 'public_occurrences_lost')},
            'public_reference_replacements': sum(row['replacements'] for row in selected
                                                if row['file'] == '08-public-reference.md')}


def save():
    state['completed_jobs'] = sum(row.get('status') == 'completed' for row in state['jobs'].values())
    state['exact_roundtrips'] = sum(row.get('exact_roundtrips', 0) for row in state['jobs'].values())
    state['updated_at_utc'] = utc()
    atomic_json(HERE / 'status.json', state)
    fields = ['id', 'model', 'variant', 'status', 'private_spans_fully_covered',
              'private_spans_partly_covered', 'private_spans_untouched', 'public_occurrences_lost',
              'public_reference_replacements', 'exact_roundtrips', 'result_sha256']
    with (HERE / 'applications.csv').open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction='ignore');writer.writeheader()
        for job in config['jobs']:
            writer.writerow({**job, **state['jobs'].get(job['id'], {'status': 'waiting_source'})})


def reports():
    study = HERE.parent
    complete = strict_json((study / 'complete-v1/config.json').read_text())
    policy = strict_json((study / 'policy-v2/config.json').read_text())
    extension = strict_json((study / 'gemma-it-v1/config.json').read_text())
    jobs = complete_jobs(complete) + policy_jobs(policy) + gemma_jobs(extension)
    rows = {}
    for name in ('complete-v1', 'policy-v2', 'gemma-it-v1'):
        rows.update(strict_json((study / name / 'status.json').read_text()).get('jobs', {}))
    current = {'status': state['status'], 'jobs': rows}
    settings = {**complete, 'output': str(HERE / 'research'), 'expected_models': config['expected_models'],
                'reference_recovery_output': str(Path(config['recovery_queue']).parent)}
    state['research_report'] = write_reports(settings, current, jobs)
    state['policy_report'] = policy_reports(
        {'output': str(HERE / 'policy-comparison'), 'expected_models': config['expected_models']},
        current, [job for job in jobs if job['kind'] == 'policy_clarification'])


if '--check-only' in sys.argv:
    guard()
    checked = 0
    for job in config['jobs']:
        if job.get('adopt_existing'):
            run = source(job);require(run is not None, 'existing_source_not_complete')
            bind(job, run);checked += 1
    print(json.dumps({'registered_jobs': len(config['jobs']), 'existing_jobs_verified': checked,
                      'new_model_calls': 0, 'new_api_calls': 0}))
    sys.exit(0)


with SuiteLock(HERE / '.application.lock'):
    existing = HERE / 'status.json'
    if existing.exists():
        require('--resume' in sys.argv, 'existing_application_state_requires_explicit_resume')
        state = strict_json(existing.read_text())
        require(state['config_sha256'] == config_sha, 'application_configuration_changed')
        owner = state['controller'];actual = process_identity(owner['pid'])
        require(not actual or actual['state'] == 'Z' or actual['start_ticks'] != owner['start_ticks'],
                'previous_application_controller_alive')
        require(not any(row.get('status') in ('launching', 'running') for row in state['jobs'].values()),
                'interrupted_application_requires_inspection_no_automatic_replay')
    else:
        state = {'config_sha256': config_sha, 'started_at_utc': utc(), 'jobs': {},
                 'planned_jobs': len(config['jobs']), 'new_model_inference_calls': 0, 'user_rules_changed': 0}
    identity = process_identity(os.getpid())
    state['controller'] = {'pid': os.getpid(), 'start_ticks': identity['start_ticks']}
    try:
        guard()
        for job in config['jobs']:
            if job.get('adopt_existing') or state['jobs'].get(job['id'], {}).get('status') == 'completed':
                run = source(job);require(run is not None, 'completed_application_source_not_ready')
                verified = bind(job, run)
                if job['id'] in state['jobs']:
                    require(state['jobs'][job['id']]['result_sha256'] == verified['result_sha256'],
                            'completed_application_changed')
                state['jobs'][job['id']] = {**verified, 'adopted_without_repeating': True}
        state['status'] = 'waiting_sources';reports();save()
        while state['completed_jobs'] < len(config['jobs']):
            progressed = False
            for job in config['jobs']:
                if state['jobs'].get(job['id'], {}).get('status') == 'completed':
                    continue
                run = source(job)
                if run is None:
                    continue
                guard();output = Path(job['output'])
                require(not output.exists(), 'application_output_exists_no_overwrite')
                state['status'] = 'running';state['current_job'] = job['id']
                row = state['jobs'][job['id']] = {'status': 'launching', 'source_sha256': run['result_sha256']}
                save()
                command = [sys.executable, '-u', str(producer / 'scripts/apply_measured_privacy.py'),
                    '--result', job['original'], '--transport-supplement', job['supplement'],
                    '--binary', config['binary'], '--output', str(output), '--variant', job['variant']]
                with (HERE / 'applications.log').open('a') as log:
                    child = subprocess.Popen(command, cwd=producer, stdout=log, stderr=subprocess.STDOUT,
                        stdin=subprocess.DEVNULL, start_new_session=True,
                        env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
                    row.update(status='running', pid=child.pid, identity=process_identity(child.pid));save()
                    require(child.wait() == 0, 'application_child_failed')
                state['jobs'][job['id']] = bind(job, run);save();progressed = True
                print(json.dumps({'utc': utc(), 'completed': job['id'], 'roundtrips': state['exact_roundtrips']}), flush=True)
            state.pop('current_job', None)
            state['status'] = 'applications_finished' if state['completed_jobs'] == len(config['jobs']) else 'waiting_sources'
            if progressed:
                reports()
                completed_sources = sorted({row['source_sha256'] for row in state['jobs'].values()
                                           if row.get('status') == 'completed'})
                tag = hashlib.sha256(json.dumps(completed_sources).encode()).hexdigest()[:12]
                destination = HERE / 'snapshots' / tag
                if not destination.exists():
                    archived = snapshots.export(HERE.parent, destination, Path(config['recovery_queue']))
                    state['latest_snapshot'] = {'output': str(destination), 'runs': len(archived['runs']),
                                                'pending': len(archived['pending'])}
            save()
            if state['status'] == 'waiting_sources':
                time.sleep(15)
    except BaseException as error:
        state.update(status='blocked', error=type(error).__name__, reason=str(error)[:300]);save();raise
