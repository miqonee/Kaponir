"""Task-specific, serial API application of frozen, completed model measurements."""
import csv,gzip,hashlib,json,os,subprocess,sys,time
from pathlib import Path

HERE=Path(__file__).resolve().parent
config=json.loads((HERE/'config.json').read_text());producer=Path(config['runner_root'])
sys.path.insert(0,str(producer/'scripts'))
from run_privacy_policy_suite import atomic_json,file_sha,process_identity,SuiteLock,utc
from run_reference_abcd import snapshot
from summarize_privacy_policy import require,strict_json

TERMINAL={'completed','unavailable_context','source_failed'}
configuration_sha=file_sha(HERE/'config.json')

def guard():
 require(file_sha(Path(__file__))==config['controller_sha256'],'application_controller_source_changed')
 require(file_sha(Path(config['binary']))==config['binary_sha256'],'application_binary_changed')
 require(snapshot(producer)==config['producer_inputs_sha256'],'application_frozen_producer_changed')
 for name,expected in config['reference_config_sha256'].items():require(file_sha(Path(name))==expected,'measurement_configuration_changed')

def source_state(job,owners):
 source=Path(job['source'])
 if job['archived']:
  require(file_sha(source)==job['source_file_sha256'],'archived_application_source_changed')
  return 'ready',None
 owner=owners[job['source_owner']]
 if job['source_owner']=='suite-v1':
  row=owner.get('gemma',{}) if job['source_owner_job']=='gemma4-e4b-qat' else owner.get('models',{}).get(job['source_owner_job'],{})
 else:row=owner.get('jobs',{}).get(job['source_owner_job'],{})
 status=row.get('status','pending')
 if status.startswith('completed'):
  require(source.is_file(),'completed_application_source_missing')
  if row.get('result_sha256'):require(file_sha(source)==row['result_sha256'],'completed_model_source_changed')
  return 'ready',row
 if status=='unavailable_context':
  observed=source.with_name('native-budget-observations.json')
  require(observed.is_file() and file_sha(observed)==row.get('budget_observations_sha256'),'source_budget_diagnostic_changed')
  data=strict_json(observed.read_text());require(data.get('measurement_request_slots_recorded')==0,'invalid_context_diagnostic')
  return status,row
 if status=='failed':return 'source_failed',row
 return 'waiting',None

def result_binding(job,row):
 path=Path(row['output'])/'result.json';result=strict_json(path.read_text())
 require(result.get('status')=='completed' and result.get('binary_sha256')==config['binary_sha256'],'application_result_not_complete_or_binary_changed')
 require(result.get('new_inference_calls')==0 and result.get('user_rules_changed')==0,'application_must_not_call_model_or_change_rules')
 require(result.get('model')==job['model'] and result.get('variant')==job['method'],'application_result_identity_mismatch')
 raw=Path(job['source']).read_bytes();require(hashlib.sha256(raw).hexdigest()==row['source_file_sha256'],'measured_source_changed_during_application')
 expected=hashlib.sha256(gzip.decompress(raw) if job['archived'] else raw).hexdigest()
 require(result.get('source_result_sha256')==expected,'application_source_result_not_bound')
 docs=result.get('documents',[]);expected_docs=8 if job['dataset']=='holdout' else 6
 require(result.get('exact_roundtrips')==len(docs)==expected_docs and all(d.get('restore_exact') and d.get('persistent_rules_unchanged') for d in docs),'application_restore_or_rule_invariant_failed')
 artifacts={p.relative_to(path.parent).as_posix():file_sha(p) for p in path.parent.rglob('*') if p.is_file() and p.name in ('mask.json','restore.json','masked.txt')}
 require(len(artifacts)==expected_docs*3,'application_raw_evidence_missing')
 return {'result_sha256':file_sha(path),'evidence_files_sha256':artifacts,'exact_roundtrips':expected_docs}

def report(state):
 columns=['job','model','profile','variant_or_scheme','status','private_full','private_partial','private_untouched','public_control_occurrences_lost','public_reference_replacements','requested_mask_occurrences_still_visible','exact_roundtrips','result_sha256']
 rows=[];roundtrips=0
 for job in config['jobs']:
  r=state['jobs'].get(job['id'],{});out={'job':job['id'],'model':job['model'],'profile':job['profile'],'variant_or_scheme':job['method'],'status':r.get('status','waiting_source')}
  if out['status']=='completed':
   p=Path(r['output'])/'result.json';require(file_sha(p)==r['result_sha256'],'application_report_changed')
   data=strict_json(p.read_text());selected=[d for d in data['documents'] if d['mode']=='model_masks_added']
   for label,key in [('private_full','private_spans_fully_covered'),('private_partial','private_spans_partly_covered'),('private_untouched','private_spans_untouched'),('public_control_occurrences_lost','public_occurrences_lost'),('requested_mask_occurrences_still_visible','mask_occurrences_still_visible')]:out[label]=sum(d[key] for d in selected)
   out['public_reference_replacements']=sum(d['replacements'] for d in selected if d['file']=='08-public-reference.md')
   out['exact_roundtrips']=data['exact_roundtrips'];out['result_sha256']=r['result_sha256'];roundtrips+=data['exact_roundtrips']
  rows.append(out)
 with (HERE/'applications.csv.tmp').open('w',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader();writer.writerows(rows)
 (HERE/'applications.csv.tmp').replace(HERE/'applications.csv')
 state['completed_jobs']=sum(r.get('status')=='completed' for r in state['jobs'].values());state['terminal_jobs']=sum(r.get('status') in TERMINAL for r in state['jobs'].values());state['exact_roundtrips']=roundtrips
 state['updated_at_utc']=utc();atomic_json(HERE/'status.json',state)

def wait_child(job,row,child=None):
 while True:
  actual=process_identity(row['pid'])
  if actual and actual['state']!='Z':require(actual['start_ticks']==row['identity']['start_ticks'],'application_child_pid_reused')
  if child is not None:
   try:row['exit_code']=child.wait(timeout=15);break
   except subprocess.TimeoutExpired:continue
  elif not actual or actual['state']=='Z':break
  else:time.sleep(15)
 row.update(result_binding(job,row),status='completed',finished_at_utc=utc())

with SuiteLock(HERE/'.application.lock'):
 state_path=HERE/'status.json'
 if state_path.exists():
  require('--resume' in sys.argv,'application_resume_must_be_explicit')
  state=strict_json(state_path.read_text());require(state.get('config_sha256')==configuration_sha,'application_config_changed')
  old=state.get('controller',{});actual=process_identity(old.get('pid',0))
  require(not actual or actual['state']=='Z' or actual['start_ticks']!=old.get('identity',{}).get('start_ticks'),'application_controller_still_alive')
 else:state={'version':1,'config_sha256':configuration_sha,'started_at_utc':utc(),'jobs':{},'new_model_inference_calls':0,'user_rules_changed':0,'planned_jobs':len(config['jobs'])}
 state['controller']={'pid':os.getpid(),'identity':process_identity(os.getpid())}
 state['controller_sha256']=file_sha(Path(__file__))
 try:
  guard()
  for job in config['jobs']:
   row=state['jobs'].get(job['id'],{})
   if row.get('status') in ('running','launching'):
    require(row.get('pid') and row.get('identity'),'uncertain_application_launch_no_replay')
    wait_child(job,row);report(state)
   elif row.get('status')=='completed':
    binding=result_binding(job,row);require(all(row[k]==v for k,v in binding.items()),'application_evidence_changed')
  while state.get('terminal_jobs',0)<len(config['jobs']):
   owners={name:strict_json((HERE.parent/name/'status.json').read_text()) for name in config['source_owners']}
   progressed=False
   for job in config['jobs']:
    if state['jobs'].get(job['id'],{}).get('status') in TERMINAL:continue
    ready,source=source_state(job,owners)
    if ready=='waiting':continue
    if ready!='ready':state['jobs'][job['id']]={'status':ready,'source_status':source,'source':job['source']};progressed=True;continue
    guard();destination=HERE/'runs'/job['id'];require(not destination.exists(),'existing_application_evidence_no_overwrite')
    row={'status':'launching','output':str(destination),'source_file_sha256':file_sha(Path(job['source'])),'started_at_utc':utc()}
    state['jobs'][job['id']]=row;state['status']='running';state['current_job']=job['id'];report(state)
    script='apply_scheme_masks.py' if job['kind']=='schemes' else 'apply_measured_privacy.py'
    command=[sys.executable,'-u',str(producer/'scripts'/script),'--result',job['source'],'--binary',config['binary'],'--output',str(destination),'--method' if job['kind']=='schemes' else '--variant',job['method']]
    if job['archived']:command.append('--archived')
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
    with (HERE/'commands.log').open('a') as log:
     child=subprocess.Popen(command,cwd=producer,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=env)
     row.update(pid=child.pid,identity=process_identity(child.pid),status='running');report(state);wait_child(job,row,child)
    report(state);progressed=True;print(json.dumps({'utc':utc(),'job':job['id'],'completed_jobs':state['completed_jobs'],'roundtrips':state['exact_roundtrips']}),flush=True)
   state.pop('current_job',None);state['status']='waiting_sources' if state.get('terminal_jobs',0)<len(config['jobs']) else 'applications_finished_with_source_limitations' if any(r['status']!='completed' for r in state['jobs'].values()) else 'applications_finished';report(state)
   if not progressed and state['status']=='waiting_sources':time.sleep(15)
 except BaseException as error:
  state.update(status='blocked',error=type(error).__name__,reason=str(error)[:220]);report(state);raise
