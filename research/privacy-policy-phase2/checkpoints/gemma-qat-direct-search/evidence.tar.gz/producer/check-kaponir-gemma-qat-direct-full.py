"""Confirm the short-pilot Gemma QAT search profile on the three frozen documents."""

from argparse import Namespace
from copy import deepcopy
import json
import os
from pathlib import Path
import runpy
from tempfile import TemporaryDirectory

from jsonschema import Draft202012Validator
from evaluate_model_schemes import MeasuredClient
from experiment_inference import discover, prompts_and_kinds
from kaponir_worker import Worker, configuration
from native_model_profiles import catalog_for
from privacy_expansion_profiles import research_registration
from run_privacy_policy_suite import SuiteLock, atomic_json, file_sha, runtime_processes
from summarize_privacy_policy import digest, require, strict_json

HERE = Path(__file__).resolve().parent
large = runpy.run_path(str(HERE / 'check-kaponir-lfm-large.py'))
ROOT, RUNTIME, BINARY = (large[k] for k in ('ROOT','RUNTIME','BINARY'))
OUT = HERE/'kaponir-hybrid-pilot/gemma-qat-direct-full-v1'
SHORT = HERE/'kaponir-hybrid-pilot/stock-calibration-v1/gemma4-e4b-qat-direct-temperature-0/candidate/transports.json'
MODEL = 'gemma4-e4b-qat'
read = large['read']


def run():
    sources, private, public, pool = large['corpus']()
    binary_sha = file_sha(BINARY)
    require(binary_sha == read(ROOT/'status.json')['binary_sha256'] and file_sha(RUNTIME) == large['RUNTIME_SHA256'], 'runtime_or_api_changed')
    baseline = large['originals'](MODEL, sources, binary_sha)
    short = read(SHORT)['profile']
    profile = deepcopy(baseline['profile'])
    profile.update(temperature=0.0, template_kwargs={'enable_thinking':False})
    require({k for k in profile if profile[k] != short[k]} == {'transport_timeout_seconds'}
            and profile['transport_timeout_seconds']==1200 and short['transport_timeout_seconds']==300,
            'short_recipe_mismatch')
    weights, size, sha, _ = baseline['artifact']
    cpus = sorted(os.sched_getaffinity(0))[2:4]
    require(len(cpus)==2, 'requires_two_cpus')
    os.sched_setaffinity(0, cpus)
    with SuiteLock(ROOT/'.native-retest.lock'):
        require(not runtime_processes(RUNTIME), 'runtime_busy')
        require(not OUT.exists(), 'existing_run')
        OUT.mkdir(parents=True)
        checks = {k:baseline[k] for k in ('plan_sha256','journal_sha256','result_sha256','application_sha256','source_sha256','artifact')}
        plan = {'model':MODEL,'profile':profile,'recommended_reference':checks,'source_sha256':baseline['source_sha256'],
            'short_profile_sha256':file_sha(SHORT),'runtime_sha256':file_sha(RUNTIME),'binary_sha256':binary_sha,
            'detector_pool_sha256':large['EXPORT_SHA'],'script_sha256':file_sha(Path(__file__)),
            'temperature_change':[1.0,0.0],'thinking_change':[True,False],
            'decision':'Faster than recommended, at least as many full private hides, no increase in public control losses or guide replacements; compare original separately.',
            'documents':list(sources),'private_occurrences':193,'public_controls':87,
            'threads':2,'allowed_cpus':cpus,'timing':'sum of all measured HTTP requests, retries included; loading and application excluded'}
        atomic_json(OUT/'plan.json',plan)
        print('plan saved; verifying model', weights, flush=True)
        require((ROOT/'models'/weights).stat().st_size == size and file_sha(ROOT/'models'/weights)==sha, 'weights_changed')
        history, stages, diagnostics = [], {}, {}
        prompt, _, kinds = prompts_and_kinds()
        args = Namespace(**profile,candidate_mode='typed',strategy='auto',target_input_tokens=0)
        with research_registration(MODEL,catalog_for(MODEL)), TemporaryDirectory(prefix='kaponir-gemma-full-') as loc:
            home=Path(loc)
            worker=Worker(home,configuration(home,{'model_dir':str(ROOT/'models'),'runtime':str(RUNTIME),
                'threads':2,'ocr_timeout_seconds':profile['worker_configuration_timeout_seconds']}),'unused')
            try:
                sampling={k:profile[k] for k in ('temperature','top_p','top_k','min_p','seed')}
                client=MeasuredClient(worker,MODEL,profile['context_tokens'],profile['output_tokens'],profile['response_format'],sampling,profile,OUT,history)
                for name,source in sources.items():
                    client.measurement_stage='discovery:'+name
                    first=len(history)
                    print(name,'started',flush=True)
                    found=discover(client,source,prompt,kinds,args,client.save_history,{})
                    entries=history[first:]
                    old=baseline['requests'][name]['request']
                    expected={**old,'temperature':0.0,'chat_template_kwargs':profile['template_kwargs']}
                    require(entries and entries[0]['request']==expected,'primary_request_changed')
                    for h in entries:
                        req=h['request']
                        same_keys=set(req)-{'messages','max_tokens'}
                        require(same_keys==set(expected)-{'messages','max_tokens'} and all(req[k]==expected[k] for k in same_keys)
                            and req['messages'][0]==old['messages'][0] and json.loads(req['messages'][-1]['content'])['source'] in source
                            and h['request_sha256']==digest(req),'prompt_or_schema_changed')
                    diagnostics[name]=[]
                    for h in entries:
                        req=h['request']
                        rec=h['record']
                        choice=h.get('raw_reply',{}).get('choices',[{}])[0]
                        schema=req['response_format']['json_schema']['schema']
                        valid=False
                        issues=[]
                        try:
                            parsed=strict_json(choice['message']['content'])
                            errors=list(Draft202012Validator(schema).iter_errors(parsed))
                            valid=not errors
                            issues=[{'path':list(e.absolute_path),'validator':e.validator} for e in errors]
                        except (KeyError, ValueError, TypeError):
                            issues=[{'path':[],'validator':'valid_json'}]
                        diagnostics[name].append({'finish_reason':choice.get('finish_reason'),'schema_valid':valid,'schema_issues':issues,
                            'candidate_count':rec.get('candidate_count'),'grounded':rec.get('unique_grounded_count'),
                            'reasoning_tokens':rec.get('reasoning_text_tokens'),'completion_tokens':(rec.get('usage') or {}).get('completion_tokens'),
                            'http_seconds':rec['http_wall_seconds']})
                    stages[name]={**found,'http_seconds':sum(d['http_seconds'] for d in diagnostics[name])}
                    atomic_json(OUT/'discovery.json',stages)
                    atomic_json(OUT/'response-checks.json',diagnostics)
                    print(name,'done', 'requests',len(entries),'seconds',round(stages[name]['http_seconds'],2),'valid',[d['schema_valid'] for d in diagnostics[name]],flush=True)
            finally:
                worker.stop_runtime()
        require(all(not v['errors'] for v in stages.values()),'discovery_error')
        require(not runtime_processes(RUNTIME),'runtime_cleanup')
        applied=large['apply_stage'](MODEL,'direct-temperature-0-full',stages,sources,private,public,pool,baseline['source_sha256'],OUT)
        totals=applied['application']
        report={'model':MODEL,'documents':totals,'private_full':sum(d['private_spans_fully_covered'] for d in totals.values()),
            'public_lost':sum(d['public_occurrences_lost'] for d in totals.values()),
            'private_partial':sum(d['private_spans_partly_covered'] for d in totals.values()),
            'private_untouched':sum(d['private_spans_untouched'] for d in totals.values()),
            'guide_replacements':totals['08-public-reference.md']['replacements'],'http_seconds':applied['http_seconds'],
            'exact_restores':applied['exact_roundtrips'],'plan_sha256':file_sha(OUT/'plan.json'),
            'transports_sha256':file_sha(OUT/'transports.json'),'application_sha256':file_sha(OUT/'apply/result.json'),
            'request_checks':diagnostics}
        require(sum(report[k] for k in ('private_full','private_partial','private_untouched'))==193 and report['exact_restores']==6,'application_incomplete')
        m=report['http_seconds']/60
        report['score']=50*report['private_full']/193+15*(87-report['public_lost'])/87+5/(1+report['guide_replacements'])+30*11.55/(11.55+m)
        atomic_json(OUT/'result.json',report)
        print('completed',{k:report[k] for k in ('private_full','public_lost','guide_replacements','http_seconds','score','exact_restores')},flush=True)


if __name__=='__main__':
    run()
