"""Calibrate the two Q4_K_M models and verify one profile on the full Kaponir corpus."""

from argparse import ArgumentParser, Namespace
import base64
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import runpy
from tempfile import TemporaryDirectory
import time

from jsonschema import Draft202012Validator

from check_learning_corpus import load_corpus, occurrences
from compare_local_models import DOCUMENTS, ROOT as REPO
from evaluate_context_controls import prepare_cases
from evaluate_model_schemes import MeasuredClient, scheme_profile
from evaluate_privacy_policy import request_raw
from evaluate_validation_schemes import detector_pool_from_export
from experiment_inference import discover, prompts_and_kinds
from kaponir_worker import FILES, Worker, configuration, http_json
from privacy_policy_experiment import common_batches, metrics, payload, prompts, schema, technical_review, validate
from run_privacy_policy_suite import atomic_json, file_sha
from summarize_privacy_policy import digest, require, strict_json

HERE = Path(__file__).resolve().parent
helpers = runpy.run_path(str(HERE / 'check-kaponir-lfm-large.py'))
STUDY, RUNTIME, BINARY = (helpers[k] for k in ('ROOT', 'RUNTIME', 'BINARY'))
PILOT = HERE / 'kaponir-hybrid-pilot'
OUTPUT = PILOT / 'granite-nanbeige-v1'
GRANITE = 'granite42-3b'
NANBEIGE = 'nanbeige42-3b'
OPTIONS = {
    GRANITE: (
        ('direct-card', 1.0, -1, 'chat-grammar'),
        ('direct-greedy', 0.0, -1, 'chat-grammar'),
        ('thinking-384', 1.0, 384, 'chat-grammar'),
        ('low-effort-384', 1.0, 384, 'chat-grammar'),
    ),
    NANBEIGE: (
        ('direct-card-schema', 0.6, -1, 'completion-grammar'),
        ('direct-greedy-schema', 0.0, -1, 'completion-grammar'),
        ('direct-card-prompt', 0.6, -1, 'chat-prompt'),
        ('thinking-384', 0.6, 384, 'chat-prompt'),
    ),
}


class ValidatedClient(MeasuredClient):
    def prepared_prompt(self, prompt, schema=None):
        if self.profile['route'] == 'completion-grammar':
            return prompt
        return super().prepared_prompt(prompt, schema)

    def completion(self, prompt, value, schema, output_tokens):
        messages = [{'role': 'system', 'content': prompt},
                    {'role': 'user', 'content': json.dumps(value, ensure_ascii=False)}]
        params = {'messages': messages, 'chat_template_kwargs': self.profile['template_kwargs'],
                  'add_generation_prompt': True}
        rendered = http_json(self.worker.ocr_base + '/apply-template', params)['prompt']
        input_tokens = self.worker.count_text_tokens(rendered)
        require(input_tokens + output_tokens + self.profile['reserve_tokens'] <= self.context_tokens,
                'model_context_budget_exceeded')
        request = {'prompt': rendered, **self.sampling, **self.profile['extra_sampling'],
                   'n_predict': output_tokens, 'stream': False, 'cache_prompt': False,
                   'json_schema': schema}
        record = {'input_tokens': input_tokens, 'max_output_tokens': output_tokens,
                  'structured_output': self.profile['route'],
                  'physical_request_index': len(self.history), 'measurement_stage': self.measurement_stage}
        entry = {'status': 'pending', 'endpoint': '/completion', 'template_request': params,
                 'request': request, 'request_sha256': digest(request),
                 'rendered_prompt_sha256': hashlib.sha256(rendered.encode()).hexdigest(),
                 'record': record}
        self.history.append(entry)
        self.records.append(record)
        self.save_history()
        started = time.monotonic()
        try:
            transport = request_raw(self.worker.ocr_base + '/completion', request,
                                    self.profile['transport_timeout_seconds'])
            entry.update(status='received', raw_transport=transport)
            require(transport['status'] == 200, 'runtime_http_' + str(transport['status']))
            reply = strict_json(base64.b64decode(transport['body_base64']).decode('utf-8'))
            entry['raw_reply'] = reply
            record.update(finish_reason='length' if reply['stop_type'] == 'limit' else 'stop',
                          stop_type=reply['stop_type'], reasoning_text_tokens=0,
                          usage={'prompt_tokens': reply['tokens_evaluated'],
                                 'completion_tokens': reply['tokens_predicted']})
            require(reply['stop_type'] != 'limit', 'model_response_truncated')
            require(reply['stop_type'] in ('eos', 'word'), 'model_nonstop_response')
            return strict_json(reply['content'])
        except Exception as exc:
            entry['parse_error'] = str(exc)[:160]
            record['error'] = type(exc).__name__
            if 'raw_transport' not in entry:
                entry['status'] = 'failed'
            raise
        finally:
            record['http_wall_seconds'] = time.monotonic() - started
            record['seconds'] = record['http_wall_seconds']
            self.save_history()

    def one(self, prompt, value, schema, output_tokens):
        if self.profile['route'] == 'completion-grammar':
            reply = self.completion(prompt, value, schema, output_tokens)
        else:
            super().one(prompt, value, schema, output_tokens)
            reply = strict_json(self.history[-1]['raw_reply']['choices'][0]['message']['content'])
        if self.measurement_stage.startswith('discovery:'):
            if not Draft202012Validator(schema).is_valid(reply):
                self.history[-1]['record']['error'] = 'response_schema_mismatch'
                self.save_history()
                raise ValueError('response_schema_mismatch')
        return reply


def short_fixture():
    directory = PILOT / 'fresh-lfm12'
    plan = strict_json((directory / 'plan.json').read_text())
    source, private, public = (plan[key] for key in ('sources', 'private_values', 'public_values'))
    require({name: hashlib.sha256(t.encode()).hexdigest() for name, t in source.items()} == plan['source_sha256'],
            'short_corpus_changed')
    pool, _ = detector_pool_from_export(strict_json((directory / 'detectors.json').read_text()), source)
    return source, private, public, pool


def profile_for(model, option, phase):
    label, temperature, budget, route = option
    profile = scheme_profile(model, 'native')
    profile.update(temperature=temperature, reasoning_budget=budget,
                   template_kwargs={'enable_thinking': budget > 0},
                   response_format='grammar' if route == 'chat-grammar' else 'prompt',
                   route=route, max_candidates=24, max_fragments=1 if phase == 'pilot' else 64,
                   retry_output_tokens=4096 if phase == 'pilot' else 8192,
                   transport_timeout_seconds=220 if phase == 'pilot' else 1200)
    if label == 'low-effort-384':
        profile['template_kwargs']['low_effort'] = True
    return label, profile


def verify_inputs(model):
    name, size, sha, _ = FILES[model]
    path = STUDY / 'models' / name
    require(path.stat().st_size == size and file_sha(path) == sha, 'fixed_model_artifact_changed')
    require(file_sha(RUNTIME) == helpers['RUNTIME_SHA256'], 'runtime_changed')
    require(file_sha(BINARY) == strict_json((STUDY / 'status.json').read_text())['binary_sha256'],
            'application_binary_changed')


def total(labels, sources):
    return sum(len(occurrences(sources[name], v)) for name, values in labels.items() for v in values)


def reuse_discovery(client, replay, name):
    stage = f'discovery:{name}'
    entries = [r for r in replay['requests'] if r['record']['measurement_stage'] == stage]
    require(len(entries) == 1 and entries[0]['status'] == 'received', 'invalid_reused_discovery')
    request = deepcopy(entries[0])
    request['reused'] = replay['label']
    request['record']['physical_request_index'] = len(client.history)
    client.history.append(request)
    client.records.append(request['record'])
    client.save_history()
    return replay['stages'][name]


def load_replay(base):
    stages = strict_json((base / 'discovery.json').read_text())
    journal = strict_json((base / 'transports.json').read_text())
    require(len(journal['requests']) >= 3 and all(not stage['errors'] for stage in stages.values()),
            'base_search_incomplete')
    return {'label': base.name, 'stages': stages, 'requests': journal['requests']}


def measure_search(client, args, output, fixture, target_for_log, replay=None):
    sources, private, public, pool = fixture
    prompt, _, kinds = prompts_and_kinds()
    stages = {}
    for name, text in sources.items():
        if replay and not name.endswith('.log'):
            stages[name] = reuse_discovery(client, replay, name)
            continue
        client.measurement_stage = f'discovery:{name}'
        args.target_input_tokens = target_for_log if name.endswith('.log') else 0
        before = len(client.records)
        print(client.model, output.name, 'search', name, flush=True)
        try:
            found = discover(client, text, prompt, kinds, args, client.save_history, {})
        except ValueError as exc:
            found = {'values': [], 'errors': [{'error': str(exc)}]}
        calls = client.records[before:]
        stages[name] = {**found, 'http_seconds': sum(c['http_wall_seconds'] for c in calls),
                        'requests': len(calls), 'completed_candidates': len(found['values'])}
        atomic_json(output / 'discovery.json', stages)

    atomic_json(output / 'discovery.json', stages)
    return apply_search(client, output, fixture, stages)


def apply_search(client, output, fixture, stages):
    sources, private, public, pool = fixture
    hashes = {name: hashlib.sha256(t.encode()).hexdigest() for name, t in sources.items()}
    applied = helpers['apply_stage'](client.model, output.name, stages, sources, private, public, pool, hashes, output)
    documents = applied['application']
    private_count, public_count = total(private, sources), total(public, sources)
    full = sum(row['private_spans_fully_covered'] for row in documents.values())
    lost = sum(row['public_occurrences_lost'] for row in documents.values())
    public_doc, = [name for name in sources if not private[name]]
    guide = documents[public_doc]['replacements']
    http = applied['http_seconds']
    quality = 50 * full / private_count + 15 * (public_count-lost) / public_count + 5 / (1+guide)
    return {'completed': all(not v['errors'] for v in stages.values()),
            'private_full': full, 'public_lost': lost, 'reference_replacements': guide,
            'private_total': private_count, 'public_total': public_count, 'http_seconds': http,
            'exact_roundtrips': applied['exact_roundtrips'], 'documents': documents,
            'quality_70': quality, 'score_100': quality + 30*693/(693+http)}


def measure_log_cap(client, output, fixture, base, limit):
    replay = load_replay(base)
    stages = replay['stages']
    for name, stage in stages.items():
        measurement = f'discovery:{name}'
        if not name.endswith('.log'):
            reuse_discovery(client, replay, name)
            continue
        old, = [r for r in replay['requests'] if r['record']['measurement_stage'] == measurement]
        prompt, message = old['template_request']['messages']
        value = strict_json(message['content'])
        require(value['source'] == fixture[0][name], 'paired_log_source_changed')
        schema = deepcopy(old['request']['json_schema'])
        schema['properties']['candidates']['maxItems'] = limit
        client.measurement_stage = measurement
        print(client.model, output.name, 'search', name, flush=True)
        found = {}
        errors = []
        try:
            reply = client.infer(prompt['content'], value, schema, old['request']['n_predict'])
            for row in reply['candidates']:
                quoted = row['value']
                if 3 <= len(quoted.encode()) <= 512 and quoted.strip() == quoted and quoted in value['source']:
                    found.setdefault(quoted, row)
            client.records[-1].update(candidate_count=len(reply['candidates']), unique_grounded_count=len(found))
        except Exception as exc:
            errors.append({'error': type(exc).__name__, 'code': str(exc)[:160]})
        new = client.history[-1]
        require(dict(old['request'], json_schema=schema) == new['request'], 'paired_log_request_changed')
        client.save_history()
        stages[name] = dict(stage, values=list(found.values()), errors=errors,
                            completed_candidates=len(found), http_seconds=client.records[-1]['http_wall_seconds'])
    atomic_json(output / 'discovery.json', stages)
    return apply_search(client, output, fixture, stages)


def measure_review(client, output):
    _, expected, public, all_sources, _ = load_corpus()
    sources = {name: all_sources[name] for name in DOCUMENTS}
    cases, meta = prepare_cases(REPO / 'tests/fixtures/context-control-candidates.json',
                                sources, expected, public, 32)
    require(meta['reference_private'] == meta['reference_public'] == 16, 'review_fixture_changed')
    instruction = prompts((REPO / 'docs/experiments/privacy-policy-v1.txt').read_text())['D']
    _, _, kinds = prompts_and_kinds()
    before = len(client.records)
    decisions = {}
    batches = common_batches(cases, DOCUMENTS, client.profile['batch_size'])
    for i, batch in enumerate(batches, 1):
        client.measurement_stage = f'D:{i}:{batch[0].file}'
        value, contexts = payload('D', batch, sources)
        print(client.model, 'D', i, 'of', len(batches), batch[0].file, flush=True)
        try:
            reply = client.infer(instruction, value, schema('D', batch, kinds), client.output_tokens)
            decisions.update(validate(reply, batch, contexts, kinds, 'D'))
        except Exception as exc:
            decisions.update({c.id: technical_review(c, str(exc)[:120]) for c in batch})
        atomic_json(output / 'review-decisions.json', decisions)
    http = sum(c['http_wall_seconds'] for c in client.records[before:])
    quality = metrics(cases, decisions, expected)
    score = 50*quality['private_mask']/16 + 20*quality['public_keep']/16 + 30*3106.4891/(3106.4891+http)
    return {'metrics': quality, 'http_seconds': http, 'batches': len(batches), 'score_100': score,
            'case_file_sha256': file_sha(REPO / 'tests/fixtures/context-control-candidates.json')}


def measure(model, option, phase, cpus, target_for_log=0, run_review=False, log_cap=0, reuse=False):
    label, settings = profile_for(model, option, phase)
    base = OUTPUT / model / phase / label
    if target_for_log:
        label += f'-log-{target_for_log}'
    if log_cap:
        label += f'-log-cap-{log_cap}'
        settings.update(log_cap=log_cap, transport_timeout_seconds=1800)
    if log_cap or reuse:
        settings['reused_nonlog_from'] = base.name
    output = OUTPUT / model / phase / label
    if (output / 'result.json').exists():
        return strict_json((output / 'result.json').read_text())
    output.mkdir(parents=True, exist_ok=False)
    plan = {'model': model, 'profile': settings, 'phase': phase, 'threads': len(cpus),
            'cpus': cpus, 'log_target_input_tokens': target_for_log, 'artifact': FILES[model],
            'runtime_sha256': file_sha(RUNTIME), 'binary_sha256': file_sha(BINARY)}
    atomic_json(output / 'plan.json', plan)
    fixture = short_fixture() if phase == 'pilot' else helpers['corpus']()
    with TemporaryDirectory(prefix='kaponir-model-tuning-') as path:
        home = Path(path)
        worker = Worker(home, configuration(home, {'model_dir': str(STUDY / 'models'), 'runtime': str(RUNTIME),
            'threads': len(cpus), 'ocr_timeout_seconds': settings['worker_configuration_timeout_seconds']}), 'unused')
        try:
            sampling = {k: settings[k] for k in ('temperature', 'top_p', 'top_k', 'min_p', 'seed')}
            client = ValidatedClient(worker, model, settings['context_tokens'], settings['output_tokens'],
                                    settings['response_format'], sampling, settings, output, [])
            full_args = Namespace(**settings, candidate_mode='typed', strategy='auto', target_input_tokens=0)
            if log_cap:
                search = measure_log_cap(client, output, fixture, base, log_cap)
            else:
                replay = load_replay(base) if reuse else None
                search = measure_search(client, full_args, output, fixture, target_for_log, replay)
            result = {'label': label, 'option': option, 'plan': plan, 'search': search}
            atomic_json(output / 'result.json', result)
            print(model, phase, label, 'search summary', {k: search[k] for k in
                ('completed', 'private_full', 'public_lost', 'reference_replacements', 'http_seconds')}, flush=True)
            if run_review and search['completed']:
                result['D'] = measure_review(client, output)
                atomic_json(output / 'result.json', result)
                print(model, label, 'D summary', result['D'], flush=True)
            return result
        finally:
            worker.stop_runtime()


def summary_line(r):
    keys = ('completed', 'private_full', 'public_lost', 'reference_replacements', 'http_seconds', 'quality_70')
    return {'label': r['label'], **{k: r['search'][k] for k in keys}}


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('model', choices=OPTIONS)
    parser.add_argument('phase', choices=('pilot', 'full'))
    parser.add_argument('--profile')
    parser.add_argument('--log-target', type=int, default=0)
    parser.add_argument('--log-cap', type=int, default=0)
    parser.add_argument('--cpu-start', type=int)
    parser.add_argument('--reuse-other-docs', action='store_true')
    parser.add_argument('--review', action='store_true')
    args = parser.parse_args()
    cores = sorted(os.sched_getaffinity(0))
    start = args.cpu_start if args.cpu_start is not None else (0 if args.model == GRANITE else 2)
    cpus = cores[start:start+2]
    require(len(cpus) == 2, 'two_physical_worker_cpu_slots_required')
    os.sched_setaffinity(0, cpus)
    verify_inputs(args.model)
    options = OPTIONS[args.model]
    if args.log_cap:
        require(args.model == NANBEIGE and args.phase == 'full' and args.profile == 'direct-greedy-schema'
                and not args.log_target and not args.review and args.log_cap > 24, 'invalid_log_cap_trial')
    if args.reuse_other_docs:
        require(args.phase == 'full' and args.profile and args.log_target and not args.review,
                'invalid_log_replay')
    if args.phase == 'pilot':
        selected = options if args.profile is None else [next(o for o in options if o[0] == args.profile)]
    else:
        if args.profile is None:
            pilots = [strict_json((OUTPUT / args.model / 'pilot' / option[0] / 'result.json').read_text())
                      for option in options]
            complete = [r for r in pilots if r['search']['completed']]
            winner = max(complete, key=lambda r:(r['search']['quality_70'], -r['search']['http_seconds']))
            selected = [tuple(winner['option'])]
            print(args.model, 'pilot winner', summary_line(winner), flush=True)
        else:
            selected = [next(o for o in options if o[0] == args.profile)]
    for option in selected:
        measure(args.model, option, args.phase, cpus, args.log_target, args.review, args.log_cap,
                args.reuse_other_docs)


if __name__ == '__main__':
    main()
