import os
import sys
from pathlib import Path
from tempfile import TemporaryDirectory

from evaluate_privacy_policy import request_raw
from kaponir_worker import Worker, configuration, http_json
from recover_privacy_transport import wait_for_verified_model
from run_native_model_retest import DEFAULT_STUDY

model = sys.argv[1]
runtime = DEFAULT_STUDY / 'runtime/llama-b12038/llama-server'
os.sched_setaffinity(0, sorted(os.sched_getaffinity(0))[:2] if model.startswith('granite')
                    else sorted(os.sched_getaffinity(0))[2:4])
schema = {'type': 'object', 'properties': {'answer': {'type': 'string'}}, 'required': ['answer'],
          'additionalProperties': False}
messages = [{'role': 'system', 'content': 'Return a JSON object with one string field named answer.'},
            {'role': 'user', 'content': 'Write Sweden in the answer field.'}]
with TemporaryDirectory(prefix='kaponir-parameter-probe-') as td:
    home = Path(td)
    worker = Worker(home, configuration(home, {'model_dir': str(DEFAULT_STUDY / 'models'),
        'runtime': str(runtime), 'threads': 2, 'ocr_timeout_seconds': 60}), 'unused')
    try:
        wait_for_verified_model(worker, model, timeout=120)
        job = worker.submit('evaluate', model=model)
        worker.start_runtime(job['id'], model, 1, context_tokens=16384, reasoning='auto',
            reasoning_format='deepseek', reasoning_budget=256)
        print('runtime schema support', worker.process_supports_json_schema)
        for thinking in (False, True):
            kwargs = {'enable_thinking': thinking}
            rendered = http_json(worker.ocr_base+'/apply-template', {'messages': messages,
                'chat_template_kwargs': kwargs, 'add_generation_prompt': True})['prompt']
            print('thinking', thinking, 'rendered suffix', repr(rendered[-84:]), flush=True)
            common = {'top_p':.95,'top_k':20,'temperature':.6,'seed':42,'cache_prompt':False,'stream':False}
            requests = [
                ('chat-grammar', '/v1/chat/completions', dict(common, model='qwen-cpu', messages=messages,
                    chat_template_kwargs=kwargs, max_tokens=96, response_format={'type':'json_schema',
                        'json_schema':{'name':'probe','schema':schema,'strict':True}})),
                ('chat-prompt', '/v1/chat/completions', dict(common, model='qwen-cpu', messages=messages,
                    chat_template_kwargs=kwargs, max_tokens=96)),
            ]
            if not thinking:
                requests.append(('raw-grammar','/completion',dict(common,prompt=rendered,n_predict=96,json_schema=schema)))
            for label, route, req in requests:
                try:
                    reply = http_json(worker.ocr_base+route, req, timeout=35)
                    if 'choices' in reply:
                        choice = reply['choices'][0]
                        print(label, choice.get('finish_reason'), repr(choice.get('message'))[:420], flush=True)
                    else:
                        print(label, reply.get('stop_type'), repr(reply.get('content'))[:320], flush=True)
                except Exception as exc:
                    raw = request_raw(worker.ocr_base+route, req, 35) if hasattr(exc, 'code') else None
                    if raw:
                        import base64
                        print(label, raw['status'], base64.b64decode(raw['body_base64']).decode()[:400], flush=True)
                    else:
                        print(label, type(exc).__name__, flush=True)
    finally:
        worker.stop_runtime()
