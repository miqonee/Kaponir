"""Measure the LFM tuning candidates on the frozen three-document search corpus."""

from argparse import ArgumentParser, Namespace
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
import time

from apply_measured_privacy import apply_documents
from apply_scheme_masks import select_masks
from check_learning_corpus import load_corpus, occurrences
from compare_local_models import DOCUMENTS
from evaluate_model_schemes import EXPORT, EXPORT_CANONICAL_SHA, EXPORT_SHA, MeasuredClient
from evaluate_privacy_policy import RUNTIME_SHA256
from evaluate_validation_schemes import frozen_detector_pool
from experiment_inference import discover, prompts_and_kinds
from kaponir_worker import Worker, configuration
from native_model_profiles import catalog_for
from privacy_expansion_profiles import research_registration
from report_complete_research import legacy_summary
from report_native_model_retest import verified_application
from run_native_model_retest import DEFAULT_STUDY
from run_privacy_policy_suite import SuiteLock, atomic_json, file_sha, runtime_processes
from summarize_privacy_policy import digest, require, strict_json
from validation_pipeline import Candidate, opaque_id


LFM12, LFM26, LFM8 = 'lfm2.5-1.2b-instruct', 'lfm2.5-2.6b', 'lfm2.5-8b-a1b'
CHANGES = {LFM26: {'reasoning_budget': 384}, LFM8: {'reasoning_budget': 768}, LFM12: {'temperature': 0.0}}
ROOT = DEFAULT_STUDY
WORK = Path(__file__).resolve().parent / 'kaponir-hybrid-pilot' / 'lfm-large'
RUNTIME = ROOT / 'runtime/llama-b12038/llama-server'
BINARY = ROOT / 'build/release/kaponir'
LOG = next(name for name in DOCUMENTS if name.endswith('.log'))
LOG_INPUT_TARGET = 4096 - 1600 - 64


def read(path):
    return strict_json(path.read_text())


def originals(model, sources, binary_sha):
    folder = ROOT / 'schemes' / model
    result = folder / 'result.json'
    plan = read(folder / 'scheme-plan.json')
    journal = read(folder / 'transports.json')
    state = read(result)
    require(state['status'] == 'completed' and plan['model'] == journal['model'] == model
            and state['transport_journal_sha256'] == file_sha(folder / 'transports.json')
            and plan['expected_runtime_sha256'] == RUNTIME_SHA256, 'baseline_sources_changed')
    hashes = {name: hashlib.sha256(source.encode()).hexdigest() for name, source in sources.items()}
    require(plan['source_sha256'] == hashes and journal['profile'] == plan['profile'], 'baseline_profile_changed')
    from apply_scheme_masks import complete_discovery_snapshot
    complete_discovery_snapshot(state, plan, journal)
    existing_application = ROOT / 'application/schemes' / model / 'current_union'
    verified = verified_application(existing_application, legacy_summary(result, False), result, 'current_union',
                                    binary_sha, archived=False)
    require(verified is not None and verified['exact_roundtrips'] == 6, 'baseline_application_changed')
    applied = read(existing_application / 'result.json')
    calls = {name: [row for row in journal['requests']
                    if row['record']['measurement_stage'] == f'discovery:{name}'] for name in sources}
    require(all(len(rows) == 1 and rows[0]['request_sha256'] == digest(rows[0]['request'])
                and json.loads(rows[0]['request']['messages'][-1]['content'])['source'] == sources[name]
                for name, rows in calls.items()), 'baseline_discovery_fragments_changed')
    return {
        'profile': plan['profile'], 'artifact': plan['model_artifact'], 'source_sha256': hashes,
        'plan_sha256': file_sha(folder / 'scheme-plan.json'), 'journal_sha256': file_sha(folder / 'transports.json'),
        'result_sha256': file_sha(result), 'application_sha256': file_sha(existing_application / 'result.json'),
        'requests': {name: rows[0] for name, rows in calls.items()},
        'discovery': {name: state['stages'][f'discovery:{name}'] for name in sources},
        'application': {row['file']: row for row in applied['documents'] if row['mode'] == 'model_masks_added'},
    }


def measured_requests_ok(entries, archived, source, change, target_tokens):
    expected = dict(archived['request'])
    expected.update({key: value for key, value in change.items() if key == 'temperature'})
    same_body = lambda request: {key: val for key, val in request.items() if key not in ('messages', 'max_tokens')}
    require(entries and all(same_body(row['request']) == same_body(expected)
                and row['request']['messages'][0] == expected['messages'][0]
                and json.loads(row['request']['messages'][-1]['content'])['source'] in source
                and row['request_sha256'] == digest(row['request']) for row in entries),
            'request_changed_outside_trial_settings')
    if not target_tokens:
        require(entries[0]['request'] == expected and
                entries[0]['rendered_prompt_sha256'] == archived['rendered_prompt_sha256'],
                'standard_discovery_request_not_matched')
    else:
        require(len(entries) > 1 and all(row['record']['input_tokens'] <= target_tokens for row in entries),
                'log_chunk_cutoff_not_applied')


def explore(model, baseline, sources, profile, output, change, target_tokens=0):
    output.mkdir(parents=True)
    settings = Namespace(**profile, candidate_mode='typed', strategy='auto', target_input_tokens=target_tokens)
    history, results = [], {}
    prompt, _, kinds = prompts_and_kinds()
    with TemporaryDirectory(prefix='kaponir-lfm-large-') as location:
        home = Path(location)
        worker = Worker(home, configuration(home, {'model_dir': str(ROOT / 'models'), 'runtime': str(RUNTIME),
            'threads': 2, 'ocr_timeout_seconds': profile['worker_configuration_timeout_seconds']}), 'unused')
        try:
            generation = {key: profile[key] for key in ('temperature', 'top_p', 'top_k', 'min_p', 'seed')}
            client = MeasuredClient(worker, model, profile['context_tokens'], profile['output_tokens'],
                                    profile['response_format'], generation, profile, output, history)
            progress = {}
            for name, text in sources.items():
                client.measurement_stage = f'discovery:{name}'
                first = len(history)
                print(model, output.name, name, 'running', flush=True)
                stage = discover(client, text, prompt, kinds, settings, client.save_history, progress.setdefault(name, {}))
                requests = history[first:]
                measured_requests_ok(requests, baseline['requests'][name], text, change, target_tokens)
                results[name] = {**stage, 'requests': len(requests),
                    'http_seconds': sum(row['record']['http_wall_seconds'] for row in requests),
                    'input_tokens': [row['record']['input_tokens'] for row in requests],
                    'reasoning_tokens': sum(row['record']['reasoning_text_tokens'] for row in requests),
                    'output_tokens': sum(row['record']['usage']['completion_tokens'] for row in requests)}
                atomic_json(output / 'discovery.json', results)
                print(model, output.name, name, 'done', stage['calls'], len(stage['errors']),
                      round(results[name]['http_seconds'], 2), flush=True)
        finally:
            worker.stop_runtime()
    require(all(not stage['errors'] for stage in results.values()), 'tuned_discovery_incomplete')
    return results


def apply_stage(model, label, data, sources, private, public, pool, hashes, output):
    union = {(case.file, case.value): case for case in pool}
    for name, stage in data.items():
        for row in stage['values']:
            value = row['value']
            offset = sources[name].index(value)
            union.setdefault((name, value), Candidate(opaque_id(name, value), name, value, offset,
                offset + len(value), row['kind'], origin='discovery_llm'))
    stage = {'candidates': [case.json() for case in union.values()],
             'decisions': {case.id: {'valid': True, 'verdict': 'mask'} for case in union.values()}}
    masks, protected = select_masks(stage, sources)
    verified = apply_documents(BINARY, output / 'apply', hashes, sources, private, public, masks,
        {'model': model, 'variant': label, 'stage': 'current_union', 'protected_mask_values_selected': protected})
    return {'application': {row['file']: row for row in verified['documents'] if row['mode'] == 'model_masks_added'},
            'exact_roundtrips': verified['exact_roundtrips'], 'discovery': data,
            'http_seconds': sum(stage['http_seconds'] for stage in data.values())}


def corpus():
    _, expected, public, sources, _ = load_corpus()
    sources = {name: sources[name] for name in DOCUMENTS}
    private = {name: [value for doc, value in expected if doc == name] for name in sources}
    public = {name: public[name] for name in sources}
    for values, total in ((private, 193), (public, 87)):
        require(sum(len(occurrences(sources[name], value)) for name in sources for value in values[name]) == total,
                'corpus_annotation_counts_changed')
    require(file_sha(EXPORT) == EXPORT_SHA, 'frozen_detector_archive_changed')
    pool, exported = frozen_detector_pool(EXPORT, sources)
    require(hashlib.sha256(json.dumps(exported, sort_keys=True).encode()).hexdigest() == EXPORT_CANONICAL_SHA,
            'frozen_detector_export_changed')
    return sources, private, public, pool


def run_model(model, cpus):
    os.sched_setaffinity(0, cpus)
    fixture = read(WORK / 'plan.json')
    sources, private, public, pool = corpus()
    anchor = originals(model, sources, fixture['binary_sha256'])
    require(anchor['plan_sha256'] == fixture['references'][model]['plan_sha256']
            and anchor['journal_sha256'] == fixture['references'][model]['journal_sha256'], 'baseline_anchor_changed')
    name, size, sha, _ = anchor['artifact']
    model_path = ROOT / 'models' / name
    require(model_path.stat().st_size == size and file_sha(model_path) == sha, 'model_weights_changed')
    analysis = {
        name: {**data, 'requests': 1, 'reused': True, 'http_seconds': anchor['requests'][name]['record']['http_wall_seconds'],
               'reasoning_tokens': anchor['requests'][name]['record']['reasoning_text_tokens'],
               'output_tokens': anchor['requests'][name]['record']['usage']['completion_tokens']}
        for name, data in anchor['discovery'].items()
    }
    check = {'recommended': {'application': anchor['application'], 'discovery': analysis,
                             'exact_roundtrips': 6, 'http_seconds': sum(d['http_seconds'] for d in analysis.values())}}
    folder = WORK / model
    change = CHANGES[model]
    label = 'temperature-0' if model == LFM12 else f'budget-{change["reasoning_budget"]}'
    with research_registration(model, catalog_for(model)):
        output = folder / label
        settings = {**anchor['profile'], **change}
        discovery = explore(model, anchor, sources, settings, output, change)
        check[label] = apply_stage(model, label, discovery, sources, private, public, pool, anchor['source_sha256'], output)
        atomic_json(folder / 'result.json', check)
        if model == LFM12:
            label = 'log-chunks'
            output = folder / label
            logs = explore(model, anchor, {LOG: sources[LOG]}, anchor['profile'], output, {}, LOG_INPUT_TARGET)
            check[label] = apply_stage(model, label, {**analysis, **logs}, sources, private, public, pool,
                                       anchor['source_sha256'], output)
            atomic_json(folder / 'result.json', check)
    print(model, 'applied', len(check) - 1, 'new variants', flush=True)


def run():
    require(not WORK.exists() and file_sha(RUNTIME) == RUNTIME_SHA256, 'existing_large_run_or_wrong_runtime')
    binary_sha = file_sha(BINARY)
    require(binary_sha == read(ROOT / 'status.json')['binary_sha256'], 'application_binary_changed')
    sources, _, _, _ = corpus()
    archived = {model: originals(model, sources, binary_sha) for model in CHANGES}
    references = {model: {key: row[key] for key in ('plan_sha256', 'journal_sha256', 'result_sha256',
                                                    'application_sha256', 'artifact', 'profile')}
                  for model, row in archived.items()}
    cores = sorted(os.sched_getaffinity(0))
    slots = [cores[offset:offset + 2] for offset in range(0, min(4, len(cores)) - 1, 2)]
    require(slots, 'not_enough_cpu_for_large_checks')
    jobs = list(CHANGES)
    with SuiteLock(ROOT / '.native-retest.lock'):
        require(not runtime_processes(RUNTIME), 'runtime_already_running')
        atomic_json(WORK / 'plan.json', {'references': references, 'changes': CHANGES, 'binary_sha256': binary_sha,
            'runtime_sha256': RUNTIME_SHA256, 'script_sha256': file_sha(Path(__file__)),
            'detector_sha256': EXPORT_SHA, 'source_sha256': archived[LFM12]['source_sha256'],
            'cpu_affinities': slots, 'test_fixture_scope': 'frozen full adding-search corpus',
            'lfm12_log_input_token_target': LOG_INPUT_TARGET})
        errors, active = {}, {}
        while jobs or active:
            for index, (model, child) in list(active.items()):
                status = child.poll()
                if status is not None:
                    if status:
                        errors[model] = status
                    del active[index]
            for index, cpus in enumerate(slots):
                if jobs and index not in active:
                    model = jobs.pop(0)
                    child = subprocess.Popen([sys.executable, '-Bu', __file__, '--model', model,
                                                '--cpus', ','.join(map(str, cpus))])
                    active[index] = (model, child)
            if active:
                time.sleep(0.5)
        require(not runtime_processes(RUNTIME), 'runtime_not_cleaned_up')
    records = {model: read(WORK / model / 'result.json') for model in CHANGES if (WORK / model / 'result.json').is_file()}
    atomic_json(WORK / 'summary.json', {'status': 'partial' if errors else 'completed', 'process_errors': errors,
        'plan_sha256': file_sha(WORK / 'plan.json'), 'models': records})
    print('large LFM probes finished', len(records), errors, flush=True)


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('--model')
    parser.add_argument('--cpus')
    args = parser.parse_args()
    if args.model:
        run_model(args.model, [int(cpu) for cpu in args.cpus.split(',')])
    else:
        run()
