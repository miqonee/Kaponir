"""Dispatch the remaining predeclared calibration jobs on two disjoint CPU pairs."""
from pathlib import Path
import json
import subprocess
import sys
import time

base=Path(__file__).resolve().parent
root=base/'kaponir-hybrid-pilot/four-models-fresh-v1'
baseopt={'nano':'split-t020','lfm':'split-copy192','gemma':'greedy-rep108','qwen':'split-cool'}
def result(key,phase,opt):
    p=root/key/(phase+'-'+opt)/'result.json'
    return json.loads(p.read_text()) if p.exists() else None
def plans():
    tests={'nano':[baseopt['nano'],'wide-t020'],'lfm':[baseopt['lfm'],'split-nohint384'],'qwen':None,'gemma':None}
    q=result('qwen','full','split-cool')
    if q is not None:
        tests['qwen']=['split-cool']
        if not q['completed'] or q['score']<78.69: tests['qwen'].append('split-greedy')
    g=result('gemma','full','greedy-rep108')
    short=result('gemma','guide','short-thought')
    if g is not None and short is not None:
        tests['gemma']=['greedy-rep108']
        if not (g['completed'] and g['H']>=190 and g['P']<=2 and g['R']<=4):
            guides={opt:result('gemma','guide',opt) for opt in ('short-thought','greedy-rep108')}
            valid=[opt for opt,r in guides.items() if r and r['completed'] and r['P']<5 and r['R']<7]
            if valid:
                opt=min(valid,key=lambda k:(guides[k]['P'],guides[k]['R'],guides[k]['http_seconds']))
                tests['gemma'].append('short-thought384-long-direct' if opt=='short-thought' else 'short-rep108-long-direct')
    return tests
def expected(tests):
    jobs=[]; chosen={}
    for key in ('nano','gemma','lfm','qwen'):
        if tests[key] is None:continue
        for opt in tests[key]:
            if opt!=baseopt[key]:jobs.append((key,'full',opt))
    for key in ('nano','gemma','qwen','lfm'):
        if tests[key] is None:continue
        jobs.append((key,'holdout','baseline'))
        trials=[result(key,'full',opt) for opt in tests[key]]
        if all(x is not None for x in trials):
            valid=[x for x in trials if x['completed']]
            if valid:
                opt=max(valid,key=lambda x:x['score'])['option']
                chosen[key]=opt
                jobs.append((key,'holdout',opt))
    return jobs,chosen
active={};failed=set()
while True:
    for cpu,(job,p) in list(active.items()):
        code=p.poll()
        if code is not None:
            print('END',job,'cpu',cpu,'code',code,flush=True)
            if code or result(*job) is None:failed.add(job)
            del active[cpu]
    tests=plans();jobs,chosen=expected(tests)
    lanes={0:result('nano','full','split-t020') is not None,2:result('gemma','guide','short-thought') is not None}
    for cpu,ready in lanes.items():
        if not ready or cpu in active:continue
        running={pair[0] for pair in active.values()}
        pending=[j for j in jobs if j not in running|failed and result(*j) is None]
        if not pending:continue
        job=pending[0];key,phase,opt=job
        script='tune-kaponir-four.py' if phase=='full' else 'holdout-kaponir-four.py'
        args=[key,opt,phase,str(cpu)] if phase=='full' else [key,opt,str(cpu)]
        print('START',job,'cpu',cpu,flush=True)
        child=subprocess.Popen([sys.executable,'-Bu',str(base/script),*args])
        active[cpu]=(job,child)
    if all(lanes.values()) and not active and all(tests[k] is not None for k in tests):
        if all(result(*j) is not None or j in failed for j in jobs):
            (root/'selection.json').write_text(json.dumps({'available':tests,'selected':chosen,'failed':sorted(failed)},indent=2)+'\n')
            print('ALL',chosen,failed,flush=True)
            break
    time.sleep(2)
