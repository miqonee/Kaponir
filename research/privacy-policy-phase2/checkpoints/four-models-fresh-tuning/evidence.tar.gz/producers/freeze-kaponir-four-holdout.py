from pathlib import Path
import hashlib
import json

from check_learning_corpus import occurrences
from evaluate_validation_schemes import detector_pool
from run_native_model_retest import DEFAULT_STUDY
from run_privacy_policy_suite import atomic_json, file_sha
from summarize_privacy_policy import require

out=Path(__file__).with_name('kaponir-hybrid-pilot')/'four-models-fresh-v1'/'holdout'
out.mkdir(exist_ok=False)
corpus=[
    ('handover-cost.md',
     '# Смета на обслуживание\n'
     'Заказчик ООО «Талый Берег» согласовал закрытый проект «Мятный Парус». '
     'Ответственная Алина Чернова просит отправить экземпляр на alina.chernova@talbereg.test.\n'
     'Публичные условия договора: НДС 20%, валюта RUB. '
     'Формат приложения PDF. Проект «Мятный Парус» включён в заявку заказа TB-59214.\n',
     ['Талый Берег','Мятный Парус','Алина Чернова','alina.chernova@talbereg.test','TB-59214'],
     ['НДС 20%','RUB','PDF']),
    ('mirror-worker.log',
     '2026-10-06T07:20:01Z INFO format=JSON method=POST status=202 Accepted\n'
     'tenant=brume-river service=reed-lantern host=node03.brume.int client_ip=10.181.43.27\n'
     '2026-10-06T07:20:04Z WARN service=reed-lantern order=BR-78302 account=acorn-mira\n'
     'source=/srv/brume/exports/batch_61.csv protocol=HTTPS trace=sample-07\n'
     '2026-10-06T07:20:05Z INFO service=reed-lantern tenant=brume-river file=/srv/brume/exports/batch_61.csv\n'
     'owner=mira@brume.test client_ip=10.181.43.27 method=GET status=200 OK trace=sample-07\n',
     ['brume-river','reed-lantern','node03.brume.int','10.181.43.27','BR-78302','acorn-mira',
      '/srv/brume/exports/batch_61.csv','mira@brume.test'],
     ['JSON','POST','202 Accepted','HTTPS','sample-07','GET','200 OK']),
    ('http-guide.md',
     '# Открытая памятка по протоколам\n'
     'HTTP и HTTPS поддерживают методы GET и HEAD. '
     'Код 304 Not Modified позволяет использовать кэш. '
     'Примеры опубликованы на https://www.rfc-editor.org/ в стандарте RFC 9110. '
     'Формат JSON использует кодировку UTF-8. Лицензия документа CC BY 4.0.\n',
     [],['HTTP','HTTPS','GET','HEAD','304 Not Modified','https://www.rfc-editor.org/','RFC 9110','JSON','UTF-8','CC BY 4.0'])
]
sources={n:s for n,s,_,_ in corpus}
private={n:p for n,_,p,_ in corpus}; public={n:p for n,_,_,p in corpus}
require(all(len(set(p+q))==len(p+q) and all(x in s for x in p+q) for _,s,p,q in corpus),'bad_labels')
counts={n:{'private':sum(len(occurrences(s,x)) for x in p),'public':sum(len(occurrences(s,x)) for x in q)} for n,s,p,q in corpus}
count=lambda m:sum(v[m] for v in counts.values())
binary=DEFAULT_STUDY/'build/release/examples/detector_candidates'
_,export=detector_pool(binary,sources)
atomic_json(out/'detectors.json',export)
atomic_json(out/'fixture.json', {'sources':sources,'private':private,'public':public,'counts':counts,
    'source_sha256':{n:hashlib.sha256(t.encode()).hexdigest() for n,t in sources.items()},
    'detectors_sha256':file_sha(out/'detectors.json'),'detector_binary_sha256':file_sha(binary)})
print(counts, count('private'), count('public'),file_sha(out/'fixture.json'))
