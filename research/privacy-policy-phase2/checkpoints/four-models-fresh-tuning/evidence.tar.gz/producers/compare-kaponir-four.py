"""Compare private occurrence coverage and changed public controls against the prior full presets."""
from collections import Counter
from pathlib import Path
import json
from apply_measured_privacy import occurrences
from check_learning_corpus import load_corpus
from run_native_model_retest import DEFAULT_STUDY

base=Path(__file__).with_name('kaponir-hybrid-pilot')
root=base/'four-models-fresh-v1'
prior={'gemma':base/'gemma-qat-direct-full-v1/apply',
       'nano':base/'granite-nanbeige-v1/nanbeige42-3b/full/direct-greedy-schema/apply',
       'lfm':base/'lfm-large/lfm2.5-2.6b/budget-384/apply',
       'qwen':DEFAULT_STUDY/'application/schemes/qwen3.5-4b/current_union'}
_,expected,public,sources,_=load_corpus()
def summarize(folder,n):
    d,=(folder/'model_masks_added').glob('*-'+Path(n).stem)
    mask=json.loads((d/'mask.json').read_text());orig=sources[n];b=orig.encode()
    intervals=[(r['start'],r['end']) for r in mask['replacements']]
    private={}
    for doc,value in expected:
        if doc!=n:continue
        for m in occurrences(orig,value):
            start,end=len(orig[:m.start()].encode()),len(orig[:m.end()].encode())
            private[(value,start,end)]=sum(max(0,min(end,v)-max(start,u)) for u,v in intervals)==end-start
    lost={}
    for name in public[n]:
        delta=max(0,len(occurrences(orig,name))-len(occurrences(mask['text'],name)))
        if delta:lost[name]=delta
    return private,lost
def compare(old,new):
    out={}
    for entry in json.loads((new/'result.json').read_text())['documents']:
        n=entry['file']
        if entry['mode']!='model_masks_added':continue
        oldp,oldloss=summarize(old,n);newp,newloss=summarize(new,n)
        gains=Counter(k[0] for k in oldp if not oldp[k] and newp[k]); drops=Counter(k[0] for k in oldp if oldp[k] and not newp[k])
        out[n]={'gained':dict(gains),'lost':dict(drops),'public_before':oldloss,'public_after':newloss}
    return out
if __name__=='__main__':
    for p in sorted(root.glob('*/full-*/result.json')):
        r=json.loads(p.read_text())
        if r['completed']:
            result=compare(prior[p.parts[-3]],p.parent/'apply');print(p.parts[-3:-1],json.dumps(result,ensure_ascii=False))
