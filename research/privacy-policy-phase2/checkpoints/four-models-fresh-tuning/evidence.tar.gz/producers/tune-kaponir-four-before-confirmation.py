"""Recalibrate four pinned models with new inference and identical grounding and mask application."""
from argparse import ArgumentParser, Namespace
from contextlib import contextmanager
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import runpy
from tempfile import TemporaryDirectory
import time

from experiment_inference import discover, prompts_and_kinds
from kaponir_worker import FILES, Worker, configuration
from native_model_profiles import catalog_for
from privacy_expansion_profiles import research_registration
from run_privacy_policy_suite import atomic_json, file_sha
from summarize_privacy_policy import require, strict_json

HERE = Path(__file__).resolve().parent
BASE = runpy.run_path(str(HERE / 'check-kaponir-granite-nanbeige.py'))
LARGE = BASE['helpers']
STUDY, RUNTIME, BINARY = (LARGE[k] for k in ('ROOT','RUNTIME','BINARY'))
ROOT = HERE / 'kaponir-hybrid-pilot' / 'four-models-fresh-v1'
MODELS = {'nano': 'nanbeige42-3b', 'lfm': 'lfm2.5-2.6b', 'gemma': 'gemma4-e4b-qat', 'qwen': 'qwen3.5-4b'}
# Shared seed, prompt, allowed categories, response schema and mask application.
# Each tuple is temperature, top-p, logits penalty, thinking budget, log input target in tokens.
# For Nano, only the log uses the sampled temperature; ordinary documents retain greedy decoding.
OPTIONS = {
    'nano': {'split-t020': (.2,.95,0,-1,1792), 'split-greedy': (0,.95,0,-1,1792), 'wide-t020': (.2,.95,0,-1,2304)},
    'lfm': {'split-copy192': (.1,.95,1.0,192,1280), 'split-copy512': (.1,.95,1.0,512,1280),
            'split-vendor384': (.1,.95,1.1,384,1792), 'split-nohint384': (.1,.95,1.0,384,1536)},
    'gemma': {'soft025': (.25,.95,1.0,-1,0), 'greedy-rep108': (0,.95,1.08,-1,0),
              'short-thought': (0,.95,1.0,384,0), 'short-thought384-long-direct': (0,.95,1.0,384,0), 'soft010': (.1,.95,1.0,-1,0), 'short-rep108-long-direct': (0,.95,1.0,-1,0)},
    'qwen': {'split-cool': (.2,.90,0,-1,1536), 'split-greedy': (0,.95,0,-1,2432),
             'split-card': (.7,.8,1.5,-1,1536)},
}

def recipe(key, name):
    temperature, top_p, penalty, budget, target = OPTIONS[key][name]
    model=MODELS[key]
    if key == 'nano':
        _, settings = BASE['profile_for'](model, ('direct-greedy-schema',0,-1,'completion-grammar'),'full')
    else:
        settings = json.loads((STUDY/'schemes'/model/'scheme-plan.json').read_text())['profile']
        settings['route'] = 'chat-grammar'
    settings = deepcopy(settings)
    settings.update(temperature=temperature, top_p=top_p, reasoning_budget=budget,
        thinking_mode='bounded' if budget > 0 else 'native_no_thinking',
        template_kwargs={'enable_thinking':budget > 0},transport_timeout_seconds=1800)
    if key in ('lfm','gemma'):
        settings['extra_sampling']={'repeat_penalty':penalty}
    elif key == 'qwen':
        settings['extra_sampling']={'presence_penalty':penalty,'repeat_penalty':1.0}
    if key=='gemma' and name=='short-thought384-long-direct':
        settings.update(thinking_source_token_cutoff=1024, extra_sampling={})
    if key=='gemma' and name=='short-rep108-long-direct':
        settings.update(repeat_source_token_cutoff=1024, extra_sampling={})
    if key=='lfm' and name=='split-nohint384':
        settings.update(log_hint_tokens=0,ordinary_repeat_penalty=1.1)
    if key=='qwen' and name=='split-greedy':
        settings.update(top_k=40,ordinary_target_input_tokens=2432)
    return settings,target

@contextmanager
def session(model, settings, folder):
    with TemporaryDirectory(prefix='kaponir-four-') as td:
        home=Path(td)
        worker=Worker(home,configuration(home,{'model_dir':str(STUDY/'models'),'runtime':str(RUNTIME),
                      'threads':2,'ocr_timeout_seconds':1800}),'unused')
        try:
            sampling={k:settings[k] for k in ('temperature','top_p','top_k','min_p','seed')}
            client=BASE['ValidatedClient'](worker,model,settings['context_tokens'],settings['output_tokens'],
                    settings['response_format'],sampling,settings,folder,[])
            yield client
        finally:
            worker.stop_runtime()

def run(key, option, phase, cpu):
    cores = sorted(os.sched_getaffinity(0))[cpu:cpu+2]
    require(len(cores)==2,'two_cpus_needed')
    os.sched_setaffinity(0,cores)
    model=MODELS[key]
    settings,target=recipe(key,option)
    folder=ROOT/key/(phase+'-'+option)
    fixture= BASE['short_fixture']() if phase=='pilot' else LARGE['corpus']()
    sources,private,public,pool=fixture
    if phase=='guide':
        selected={n:t for n,t in sources.items() if n.endswith('reference.md')}
        fixture=(selected,{n:private[n] for n in selected},{n:public[n] for n in selected},
                 [c for c in pool if c.file in selected])
        sources,private,public,pool=fixture
    prompt,_,kinds=prompts_and_kinds()
    sha=lambda s:hashlib.sha256(s.encode()).hexdigest()
    with research_registration(model,catalog_for(model)):
        BASE['verify_inputs'](model)
        folder.mkdir(parents=True,exist_ok=False)
        hashes={n:sha(t) for n,t in sources.items()}
        atomic_json(folder/'plan.json', {'model':model,'option':option,'phase':phase,'artifact':FILES[model],
            'profile':settings,'log_input_token_target':target,'ordinary_temperature':0 if key=='nano' else settings['temperature'],
            'source_sha256':hashes,'prompt_sha256':sha(prompt),'kinds':kinds,
            'runtime_sha256':file_sha(RUNTIME),'binary_sha256':file_sha(BINARY),'cpu_affinity':cores,'threads':2,
            'detector_archive_sha256':LARGE['EXPORT_SHA'] if phase in ('full','guide') else None,
            'producer_sha256':file_sha(Path(__file__)), 'cache_prompt':False,
            'phase_definition':'full is fresh requests on all three documents, guide and pilot are diagnostics'})
        details={}
        gate=None
        t0=time.monotonic()
        with session(model,settings,folder) as client:
            t1=time.monotonic()
            # Long structured input first; every phase has its own process and new requests.
            for name in sorted(sources,key=lambda n:(not n.endswith('.log'),n)):
                is_log=name.endswith('.log')
                client.sampling['temperature']=0 if key=='nano' and not is_log else settings['temperature']
                source_tokens=None
                if 'thinking_source_token_cutoff' in settings or 'repeat_source_token_cutoff' in settings:
                    source_tokens=client.token_count(sources[name])
                if 'thinking_source_token_cutoff' in settings:
                    short_source=source_tokens<=settings['thinking_source_token_cutoff']
                    client.profile['template_kwargs']={'enable_thinking':short_source}
                if 'repeat_source_token_cutoff' in settings:
                    short_source=source_tokens<=settings['repeat_source_token_cutoff']
                    client.profile['extra_sampling']={'repeat_penalty':1.08} if short_source else {}
                args=Namespace(**settings,candidate_mode='typed',strategy='auto',target_input_tokens=target if is_log else settings.get('ordinary_target_input_tokens',0))
                if 'log_hint_tokens' in settings:
                    if is_log:
                        args.hint_tokens=settings['log_hint_tokens']
                    client.profile['extra_sampling']={'repeat_penalty':1.0 if is_log else settings['ordinary_repeat_penalty']}
                client.measurement_stage='discovery:'+name
                print(key,option,phase,name,'started',flush=True)
                start=len(client.records)
                found=discover(client,sources[name],prompt,kinds,args,client.save_history,{})
                records=client.records[start:]
                details[name]={**found,'source_tokens_for_cutoff':source_tokens,'requested_thinking':client.profile['template_kwargs']['enable_thinking'],'http_seconds':sum(r['http_wall_seconds'] for r in records),'requests':len(records)}
                atomic_json(folder/'discovery.json',details)
                print(key,option,name,'calls',len(records),'time',round(details[name]['http_seconds'],2),'errors',found['errors'],flush=True)
                if found['errors']:
                    break
                if key=='nano' and option=='wide-t020' and phase=='full' and is_log:
                    check=folder/'log-check'
                    check.mkdir()
                    app=LARGE['apply_stage'](model,option,{name:details[name]},{name:sources[name]},
                        {name:private[name]},{name:public[name]},[c for c in pool if c.file==name],
                        {name:hashes[name]},check)
                    row=app['application'][name]
                    h,p=row['private_spans_fully_covered'],row['public_occurrences_lost']
                    elapsed=details[name]['http_seconds']
                    ref=json.loads((ROOT/key/'full-split-t020'/'discovery.json').read_text())[name]['http_seconds']
                    passes=((h>=109 and p<=1 and elapsed<=ref) or (h>109 and p<=1 and elapsed<=1.15*ref)
                            or (h>=108 and p==0 and elapsed<=.85*ref))
                    gate={'H_log':h,'P_log':p,'log_http_seconds':elapsed,'reference_log_http_seconds':ref,'passed':passes}
                    atomic_json(folder/'log-screen.json',gate)
                    print('WIDE LOG SCREEN',gate,flush=True)
                    if not passes:break
            wall=time.monotonic()-t1
        planned_documents=set(sources)
        if set(details)!=planned_documents:
            sources={n:v for n,v in sources.items() if n in details}
            private={n:private[n] for n in sources}
            public={n:public[n] for n in sources}
            pool=[c for c in pool if c.file in sources]
            hashes={n:hashes[n] for n in sources}
        app=LARGE['apply_stage'](model,option,details,sources,private,public,pool,hashes,folder)
        docs=app['application']
        H=sum(x['private_spans_fully_covered'] for x in docs.values())
        P=sum(x['public_occurrences_lost'] for x in docs.values())
        R=next((docs[n]['replacements'] for n in docs if not private[n]),None)
        seconds=app['http_seconds']
        result={'model':model,'option':option,'phase':phase,'H':H,'P':P,'R':R,'http_seconds':seconds,'search_wall_seconds':wall,
                'total_wall_seconds':time.monotonic()-t0,'exact_restores':app['exact_roundtrips'],
                'private_total':BASE['total'](private,sources),'public_total':BASE['total'](public,sources),
                'requests':sum(s['requests'] for s in details.values()),
                'completed':set(details)==planned_documents and all(not s['errors'] for s in details.values()),
                'log_screen':gate,
                'by_document':{n:{k:r[k] for k in ('private_spans_fully_covered','public_occurrences_lost','replacements')} for n,r in docs.items()}}
        if result['completed'] and phase=='full':
            require(result['private_total']==193 and result['public_total']==87 and result['exact_restores']==6,'corpus_mismatch')
            result['score']=(60*H/193+25*(87-P)/87+5/(1+R)+15*693/(693+seconds))/1.05
        atomic_json(folder/'result.json',result)
        print('RESULT',json.dumps(result,ensure_ascii=False),flush=True)

if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('key',choices=MODELS)
    p.add_argument('option')
    p.add_argument('phase',choices=('pilot','full','guide'))
    p.add_argument('cpu',type=int)
    args=p.parse_args()
    run(args.key,args.option,args.phase,args.cpu)
