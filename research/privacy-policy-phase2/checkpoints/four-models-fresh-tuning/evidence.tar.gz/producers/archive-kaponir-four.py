"""Verify full-search HTTP receipts, schema checks, applied masks and restoration; publish only complete fresh scores."""
from collections import defaultdict
from fractions import Fraction as F
from pathlib import Path
import base64
import csv
import gzip
import hashlib
import io
import json
import math
import tarfile

from jsonschema import Draft202012Validator
from apply_measured_privacy import coverage, span_coverage
from check_learning_corpus import load_corpus
from experiment_inference import extraction_schema
from summarize_privacy_policy import digest, strict_json

REPO=Path('/workspace/Kaponir')
WORK=Path(__file__).resolve().parent
ROOT=WORK/'kaponir-hybrid-pilot/four-models-fresh-v1'
EVID=REPO/'research/privacy-policy-phase2/checkpoints/four-models-fresh-tuning'
CSVDIR=REPO/'docs/experiments'
def sha(b): return hashlib.sha256(b).hexdigest()
def packed(j): return (json.dumps(j,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
def read(p): return strict_json(p.read_text())
def score(h,p,r,minutes):
    speed=F(231,20)/(F(231,20)+minutes)
    private=F(h,193); public=F(87-p,87); ref=F(5,1+r)
    o=50*private+15*public+ref+30*speed
    ten=[60*private,25*public,ref,10*speed]
    fifteen=[v/F(105,100) for v in (60*private,25*public,ref,15*speed)]
    return o,ten,fifteen

def get_data(phase, folder):
    if phase=='holdout':
        fixture=read(ROOT/'holdout/fixture.json')
        return tuple(fixture[k] for k in ('sources','private','public'))
    if phase=='pilot':
        fixture=read(ROOT.parent/'fresh-lfm12/plan.json')
        return tuple(fixture[k] for k in ('sources','private_values','public_values'))
    _,expected,public,sources,_=load_corpus()
    priv={n:[v for d,v in expected if d==n] for n in sources}
    return sources,priv,public

def verify(folder):
    plan=read(folder/'plan.json'); result=read(folder/'result.json'); app=read(folder/'apply/result.json')
    journal=read(folder/'transports.json'); discovery=read(folder/'discovery.json')
    sources,private,public=get_data(result['phase'],folder)
    assert app['status']=='completed' and plan['model']==result['model']==journal['model']
    versions={sha(f.read_bytes()) for f in WORK.glob('tune-kaponir-four*.py')}
    assert plan['producer_sha256'] in versions and plan['threads']==2 and len(plan['cpu_affinity'])==2
    profile=plan['profile']
    fixed_schema=extraction_schema(plan['kinds'],'typed',24)
    documents={n:h for n,h in plan['source_sha256'].items() if n in result['by_document']}
    if result['completed']:assert documents==plan['source_sha256']
    assert all(sha(sources[n].encode())==h for n,h in documents.items())
    seconds=defaultdict(list); found=defaultdict(dict); issues=[]; fragments=defaultdict(list)
    inputs=[]; outputs=[]; thoughts=[]
    for i,event in enumerate(journal['requests']):
        req,rec=event['request'],event['record']; name=rec['measurement_stage'].removeprefix('discovery:')
        assert name in documents and rec['physical_request_index']==i and not event.get('reused')
        assert event['request_sha256']==digest(req) and req['cache_prompt'] is False
        assert req['temperature']==(profile['temperature'] if name.endswith('.log') else plan['ordinary_temperature'])
        assert all(req[k]==profile[k] for k in ('top_k','top_p','min_p','seed'))
        if 'ordinary_repeat_penalty' in profile:
            assert req['repeat_penalty']==(1.0 if name.endswith('.log') else profile['ordinary_repeat_penalty'])
        elif 'repeat_source_token_cutoff' not in profile:
            assert all(req[k]==v for k,v in profile['extra_sampling'].items())
        seconds[name].append(rec['http_wall_seconds'])
        assert rec['http_wall_seconds']>0
        is_completion='json_schema' in req
        messages=event['template_request']['messages'] if is_completion else req['messages']
        assert sha(messages[0]['content'].encode())==plan['prompt_sha256']
        value=strict_json(messages[1]['content']); assert value['source'] in sources[name]
        fragments[name].append(value['source'])
        if event['status']!='received':
            issues.append({'request':i,'error':rec.get('error','transport')});continue
        raw=base64.b64decode(event['raw_transport']['body_base64'],validate=True)
        reply=strict_json(raw.decode())
        assert reply==event['raw_reply'] and event['raw_transport']['status']==200
        schema=req['json_schema'] if is_completion else req['response_format']['json_schema']['schema']
        assert schema==fixed_schema
        actual_think=(event['template_request'] if is_completion else req)['chat_template_kwargs']['enable_thinking']
        if 'thinking_source_token_cutoff' not in profile:
            assert actual_think==profile['template_kwargs']['enable_thinking']
        if 'thinking_source_token_cutoff' in profile:
            assert actual_think==(discovery[name]['source_tokens_for_cutoff']<=profile['thinking_source_token_cutoff'])
        if 'repeat_source_token_cutoff' in profile:
            short=discovery[name]['source_tokens_for_cutoff']<=profile['repeat_source_token_cutoff']
            assert req.get('repeat_penalty',1.0)==(1.08 if short else 1.0)
        if 'log_hint_tokens' in profile and name.endswith('.log') and profile['log_hint_tokens']==0:
            assert value['context']==''
        inp=rec['input_tokens']; usage=rec.get('usage') or {}
        inputs.append(inp); outputs.append(usage.get('completion_tokens')); thoughts.append(rec.get('reasoning_text_tokens'))
        try:
            parsed=strict_json(reply['content'] if is_completion else reply['choices'][0]['message']['content'])
            Draft202012Validator(schema).validate(parsed)
        except (ValueError,KeyError) as exc:
            issues.append({'request':i,'error':str(exc)[:100]});continue
        except Exception as exc:
            issues.append({'request':i,'error':type(exc).__name__});continue
        if rec.get('error') or rec.get('finish_reason')!='stop':
            issues.append({'request':i,'error':rec.get('error','unfinished')});continue
        for item in parsed['candidates']:
            v=item['value']
            if 3<=len(v.encode())<=512 and v.strip()==v and v in value['source']:
                found[name].setdefault(v,{'value':v,'kind':item['kind'],'confidence':item['confidence']})
    assert len(journal['requests'])==result['requests'] and math.isclose(sum(map(sum,seconds.values())),result['http_seconds'],abs_tol=1e-7)
    for name,d in discovery.items():
        assert math.isclose(sum(seconds[name]),d['http_seconds'],abs_tol=1e-7)
        assert found[name]=={v['value']:v for v in d['values']}
    if result['completed']:
        assert not issues and set(documents)==set(discovery) and all(not d['errors'] for d in discovery.values())
        for name,values in fragments.items():
            # An automatic split may repeat sections after a valid saturated parent.
            pos=0
            for v in values:
                if sources[name].startswith(v,pos):pos+=len(v)
            assert pos==len(sources[name]), ('source coverage',folder,name,pos)
    h=p=r=0; total_priv=total_pub=0
    for idx,name in enumerate(documents,1):
        # apply_stage preserves original sources order even after JSON keys were sorted.
        for mode in ('baseline','model_masks_added'):
            apps=[x for x in app['documents'] if x['file']==name and x['mode']==mode]
            assert len(apps)==1
            ar=apps[0]; files=list((folder/'apply'/mode).glob('*-'+Path(name).stem))
            assert len(files)==1
            mask=read(files[0]/'mask.json'); restore=read(files[0]/'restore.json')
            assert restore['text']==sources[name] and ar['persistent_rules_unchanged'] and ar['restore_exact']
            row={**coverage(sources[name],mask['text'],private[name],public[name]),**span_coverage(sources[name],private[name],mask['replacements'],mask['text'])}
            assert all(ar[k]==v for k,v in row.items())
            if mode=='model_masks_added':
                h+=row['private_spans_fully_covered'];p+=row['public_occurrences_lost']
                total_priv+=row['private_occurrences_before'];total_pub+=row['public_occurrences_before']
                if not private[name]:r+=len(mask['replacements'])
    if result['R'] is None:
        assert not any(not private[n] for n in documents)
        r=None
    assert (h,p,r,total_priv,total_pub)==tuple(result[k] for k in ('H','P','R','private_total','public_total'))
    assert len(app['documents'])==result['exact_restores']==len(documents)*2
    if result['phase']=='full' and result['completed']:
        _,_,points=score(h,p,r,F(str(result['http_seconds']))/60)
        assert (total_priv,total_pub)==(193,87) and abs(float(sum(points))-result['score'])<1e-8
    return {**result,'invalid_requests':issues,'input_tokens':inputs,'completion_tokens':outputs,'reasoning_tokens':thoughts}

def csv_update(results):
    paths=[CSVDIR/'model-search-summary.csv',CSVDIR/'model-search-summary-60-30-10.csv',CSVDIR/'model-search-summary-60-30-15.csv']
    for table,path in enumerate(paths):
        with path.open(newline='') as stream:
            reader=csv.DictReader(stream); fields=reader.fieldnames; orig=list(reader)
        keyed={(r['model'],r['series'],r['profile']):r for r in orig}
        assert len(keyed)==len(orig)
        for res in results:
            if res['phase']!='full' or not res['completed']:continue
            h,p,r=res['H'],res['P'],res['R']; m=F(str(res['http_seconds']))/60
            o,ten,fifteen=score(h,p,r,m)
            row={'model':res['model'],'series':'fresh_tuning','profile':res['option'],'private_full_193':h,'public_lost_87':p,'guide_replacements':r,
                'http_minutes':f'{float(m):.9f}','application_or_table':res['application_file'],'application_sha256':res['application_sha256']}
            if table==0:row['score_100']=f'{float(o):.2f}'
            else:
                row.update(score_original_100=f'{float(o):.2f}',score_60_30_10_100=f'{float(sum(ten)):.2f}')
                if table==1:
                    row['score_change']=f'{float(sum(ten)-o):.2f}'
                    row.update(dict(zip(('private_points_60','public_control_points_25','public_guide_points_5','time_points_10'),(f'{float(v):.6f}' for v in ten))))
                else:
                    row.update(score_60_30_15_100=f'{float(sum(fifteen)):.2f}',score_change_vs_60_30_10=f'{float(sum(fifteen)-sum(ten)):.2f}')
                    row.update(dict(zip(('private_points','public_control_points','public_guide_points','time_points'),(f'{float(v):.6f}' for v in fifteen))))
            keyed[(row['model'],row['series'],row['profile'])]=row
        rows=list(keyed.values())
        def rank(row):
            old,ten,fifteen=score(int(row['private_full_193']),int(row['public_lost_87']),int(row['guide_replacements']),F(row['http_minutes']))
            return (old,sum(ten),sum(fifteen))[table]
        if table:rows.sort(key=rank,reverse=True)
        data=io.StringIO(newline=''); writer=csv.DictWriter(data,fields,lineterminator='\n')
        writer.writeheader();writer.writerows(rows)
        path.write_text(data.getvalue())
    print(len(rows),'full search entries')

def publish():
    files={};results=[]
    def add(name,p):
        data=p.read_bytes()
        assert name not in files
        files[name]=data
    EVID.mkdir(parents=True,exist_ok=True)
    add('pilot/fixture.json',ROOT.parent/'fresh-lfm12/plan.json')
    if (ROOT/'selection.json').exists():add('selection.json',ROOT/'selection.json')
    for p in (ROOT/'holdout').glob('*.json'):add('holdout/'+p.name,p)
    for trial in sorted(ROOT.glob('*/*/result.json')):
        folder=trial.parent
        row=verify(folder)
        row['trial_directory']=folder.relative_to(ROOT).as_posix()
        if folder.name.startswith('screen-'):
            assert not row['completed'] and len(row['by_document'])==1
            row['phase']='log_screen'
        results.append(row)
        for f in folder.rglob('*.json'):
            if (folder/'apply') in f.parents and f.name not in ('mask.json','restore.json','result.json'):continue
            add('runs/'+str(f.relative_to(ROOT)),f)
        if row['completed'] and row['phase']=='full':
            file=EVID/(row['model']+'-'+row['option']+'-application.json.gz')
            raw=gzip.compress((folder/'apply/result.json').read_bytes(),mtime=0)
            file.write_bytes(raw);row['application_file']=str(file.relative_to(REPO));row['application_sha256']=sha(raw)
    tested_versions={read(p)['producer_sha256'] for p in ROOT.glob('*/*/plan.json') if p.with_name('result.json').is_file()}
    for path in sorted(WORK.glob('tune-kaponir-four*.py')):
        version=sha(path.read_bytes())
        if version in tested_versions:
            add('producers/'+path.name,path)
            tested_versions.remove(version)
    assert not tested_versions
    for name in ['holdout-kaponir-four.py','freeze-kaponir-four-holdout.py','check-kaponir-granite-nanbeige.py','check-kaponir-lfm-large.py','compare-kaponir-four.py','finish-kaponir-four.py','archive-kaponir-four.py']:
        add('producers/'+name,WORK/name)
    bio=io.BytesIO()
    with tarfile.open(fileobj=bio,mode='w') as tf:
        for name,raw in sorted(files.items()):
            info=tarfile.TarInfo(name);info.size=len(raw)
            tf.addfile(info,io.BytesIO(raw))
    archive=gzip.compress(bio.getvalue(),mtime=0)
    (EVID/'evidence.tar.gz').write_bytes(archive)
    winners={}
    if (ROOT/'selection.json').exists():
        for key,opt in read(ROOT/'selection.json')['selected'].items():
            trial=next(r for r in results if r['trial_directory']==f'{key}/full-{opt}' and r['completed'])
            plan=read(ROOT/key/('full-'+opt)/'plan.json')
            winners[trial['model']]={'option':opt,'score_60_30_15_100':trial['score'],
                'settings':plan['profile'],'ordinary_temperature':plan['ordinary_temperature'],
                'log_target_input_tokens':plan['log_input_token_target'],
                'plan_member':'runs/'+trial['trial_directory']+'/plan.json'}
    (EVID/'manifest.json').write_bytes(packed({'corpus':'synthetic Kaponir search corpora',
        'archive_sha256':sha(archive),'offline_verifier_sha256':sha((EVID/'verify.py').read_bytes()),
        'selected_profiles':winners,'members_sha256':{n:sha(d) for n,d in sorted(files.items())},
        'fresh_trials':results,'new_requests':sum(r['requests'] for r in results),
        'fresh_requests_only':True,'holdout_fixture_sha256':sha((ROOT/'holdout/fixture.json').read_bytes())}))
    csv_update(results)
    print('published',len(results),'verified trials;',len(files),'members,',len(archive),'bytes')
if __name__=='__main__': publish()
