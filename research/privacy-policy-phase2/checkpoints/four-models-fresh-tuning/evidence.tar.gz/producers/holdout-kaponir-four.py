"""Matched old/new profile measurements on a separately frozen three-document sample."""
from argparse import ArgumentParser
import json
from pathlib import Path
import runpy
from evaluate_validation_schemes import detector_pool_from_export
from run_privacy_policy_suite import file_sha
from summarize_privacy_policy import require

here=Path(__file__).resolve().parent
module=runpy.run_path(str(here/'tune-kaponir-four.py'))
run=module['run']
env=run.__globals__
large=env['LARGE']
out=env['ROOT']
loc=out/'holdout'
fixture=json.loads((loc/'fixture.json').read_text())
require(file_sha(loc/'fixture.json')=='42eaaf369f6cdf1efcee489a3346c2d8ffb21126d11c3cf347aa101face517a6' and
        file_sha(loc/'detectors.json')==fixture['detectors_sha256'],'holdout_fixture_changed')
pool,_=detector_pool_from_export(json.loads((loc/'detectors.json').read_text()),fixture['sources'])
def corpus():
    return fixture['sources'], fixture['private'],fixture['public'],pool
large['corpus']=corpus
old_recipe=env['recipe']
def recipe(key, option):
    if option!='baseline':
        return old_recipe(key,option)
    model=env['MODELS'][key]
    if key=='nano':
        folder=env['BASE']['OUTPUT']/model/'full'/'direct-greedy-schema'
        profile=json.loads((folder/'plan.json').read_text())['profile']
    elif key=='gemma':
        profile=json.loads((out.parent/'gemma-qat-direct-full-v1/plan.json').read_text())['profile']
    elif key=='lfm':
        profile=json.loads((out.parent/'lfm-large'/model/'budget-384/transports.json').read_text())['profile']
    else:
        profile=json.loads((env['STUDY']/'schemes'/model/'scheme-plan.json').read_text())['profile']
    profile.setdefault('route','chat-grammar')
    return profile,0
env['recipe']=recipe
p=ArgumentParser()
p.add_argument('key',choices=env['MODELS']); p.add_argument('option'); p.add_argument('cpu',type=int)
args=p.parse_args()
run(args.key,args.option,'holdout',args.cpu)
