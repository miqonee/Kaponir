"""Assemble replayable timing evidence and append distinct complete profiles to the rankings."""
from fractions import Fraction as F
import csv
import gzip
import hashlib
import io
import json
from pathlib import Path
import runpy
import shutil
import tarfile

WORK=Path(__file__).resolve().parent
PREV=WORK/'kaponir-hybrid-pilot/four-models-fresh-v1'
ROOT=PREV.parent/'three-models-speed-v1'
REPO=Path('/workspace/Kaponir')
EVID=REPO/'research/privacy-policy-phase2/checkpoints/three-models-speed'
DOCS=REPO/'docs/experiments'
prev=runpy.run_path(str(WORK/'archive-kaponir-four.py'))
def sha(d):return hashlib.sha256(d).hexdigest()
def read(p):return json.loads(p.read_text())
def packed(obj):return (json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode()
def add_rows(trials):
    files=['model-search-summary.csv','model-search-summary-60-30-10.csv','model-search-summary-60-30-15.csv']
    points=prev['score']
    for i,file in enumerate(files):
        path=DOCS/file
        with path.open(newline='') as fp:
            reader=csv.DictReader(fp);fields=reader.fieldnames;old=list(reader)
        # The other calibration series are untouched, including repeated controls and archival estimates.
        rows=[v for v in old if v['series']!='fresh_speed']
        seen={(r['model'],r['series'],r['profile']) for r in rows}
        for t in trials:
            if not t.get('ranked_profile'): continue
            out=read(ROOT/t['trial_directory']/'result.json')
            assert out['complete'] and out['sample']=='full'
            H,P,R=[out[k] for k in ('H','P','R')]
            m=F(str(out['http_seconds']))/60
            oldscore,ten,fifteen=points(H,P,R,m)
            key=(out['model'],'fresh_speed',t['ranked_profile'])
            assert key not in seen
            seen.add(key)
            r={'model':key[0],'series':key[1],'profile':key[2],'private_full_193':H,'public_lost_87':P,'guide_replacements':R,
               'http_minutes':f'{float(m):.9f}','application_or_table':t['application_file'],'application_sha256':t['application_sha256']}
            if i==0:r['score_100']=f'{float(oldscore):.2f}'
            else:
                r['score_original_100']=f'{float(oldscore):.2f}'
                r['score_60_30_10_100']=f'{float(sum(ten)):.2f}'
                if i==1:
                    r['score_change']=f'{float(sum(ten)-oldscore):.2f}'
                    r.update(dict(zip(('private_points_60','public_control_points_25','public_guide_points_5','time_points_10'),(f'{float(a):.6f}' for a in ten))))
                else:
                    r.update(score_60_30_15_100=f'{float(sum(fifteen)):.2f}',score_change_vs_60_30_10=f'{float(sum(fifteen)-sum(ten)):.2f}')
                    r.update(dict(zip(('private_points','public_control_points','public_guide_points','time_points'),(f'{float(a):.6f}' for a in fifteen))))
            rows.append(r)
        if i:
            def sort_key(r):
                oscore,ten,fifteen=points(int(r['private_full_193']),int(r['public_lost_87']),int(r['guide_replacements']),F(r['http_minutes']))
                return sum(ten if i==1 else fifteen)
            rows.sort(key=sort_key,reverse=True)
        out=io.StringIO(newline=''); wr=csv.DictWriter(out,fields,lineterminator='\n');wr.writeheader();wr.writerows(rows)
        path.write_text(out.getvalue())
    return len(rows)

def archive(selected):
    # Controls are timing repetitions. Only distinct, fully timed two-thread configurations enter the prior two-thread ranking.
    rank=selected['rank']
    analysis=runpy.run_path(str(WORK/'analyze-kaponir-speed.py'))
    EVID.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(WORK/'verify-kaponir-search-speed.py',EVID/'verify.py')
    def member(p):
        return Path(p).read_bytes()
    blobs={'cpu-environment.json':member(ROOT/'cpu-environment.json'),'holdout/fixture.json':member(PREV/'holdout/fixture.json'),
           'holdout/detectors.json':member(PREV/'holdout/detectors.json')}
    for summary_file in ('paired-nano-lfm.json','qwen-isolated-finished.json','qwen-four-thread-finished.json','all-speed-trials-finished.json'):
        if (ROOT/summary_file).is_file():blobs['summaries/'+summary_file]=member(ROOT/summary_file)
    producers=['measure-kaponir-speed.py','measure-kaponir-speed-v1.py','kaponir-layout-tokens.py','queue-kaponir-speed-lanes.py',
               'isolated-kaponir-qwen.py','finish-kaponir-speed-privacy.py','screen-kaponir-qwen-format.py','finish-kaponir-format-screen.py','screen-kaponir-qwen-four-threads.py','drain-kaponir-qwen-holdout.py','paired-kaponir-nano-lfm.py','resume-kaponir-speed.py','tune-kaponir-four.py','check-kaponir-granite-nanbeige.py','check-kaponir-lfm-large.py','analyze-kaponir-speed.py','select-kaponir-speed.py','report-kaponir-speed.py','archive-kaponir-speed.py']
    for p in sorted(WORK.glob('measure-kaponir-speed-v*.py')):
        if p.name not in producers: producers.append(p.name)
    for name in producers:
        blobs['producers/'+name]=member(WORK/name)
    producers_hashes={sha(v) for k,v in blobs.items() if k.startswith('producers/measure-kaponir-speed')}
    interrupted=[]
    for record in sorted(ROOT.glob('interruptions/*/interruption.json')):
        folder=record.parent
        assert not (folder/'result.json').exists()
        prefix='interruptions/'+folder.name+'/'
        for q in sorted(folder.glob('*.json')):blobs[prefix+q.name]=member(q)
        journal=read(folder/'transports.json')['requests'] if (folder/'transports.json').exists() else []
        interrupted.append({'trial':read(record)['trial'],'prefix':prefix,'finished_http_receipts':sum(e['status']=='received' for e in journal)})
    trials=[]
    for path in sorted(ROOT.glob('*/*/result.json')):
        folder=path.parent;result=read(path);plan=read(folder/'plan.json')
        name=folder.relative_to(ROOT).as_posix()
        assert plan['runner_sha256'] in producers_hashes
        trial={'trial_directory':name,'model':result['model'],'sample':result['sample'],'complete':result['complete'],
               'requests':result['requests'],'http_seconds':result['http_seconds']}
        if result['complete']:
            trial.update({k:result[k] for k in ('H','P','R','private_total','public_total','exact_restores')})
        if result['complete'] and result['sample'] in ('full','holdout'):
            comp=analysis['compare'](analysis['baseline'](folder.parent.name,result['sample']),folder)
            trial['vs_previous']={k:comp[k] for k in ('private_gained','private_lost','public_recovered','public_newly_lost','raw_matches','matched_contents','matched_requests','all_mask_intervals_identical')}
        if name in rank:
            assert result['complete'] and result['sample']=='full' and plan['args']['threads']==plan['args']['batch']==2
            label=rank[name]; application=EVID/(result['model']+'-'+label+'-application.json.gz')
            gz=gzip.compress(member(folder/'apply/result.json'),mtime=0)
            application.write_bytes(gz)
            trial.update(ranked_profile=label,application_file=str(application.relative_to(REPO)),application_sha256=sha(gz))
        for f in folder.rglob('*.json'):
            if not (folder/'apply' in f.parents and f.name not in ('mask.json','restore.json','result.json')):
                blobs['runs/'+f.relative_to(ROOT).as_posix()]=member(f)
        trials.append(trial)
    assert set(rank)=={t['trial_directory'] for t in trials if t.get('ranked_profile')}
    blobs['selection.json']=packed(selected)
    stream=io.BytesIO()
    with tarfile.open(fileobj=stream,mode='w') as bundle:
        for name,raw in sorted(blobs.items()):
            info=tarfile.TarInfo(name);info.size=len(raw);bundle.addfile(info,io.BytesIO(raw))
    raw=gzip.compress(stream.getvalue(),mtime=0)
    (EVID/'evidence.tar.gz').write_bytes(raw)
    manifest={'archive_sha256':sha(raw),'members_sha256':{k:sha(v) for k,v in sorted(blobs.items())},
              'producer_hashes':sorted(producers_hashes),'trials':trials,'fresh_requests':sum(t['requests'] for t in trials),
              'selection':selected,'interrupted_attempts':interrupted,'verify_sha256':sha(member(EVID/'verify.py'))}
    (EVID/'manifest.json').write_bytes(packed(manifest))
    speed_fields=['model','trial','sample','decision','generation_threads','prompt_threads','cpu_affinity','isolated','requests',
                  'private_hidden','private_total','public_lost','public_total','public_guide_replacements',
                  'http_minutes','cost_seconds','log_seconds','reference_seconds','prompt_tokens','completion_tokens',
                  'previous_private_gained','previous_private_lost','previous_public_recovered','previous_public_newly_lost','previous_replies_identical','score_60_30_15_100']
    report=io.StringIO(newline=''); writer=csv.DictWriter(report,speed_fields,lineterminator='\n');writer.writeheader()
    for trial in trials:
        folder=ROOT/trial['trial_directory'];plan=read(folder/'plan.json');args=plan['args']
        r=analysis['summary'](folder)
        if not r['complete']:continue
        d=r['docs']; docs_for_sample=(('01-cost-estimate.md','02-application.log','08-public-reference.md') if r['sample']=='full'
                                     else ('handover-cost.md','mirror-worker.log','http-guide.md'))
        c=trial.get('vs_previous',{})
        model_key=folder.parent.name
        decision=selected.get('decisions',{}).get(trial['trial_directory'])
        if decision is None:
            if r['sample']!='full':decision='quality_check'
            elif selected.get('recommended',{}).get(model_key)==folder.name:decision='selected'
            elif folder.name in ('control-two','same-l2-two'):decision='control'
            else:decision='alternative'
        writer.writerow({'model':r['model'],'trial':folder.name,'sample':r['sample'],'decision':decision,'generation_threads':args['threads'],
             'prompt_threads':args['batch'],'cpu_affinity':','.join(map(str,plan['cpu_affinity'])),'isolated':str(bool(args.get('isolated'))).lower(),
             'requests':r['requests'],'private_hidden':r['H'],'private_total':r['private_total'],'public_lost':r['P'],
             'public_total':r['public_total'],'public_guide_replacements':r['R'],'http_minutes':f"{r['http_seconds']/60:.9f}",
             **{k:f"{d[n]['http_seconds']:.6f}" for k,n in zip(('cost_seconds','log_seconds','reference_seconds'),docs_for_sample) if n in d},
             'prompt_tokens':sum(v['prompt_tokens'] for v in d.values()),'completion_tokens':sum(v['completion_tokens'] for v in d.values()),
             'previous_private_gained':c.get('private_gained'),'previous_private_lost':c.get('private_lost'),
             'previous_public_recovered':c.get('public_recovered'),'previous_public_newly_lost':c.get('public_newly_lost'),
             'previous_replies_identical':str(c.get('matched_contents')).lower(),'score_60_30_15_100':f"{r['score']:.2f}" if 'score' in r else ''})
    (DOCS/'model-search-speed.csv').write_text(report.getvalue())
    entries=add_rows(trials)
    print('Archived',len(trials),'trials,',manifest['fresh_requests'],'requests,',len(rank),'ranked profiles,',entries,'total rows')
if __name__=='__main__':
    archive(read(ROOT/'selection.json'))
