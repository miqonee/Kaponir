"""Read paired time measurements and compare exact hidden positions in the full input."""
import json
from pathlib import Path
import runpy
from functools import lru_cache
from check_learning_corpus import occurrences

WORK=Path(__file__).resolve().parent
bench=runpy.run_path(str(WORK/'measure-kaponir-speed.py'))
SPEED=bench['output']; PREV=bench['before']
def read(p):
    return json.loads(p.read_text())
def baseline(key,phase='full'):
    choice=bench['selected'][key]
    return PREV/key/(phase+'-'+choice)
@lru_cache
def corpus(phase):
    return bench['fixture'](phase)[:3]
def summary(folder):
    result=read(folder/'result.json')
    requests=read(folder/'transports.json')['requests']
    stages=read(folder/'discovery.json')
    docs={}
    for name,stage in stages.items():
        calls=[e for e in requests if e['record']['measurement_stage']=='discovery:'+name]
        times=[e.get('raw_reply',{}).get('timings',{}) for e in calls]
        docs[name]={'http_seconds':stage['http_seconds'],'calls':len(calls),
                    'prompt_tokens':sum(e['record']['usage']['prompt_tokens'] for e in calls if e['record'].get('usage')),
                    'completion_tokens':sum(e['record']['usage']['completion_tokens'] for e in calls if e['record'].get('usage')),
                    'reasoning_tokens':sum(e['record'].get('reasoning_text_tokens',0) for e in calls),
                    'prompt_seconds':sum(t.get('prompt_ms',0) for t in times)/1000,
                    'gen_seconds':sum(t.get('predicted_ms',0) for t in times)/1000,
                    'drafted':sum(t.get('draft_n',0) for t in times),
                    'accepted':sum(t.get('draft_n_accepted',0) for t in times)}
    return {**result,'docs':docs}
@lru_cache
def masks(folder):
    result=read(folder/'result.json')
    name=result.get('sample',result.get('phase'))
    sources,pr,_=corpus('holdout' if name=='holdout' else 'full')
    docs=result['by_document']
    positions=set();applied=set()
    for n in docs:
        f,=(folder/'apply/model_masks_added').glob('*-'+Path(n).stem+'/mask.json')
        mm=read(f)
        off=[0]
        for char in sources[n]:off.append(off[-1]+len(char.encode()))
        spans=[(r['start'],r['end']) for r in mm['replacements']]
        applied.update((n,a,b) for a,b in spans)
        for v in pr[n]:
            for m in occurrences(sources[n],v):
                a,b=off[m.start()],off[m.end()]
                if sum(max(0,min(b,y)-max(a,x)) for x,y in spans)==b-a:
                    positions.add((n,v,a,b))
    assert len(positions)==result['H']
    return positions,applied
@lru_cache
def public_losses(folder):
    result=read(folder/'result.json')
    phase=result.get('sample',result.get('phase'))
    sources,_,public=corpus('holdout' if phase=='holdout' else 'full')
    _, intervals=masks(folder)
    lost=set()
    for name in result['by_document']:
        spans=[(x,y) for doc,x,y in intervals if doc==name]
        off=[0]
        for ch in sources[name]:off.append(off[-1]+len(ch.encode()))
        for v in public[name]:
            for match in occurrences(sources[name],v):
                a,b=off[match.start()],off[match.end()]
                if any(x<b and y>a for x,y in spans):lost.add((name,v,a,b))
    assert len(lost)==result['P']
    return lost

def contents(folder):
    events=read(folder/'transports.json')['requests']
    data=[]
    for e in events:
        r=e.get('raw_reply')
        if r is None:continue
        msg=r['choices'][0]['message']['content'] if 'choices' in r else r['content']
        data.append((e['request_sha256'],msg))
    return data
def compare(old,new):
    a=summary(old);b=summary(new)
    before,actual_old=masks(old);after,actual_new=masks(new)
    old_text=contents(old);new_text=contents(new)
    old_public,new_public=public_losses(old),public_losses(new)
    return {'minutes_before':a['http_seconds']/60,'minutes_after':b['http_seconds']/60,
            'gain_percent':100*(1-b['http_seconds']/a['http_seconds']),
            'private_gained':len(after-before),'private_lost':len(before-after),
            'public_recovered':len(old_public-new_public),'public_newly_lost':len(new_public-old_public),
            'new_positions':sorted((k,v,a,b) for k,v,a,b in (after-before)),
            'missing_positions':sorted((k,v,a,b) for k,v,a,b in (before-after)),
            'raw_matches':sum(x[1]==y[1] for x,y in zip(old_text,new_text)),
            'matched_contents':len(old_text)==len(new_text) and all(x[1]==y[1] for x,y in zip(old_text,new_text)),
            'matched_requests':len(old_text)==len(new_text) and all(x[0]==y[0] for x,y in zip(old_text,new_text)),
            'all_mask_intervals_identical':actual_old==actual_new}
if __name__=='__main__':
    import sys
    for folder in sorted(SPEED.glob('*/*/result.json')):
        f=folder.parent
        if not read(folder)['complete']: continue
        r=summary(f); sample=r['sample']
        if sample not in ('full','holdout'):continue
        print(f.parent.name,f.name,'HPR',[r[k] for k in ('H','P','R')],round(r['http_seconds']/60,2))
        ref=baseline(f.parent.name,sample)
        c=compare(ref,f)
        print({k:(round(v,2) if isinstance(v,float) else v) for k,v in c.items() if 'positions' not in k})
