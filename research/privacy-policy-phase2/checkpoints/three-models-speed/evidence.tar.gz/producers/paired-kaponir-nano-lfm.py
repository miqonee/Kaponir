"""Compare baseline and faster reading under identical single-model load after Qwen."""
from pathlib import Path
import fcntl
import json
import os
import runpy
import subprocess
import sys
import time

work=Path(__file__).resolve().parent
a=runpy.run_path(str(work/'analyze-kaponir-speed.py'))
root=a['SPEED']; marker=root/'exclusive-requested'
read=a['read']
def live_format_script():
    name=str(work/'screen-kaponir-qwen-format.py')
    for entry in Path('/proc').glob('[0-9]*/cmdline'):
        try:cmd=entry.read_bytes().decode().split('\0')
        except (OSError,UnicodeError):continue
        if cmd[0].endswith('python3') and name in cmd:return True
    return False
def live_llama():
    for entry in Path('/proc').glob('[0-9]*/comm'):
        try:
            if entry.read_text().strip()=='llama-server':return True
        except OSError:pass
    return False
def run(key,label,cpus,threads=2,batch=2,sample='full',extra=()):
    assert not live_llama()
    print('START',key,label,cpus,flush=True)
    subprocess.run([sys.executable,'-Bu',str(work/'measure-kaponir-speed.py'),key,label,'--isolated',
                    '--cpu-list',cpus,'--threads',str(threads),'--batch',str(batch),'--sample',sample,*extra],check=True)
    return read(root/key/label/'result.json')
def valid(key,label,phase):
    old=a['baseline'](key,phase);new=root/key/label
    b=read(old/'result.json');n=read(new/'result.json')
    return a['compare'](old,new)['private_lost']==0 and n['P']<=b['P'] and n['R']<=b['R']

while not (root/'qwen-four-thread-finished.json').is_file() or live_format_script():time.sleep(1)
marker.touch()
summary={}
try:
    with (root/'shared-cpus.lock').open('a') as guard:
        fcntl.flock(guard,fcntl.LOCK_EX)
        while live_llama():time.sleep(1)
        for key,cpu in [('lfm','2,3'),('nano','0,1')]:
            control=run(key,'control-two',cpu)
            faster=run(key,'prefill-four','0,1,2,4',batch=4)
            full_ok=valid(key,'prefill-four','full')
            hs=run(key,'prefill-four-holdout','0,1,2,4',batch=4,sample='holdout')
            holds=valid(key,'prefill-four-holdout','holdout')
            summary[key]={'prefill_preserved_full':full_ok,'prefill_preserved_holdout':holds,
                          'gain':1-faster['http_seconds']/control['http_seconds']}
            if not (full_ok and holds and faster['http_seconds']<.92*control['http_seconds']):
                rs=run(key,'four-cpu-holdout','0,1,2,4',4,4,'holdout')
                if valid(key,'four-cpu-holdout','holdout') and rs['http_seconds'] < 1.08*read(a['baseline'](key,'holdout')/'result.json')['http_seconds']:
                    four=run(key,'four-cpu','0,1,2,4',4,4)
                    summary[key]['four_preserved_full']=valid(key,'four-cpu','full')
            if key=='lfm':
                change=['--budget','192','--short-budget','384']
                run(key,'short384-long192',cpu,extra=change)
                run(key,'short384-long192-holdout',cpu,sample='holdout',extra=change)
            if key=='nano':
                run(key,'ngram-holdout',cpu,sample='holdout',extra=['--ngram'])
            (root/'paired-nano-lfm.json').write_text(json.dumps(summary,indent=2)+'\n')
        print('FINISHED',summary,flush=True)
finally:
    marker.unlink(missing_ok=True)
