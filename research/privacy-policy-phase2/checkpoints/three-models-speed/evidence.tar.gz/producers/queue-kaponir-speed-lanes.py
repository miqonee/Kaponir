"""Reserve the preceding CPU pairs for matched input, model and resource measurements."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

here=Path(__file__).resolve().parent
root=here/'kaponir-hybrid-pilot/three-models-speed-v1'
# A lane's incumbent and candidate have the same allocation. No response replay or cache.
queues={
  0:[('nano','control-two',[])],
  2:[('qwen','ngram-two',['--ngram']),('qwen','control-two',[]),('lfm','control-two',[])],
}
first={0:('nano','ngram-two'),2:('lfm','budget192-two')}
active={}
ready=set()
for lane in queues:
    pidfile=root/('lane-'+str(lane)+'-start.pid')
    if pidfile.exists(): firstpid=int(pidfile.read_text())
    else: firstpid=None
    active[lane]=(first[lane],None,firstpid)
while active:
    for lane,(job,proc,pid) in list(active.items()):
        if proc is not None:
            if proc.poll() is None: continue
            print(lane,job,'finished',proc.returncode,flush=True)
        else:
            if not (root/job[0]/job[1]/'result.json').exists() and (pid is None or Path('/proc',str(pid)).exists()):continue
        if not queues[lane]:
            del active[lane]
            continue
        k,label,opts=queues[lane].pop(0)
        child=subprocess.Popen([sys.executable,'-Bu',str(here/'measure-kaponir-speed.py'),k,label,'--cpu',str(lane),*opts])
        active[lane]=((k,label),child,None)
        print('START',k,label,'cpu',lane,flush=True)
    if active: time.sleep(2)
