"""Measure single-model latency with the preceding search prompt, grammar and scoring."""
import argparse
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import runpy
import tempfile
import time
from argparse import Namespace

from evaluate_validation_schemes import detector_pool_from_export
from experiment_inference import discover, prompts_and_kinds
from kaponir_worker import Worker, configuration
from native_model_profiles import catalog_for
from privacy_expansion_profiles import research_registration
from run_privacy_policy_suite import atomic_json, file_sha
from summarize_privacy_policy import require

WORK = Path(__file__).resolve().parent
previous = runpy.run_path(str(WORK/'tune-kaponir-four.py'))
base, large = previous['BASE'], previous['LARGE']
before = previous['ROOT']
output = before.parent/'three-models-speed-v1'
selected = json.loads((before/'selection.json').read_text())['selected']
ngram = ['--spec-type','ngram-simple','--spec-ngram-simple-size-n','4',
         '--spec-ngram-simple-size-m','12','--spec-ngram-simple-min-hits','1']
sha = lambda t: hashlib.sha256(t.encode()).hexdigest()

def fixture(sample):
    if sample=='holdout':
        loc=before/'holdout'
        fx=json.loads((loc/'fixture.json').read_text())
        require(file_sha(loc/'fixture.json')=='42eaaf369f6cdf1efcee489a3346c2d8ffb21126d11c3cf347aa101face517a6'
                and file_sha(loc/'detectors.json')==fx['detectors_sha256'],'changed_holdout')
        pool,_=detector_pool_from_export(json.loads((loc/'detectors.json').read_text()),fx['sources'])
        return fx['sources'],fx['private'],fx['public'],pool
    return large['corpus']()

@contextmanager
def session(model,settings,folder,threads,batch,flags):
    runtime=previous['RUNTIME']
    with tempfile.TemporaryDirectory(prefix='kaponir-speed-') as td:
        home=Path(td)
        # A wrapper only supplies the extra runtime flags. The same pinned binary is exec'd.
        wrapper=home/'start'
        wrapper.write_text('#!/usr/bin/env python3\nimport os,sys\na=sys.argv[1:]\na[a.index("-tb")+1]='+repr(str(batch))+'\nos.execv('+repr(str(runtime))+',['+repr(str(runtime))+']+a+'+repr(flags)+')\n')
        wrapper.chmod(0o700)
        w=Worker(home,configuration(home,{'model_dir':str(previous['STUDY']/'models'),
                 'runtime':str(wrapper),'threads':threads,'ocr_timeout_seconds':1800}),'unused')
        try:
            sampler={k:settings[k] for k in ('temperature','top_p','top_k','min_p','seed')}
            c=base['ValidatedClient'](w,model,settings['context_tokens'],settings['output_tokens'],
                                      settings['response_format'],sampler,settings,folder,[])
            proc=Path('/proc')/str(w.process.pid)
            command=(proc/'cmdline').read_bytes().decode().split('\0')[:-1]
            require((proc/'exe').resolve()==runtime.resolve() and command[command.index('-t')+1]==str(threads)
                    and command[command.index('-tb')+1]==str(batch) and command[command.index('-np')+1]=='1'
                    and (not flags or command[-len(flags):]==flags),'server_flags_mismatch')
            atomic_json(folder/'server.json',{'argv':command,'verified_runtime':str(runtime),
                         'affinity':sorted(os.sched_getaffinity(w.process.pid))})
            yield c
        finally:
            w.stop_runtime()

def run(args):
    key=args.key
    model=previous['MODELS'][key]
    cores=sorted(os.sched_getaffinity(0))[args.cpu:args.cpu+max(args.threads,args.batch)]
    require(len(cores)==max(args.threads,args.batch),'insufficient_cpu_affinity')
    os.sched_setaffinity(0,cores)
    settings,target=previous['recipe'](key,selected[key])
    if args.budget is not None:
        require(key=='lfm','only_reasoning_model')
        settings['reasoning_budget']=args.budget
    flags=ngram if args.ngram else []
    sources,private,public,pool=fixture(args.sample)
    if args.sample in ('guide','log','estimate'):
        suffix={'guide':'reference.md','log':'.log','estimate':'estimate.md'}[args.sample]
        sources={n:t for n,t in sources.items() if n.endswith(suffix)}
        private={n:private[n] for n in sources}
        public={n:public[n] for n in sources}
        pool=[c for c in pool if c.file in sources]
    hashes={n:sha(t) for n,t in sources.items()}
    folder=output/key/args.label
    folder.mkdir(parents=True,exist_ok=False)
    prompt,_,kinds=prompts_and_kinds()
    with research_registration(model,catalog_for(model)):
        base['verify_inputs'](model)
        atomic_json(folder/'plan.json',{'model':model,'args':vars(args),'profile':settings,'log_token_target':target,
            'previous_profile':selected[key],'model_artifact':previous['FILES'][model],'runtime_sha256':file_sha(previous['RUNTIME']),
            'api_sha256':file_sha(previous['BINARY']),'source_sha256':hashes,'prompt_sha256':sha(prompt),'kinds':kinds,
            'runner_sha256':file_sha(Path(__file__)), 'cpu_affinity':cores,'extra_server_flags':flags})
        print(key,args.label,'start',cores,flush=True)
        details={}
        started=time.monotonic()
        with session(model,settings,folder,args.threads,args.batch,flags) as c:
            server_ready=time.monotonic()
            for name in sorted(sources,key=lambda n:(not n.endswith('.log'),n)):
                is_log=name.endswith('.log')
                c.sampling['temperature']=0 if key=='nano' and not is_log else settings['temperature']
                c.sampling['top_p']=settings['top_p']
                c.sampling['top_k']=settings['top_k']
                cfg=Namespace(**settings,candidate_mode='typed',strategy='auto',
                              target_input_tokens=target if is_log else settings.get('ordinary_target_input_tokens',0))
                if 'log_hint_tokens' in settings:
                    if is_log: cfg.hint_tokens=settings['log_hint_tokens']
                    c.profile['extra_sampling']={'repeat_penalty':1.0 if is_log else settings['ordinary_repeat_penalty']}
                if args.short_card:
                    require(key=='qwen','short_card_only_qwen')
                    c.profile['extra_sampling']={'presence_penalty':0,'repeat_penalty':1.0}
                    if c.token_count(sources[name])<=1024:
                        c.sampling.update(temperature=.7,top_p=.8,top_k=20)
                        c.profile['extra_sampling']={'presence_penalty':1.5,'repeat_penalty':1.0}
                c.measurement_stage='discovery:'+name
                first=len(c.records)
                print(key,args.label,name,'started',flush=True)
                found=discover(c,sources[name],prompt,kinds,cfg,c.save_history,{})
                records=c.records[first:]
                details[name]={**found,'requests':len(records),'http_seconds':sum(r['http_wall_seconds'] for r in records)}
                atomic_json(folder/'discovery.json',details)
                print(key,args.label,name,'seconds',round(details[name]['http_seconds'],1),'errors',found['errors'],flush=True)
                if found['errors']: break
            wall=time.monotonic()-server_ready
        completed=set(details)==set(sources) and all(not d['errors'] for d in details.values())
        result={'model':model,'sample':args.sample,'complete':completed,'http_seconds':sum(d['http_seconds'] for d in details.values()),
                'search_wall_seconds':wall,'requests':sum(d['requests'] for d in details.values())}
        if completed:
            app=large['apply_stage'](model,args.label,details,sources,private,public,pool,hashes,folder)
            docs=app['application']
            result.update(H=sum(r['private_spans_fully_covered'] for r in docs.values()),
                          P=sum(r['public_occurrences_lost'] for r in docs.values()),
                          R=next((docs[n]['replacements'] for n in docs if not private[n]),None),
                          private_total=base['total'](private,sources),public_total=base['total'](public,sources),
                          exact_restores=app['exact_roundtrips'],
                          by_document={n:{k:r[k] for k in ('private_spans_fully_covered','public_occurrences_lost','replacements')} for n,r in docs.items()})
            require(result['exact_restores']==2*len(sources),'not_all_restores_exact')
            if args.sample=='full':
                require((result['private_total'],result['public_total'])==(193,87),'main_corpus_changed')
                result['score']=(60*result['H']/193+25*(87-result['P'])/87+5/(1+result['R'])+15*693/(693+result['http_seconds']))/1.05
        result['overall_wall_seconds']=time.monotonic()-started
        atomic_json(folder/'result.json',result)
        print(key,args.label,'RESULT',json.dumps(result),flush=True)
        require(completed,'discovery_incomplete')

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('key',choices=['nano','qwen','lfm']);p.add_argument('label')
    p.add_argument('--sample',choices=['full','holdout','log','estimate','guide'],default='full')
    p.add_argument('--cpu',type=int,default=0);p.add_argument('--threads',type=int,default=2);p.add_argument('--batch',type=int,default=2)
    p.add_argument('--ngram',action='store_true');p.add_argument('--budget',type=int);p.add_argument('--short-card',action='store_true')
    run(p.parse_args())
