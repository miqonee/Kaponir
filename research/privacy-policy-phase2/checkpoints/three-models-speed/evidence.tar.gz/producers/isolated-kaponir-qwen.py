"""Compare CPU placement while keeping the previous Qwen request bodies and model unchanged."""
import fcntl
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
import time

work=Path(__file__).resolve().parent
analysis=runpy.run_path(str(work/'analyze-kaponir-speed.py'))
root=analysis['SPEED']; marker=root/'exclusive-requested'
read=analysis['read']
compare=analysis['compare']
def model_processes():
    found=[]
    for p in Path('/proc').glob('[0-9]*/comm'):
        try: name=p.read_text().strip()
        except OSError:continue
        if name=='llama-server':found.append(int(p.parent.name))
    return found
def run(label,ids,threads=2,batch=2,phase='full'):
    assert not model_processes()
    subprocess.run([sys.executable,'-Bu',str(work/'measure-kaponir-speed.py'),'qwen',label,'--isolated','--cpu-list',ids,
                    '--threads',str(threads),'--batch',str(batch),'--sample',phase],check=True)
    return read(root/'qwen'/label/'result.json')
def eligible(dataset,path,control):
    res=read(path/'result.json'); old=read(control/'result.json')
    cmp=compare(control,path)
    return (res['H']>=old['H'] and cmp['private_lost']==0 and res['P']<=old['P'] and res['R']<=old['R'])
try:
    assert marker.is_file()
    pair=[root/'qwen/control-two/result.json',root/'nano/ngram-two/result.json']
    while not all(p.exists() for p in pair): time.sleep(2)
    with (root/'shared-cpus.lock').open('a') as stream:
        fcntl.flock(stream,fcntl.LOCK_EX)
        while model_processes():time.sleep(1)
        print('Starting Qwen isolated pair',flush=True)
        candidate=run('separate-l2-two','2,4')
        control=run('same-l2-two','2,3')
        base_path=analysis['baseline']('qwen','full')
        local=root/'qwen'
        ok=eligible('full',local/'separate-l2-two',base_path) and eligible('full',local/'separate-l2-two',local/'same-l2-two')
        speed=1-candidate['http_seconds']/control['http_seconds']
        chosen=[]
        if ok:
            h=run('separate-l2-holdout','2,4',phase='holdout')
            ok=eligible('holdout',local/'separate-l2-holdout',analysis['baseline']('qwen','holdout'))
            if ok and speed>0:chosen.append('separate-l2-two')
        print('Qwen two-thread pair',ok,speed,chosen,flush=True)
        if not chosen or speed < .12:
            candidate4=run('prefill-four','0,1,2,4',threads=2,batch=4)
            ok4=eligible('full',local/'prefill-four',base_path) and eligible('full',local/'prefill-four',local/'same-l2-two')
            if ok4 and candidate4['http_seconds']<control['http_seconds']:
                h=run('prefill-four-holdout','0,1,2,4',threads=2,batch=4,phase='holdout')
                if eligible('holdout',local/'prefill-four-holdout',analysis['baseline']('qwen','holdout')):
                    chosen.append('prefill-four')
        (root/'qwen-isolated-finished.json').write_text(json.dumps({'eligible_faster':chosen},indent=2)+'\n')
finally:
    marker.unlink(missing_ok=True)
