"""Build the corpus and paired timing tables from the recorded measurements."""
import json
from pathlib import Path
import runpy

work=Path(__file__).resolve().parent
a=runpy.run_path(str(work/'analyze-kaponir-speed.py'))
speed=a['SPEED']; prev=a['baseline']; get=a['summary']
repo=Path('/workspace/Kaponir')
selection=json.loads((speed/'selection.json').read_text())
names={'qwen':'Qwen3.5-4B','nano':'Nanbeige 4.2 3B','lfm':'LFM 2.5 2.6B'}
files=['01-cost-estimate.md','02-application.log','08-public-reference.md']
src,private,public=a['corpus']('full')
def f(val,n=2):return f'{val:.{n}f}'.replace('.',',')
def minute(seconds):return f(seconds/60)
def amount(v):return f'{v:,}'.replace(',',' ')
def met(r):return f"{r['H']} / {r['P']} / {r['R']}"
def row(cells):return '| '+' | '.join(map(str,cells))+' |'
def delta(before,after):return 100*(1-after/before)
m=[]
def p(s=''):m.append(s)
def section(title):
    p();p('## '+title);p()
p('# Время поиска приватных данных в Kaponir')
p()
p('22 ноября 2026 года. Сравнили Nanbeige 4.2 3B, Qwen3.5-4B и LFM 2.5 2.6B на CPU. В каждом прогоне одна локальная модель обрабатывает весь указанный корпус. [Предыдущие полные прогоны](FOUR_MODEL_TUNING.md)')
section('Время и качество на трёх основных документах')
pairs=[(speed/key/selection['controls'][key],speed/key/selection['recommended'][key]) for key in names]
if all(a['compare'](c,n)['all_mask_intervals_identical'] and a['compare'](c,n)['matched_contents'] for c,n in pairs):
    total=sum(get(n)['requests'] for _,n in pairs)
    p(f'Все {total} финальных JSON в выбранных режимах побайтово совпали с контрольными ответами. После применения через API Kaponir совпали и позиции всех масок.')
else:
    p('В выбранных режимах сохранились все ранее скрытые приватные вхождения и ранее открытые публичные контроли. Качество проверено после применения масок через API Kaponir.')
p()
p('Процент экономии считаем от свежего контрольного прогона. Контроль и выбранный профиль обработали все три документа по очереди на одном стенде. Прежняя публикация приведена в отдельной колонке. В публичной справке считаем все замены, включая неразмеченный текст.')
p()
p(row(['Модель','Прежняя публикация, мин','Повтор прежнего, мин','Новый, мин','Экономия к повтору','Скрыто /193','Потери /87','Замены в справке','Балл /100']))
p('|---|---:|---:|---:|---:|---:|---:|---:|---:|')
for key,name in names.items():
    ctrl=get(speed/key/selection.get('controls',{}).get(key,'control-two'));new=get(speed/key/selection['recommended'][key]);old=get(prev(key))
    p(row([name,minute(old['http_seconds']),minute(ctrl['http_seconds']),'**'+minute(new['http_seconds'])+'**',
           f(delta(ctrl['http_seconds'],new['http_seconds']),1)+'%',f"{ctrl['H']} → {new['H']}",f"{ctrl['P']} → {new['P']}",
           f"{ctrl['R']} → {new['R']}",f(ctrl['score'])+' → '+f(new['score'])]))
section('Что обрабатывает модель')
p(row(['Синтетический документ','Текст UTF-8, байт','Строки','Приватные вхождения','Публичные вхождения']))
p('|---|---:|---:|---:|---:|')
for name,title in zip(files,['Смета с 26 позициями, ценами и контактами','Журнал приложения с учётными данными и внутренними адресами','Публичная техническая справка']):
    h=sum(len(a['occurrences'](src[name],v)) for v in private[name])
    pp=sum(len(a['occurrences'](src[name],v)) for v in public[name])
    p(row([f'[{title}](../../tests/docs/input/{name})',amount(len(src[name].encode())),len(src[name].splitlines()),h,pp]))
p(row(['**Всего**','**25 122**','**257**','**193**','**87**']))
p()
p('Три файла содержат 19 675 символов. Число 193 обозначает размеченные приватные вхождения в исходных документах. Приватные значения могут встречаться несколько раз. Перед запросом Kaponir добавляет инструкцию и при необходимости разбивает документ на части. Разные токенизаторы дают разное число входных токенов. Модель тратит выходные токены на список находок, а LFM ещё и на рассуждения. [Разметка и описание датасета](../../tests/docs/README.md)')
section('За что начисляются баллы времени')
p('Колонка «мин» — сумма длительностей всех запросов генерации по трём файлам. Запрос измеряется от отправки уже работающему локальному серверу до получения ответа. Во время входят чтение входных токенов моделью, генерация ответа, записанные повторы и тайм-ауты. В этом эксперименте запросы одной модели выполняются последовательно, кэш ответа и повторное использование префикса отключены. Загрузка весов, предварительный подсчёт токенов, применение масок и проверка восстановления учитываются отдельно. Короткие документы и задача A–D имеют свои измерения.')
p()
p('При весах 60:30:15 итог нормируется на 100. Вклад скорости — 15 × 11,55 / (11,55 + t) / 1,05, где t — минуты на все три файла. При 11,55 минуты скорость даёт 7,14 балла итогового рейтинга. Максимальный вклад скорости равен 14,29 балла. [Полная формула](FOUR_MODEL_TUNING.md#как-считали)')
section('Время отдельно по документам')
p('Первая строка каждой модели — свежий контроль. «Чтение» и «генерация» взяты из внутренних счётчиков сервера. Сумма HTTP также включает транспорт и небольшие накладные расходы.')
p()
p(row(['Модель и настройки','Запросов','Смета, мин','Лог, мин','Справка, мин','Всего HTTP, мин','Чтение / генерация, мин','Скрыто / потери / замены']))
p('|---|---:|---:|---:|---:|---:|---:|---:|')
for key,name in names.items():
    for j in selection['display_order'][key]:
        rr=get(speed/key/j)
        if not rr['complete']:continue
        d=rr['docs']
        p(row([name+' · '+selection['labels'].get(key+'/'+j,j),rr['requests'],
               *(minute(d[n]['http_seconds']) for n in files),minute(rr['http_seconds']),
               minute(sum(v['prompt_seconds'] for v in d.values()))+' / '+minute(sum(v['gen_seconds'] for v in d.values())),met(rr)]))
p()
for key,name in names.items():
    r=get(speed/key/selection['recommended'][key])
    d=list(r['docs'].values())
    p(f"{name} выполнила {r['requests']} запросов. Сервер насчитал {amount(sum(x['prompt_tokens'] for x in d))} входных и {amount(sum(x['completion_tokens'] for x in d))} выходных токенов за три документа.")
    p()
section('Что менялось')
for msg in selection['findings']:p('- '+msg)
if selection.get('supplement'):
    p();p(selection['supplement'])
section('Три коротких документа')
p('В короткой смете `handover-cost.md`, логе `mirror-worker.log` и справке `http-guide.md` размечены 19 приватных и 21 публичное вхождение. Эти файлы также участвовали в предыдущей калибровке. Каждый вариант проверен с реальной маскировкой через API. Слева — выбранные в предыдущей серии настройки, справа — новый замер.')
p()
short_pairs=[(prev(key,'holdout'),speed/key/(selection['recommended'][key]+'-holdout')) for key in names]
if all((n/'result.json').exists() and a['compare'](c,n)['matched_contents'] and a['compare'](c,n)['all_mask_intervals_identical'] for c,n in short_pairs):
    p('У трёх выбранных профилей на коротком наборе совпали все девять финальных JSON и все позиции итоговых масок с предыдущей калибровкой.')
    p()
p(row(['Модель и вариант','Скрыто /19','Публичные потери /21','Замены в справке','HTTP, секунды']))
p('|---|---:|---:|---:|---:|')
for key,name in names.items():
    for j in selection['holdouts'].get(key,[]):
        old=get(prev(key,'holdout'));new=get(speed/key/j)
        if not new['complete']:continue
        p(row([name+' · '+selection['labels'].get(key+'/'+j,j),f"{old['H']} → {new['H']}",f"{old['P']} → {new['P']}",
               f"{old['R']} → {new['R']}",f(old['http_seconds'],1)+' → '+f(new['http_seconds'],1)]))
section('Условия измерения')
p('На стенде AMD EPYC 9V74 видны пять виртуальных CPU с общей квотой в четыре CPU. Генерация работала на CPU. Каждая модель использовала тот же файл GGUF и llama.cpp b12038. Для полного прогона поднимали новый сервер. Кэш страниц операционной системы между запусками сохранялся. Сохранили контекст 16 384, первичный лимит ответа 4 096, seed 42, инструкцию EXTRACT_PROMPT, JSON Schema с пределом 24 кандидата, привязку к исходному тексту и детекторы. У контроля два потока на чтение входа и два на генерацию. В варианте «чтение 4, генерация 2» серверу доступны четыре виртуальных CPU, в варианте «4/4» все четыре используются и для генерации. У всех один слот. Процесс с четырьмя потоками чтения также получает более широкий набор разрешённых виртуальных CPU.')
p()
p('Для парного сравнения скорости на стенде запускали по одной модели. В предварительных опытах с n-gram и бюджетом 192 другая модель могла работать на отдельных виртуальных CPU той же машины. Нагрузка на общую память влияет на время. Для каждого профиля приведён один полный замер. На трёх документах проверено шесть побайтовых восстановлений за прогон. Повторы прежних настроек служат контролем для скорости. В общий рейтинг двухпоточных прогонов добавлены отдельные полностью проверенные настройки с двумя потоками чтения и генерации. Все измерения, включая четырёхпоточные и контрольные, доступны в отдельном CSV.')
p()
lost=sorted((speed/'interruptions').glob('*/interruption.json'))
if lost:
    interrupted_receipts=0
    for record in lost:
        t=record.parent/'transports.json'
        if t.is_file():interrupted_receipts+=sum(x['status']=='received' for x in json.loads(t.read_text())['requests'])
    p(f'Первый запуск Nanbeige прервался. К этому моменту сервер успел вернуть {interrupted_receipts} ответ. В итоговой строке учтён целиком повторённый прогон на том же стенде. Журнал прерывания приложен к архиву отдельно.')
    p()
p('[Все новые прогоны с числом потоков и временем каждого файла](model-search-speed.csv) · [Общий рейтинг по формуле 60:30:15](model-search-summary-60-30-15.csv) · [Манифест](../../research/privacy-policy-phase2/checkpoints/three-models-speed/manifest.json) · [Запросы, ответы и маски](../../research/privacy-policy-phase2/checkpoints/three-models-speed/evidence.tar.gz) · [Офлайн-проверка](../../research/privacy-policy-phase2/checkpoints/three-models-speed/verify.py)')
(repo/'docs/experiments/THREE_MODEL_SPEED.md').write_text('\n'.join(m)+'\n')
