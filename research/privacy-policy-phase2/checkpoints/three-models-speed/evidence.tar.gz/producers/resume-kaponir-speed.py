"""Resume uncompleted controlled trials, preserving, but never reusing, interrupted replies."""
from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
import time

work=Path(__file__).resolve().parent
a=runpy.run_path(str(work/'analyze-kaponir-speed.py'))
root=a['SPEED']; marker=root/'exclusive-requested'
def completed(path):
    return (path/'result.json').is_file() and a['read'](path/'result.json')['complete']
def live_servers():
    for stat in Path('/proc').glob('[0-9]*/stat'):
        try: name,state=stat.read_text().split('(',1)[1].split(')',1)
        except (OSError,IndexError,ValueError): continue
        if name=='llama-server' and state.strip().split()[0]!='Z':return True
    return False
def run(key,label,cpus,threads=2,batch=2,sample='full',extra=()):
    assert not live_servers(), 'another model server is running'
    path=root/key/label
    if completed(path):return path
    if path.exists():
        assert not (path/'result.json').exists(), 'completed failure needs inspection'
        saved=root/'interruptions'/(key+'-'+label+'-'+str(time.time_ns()))
        saved.parent.mkdir(exist_ok=True)
        path.rename(saved)
        (saved/'interruption.json').write_text(json.dumps({
            'trial':key+'/'+label,'interrupted_before_complete':True,'reused_in_restart':False,
            'utc_observed':datetime.now(timezone.utc).isoformat(),
            'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
            'reason':'session ended before completion while executing the fresh full run'
        },indent=2)+'\n')
    subprocess.run([sys.executable,'-Bu',str(work/'measure-kaponir-speed.py'),key,label,
                    '--isolated','--cpu-list',cpus,'--threads',str(threads),'--batch',str(batch),
                    '--sample',sample,*extra],check=True)
    return path
def preserves(old,new):
    cmp=a['compare'](old,new)
    return cmp['private_lost']==0 and cmp['public_newly_lost']==0 and a['summary'](new)['R']<=a['summary'](old)['R']
def seconds(path):return a['summary'](path)['http_seconds']
def output_tokens(path):return sum(x['completion_tokens'] for x in a['summary'](path)['docs'].values())

with (root/'shared-cpus.lock').open('a') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX)
    assert not live_servers()
    marker.touch()
    try:
        ctrl=root/'nano/control-two'; assert completed(ctrl)
        full=run('nano','prefill-four','0,1,2,4',batch=4)
        short=run('nano','prefill-four-holdout','0,1,2,4',batch=4,sample='holdout')
        old=a['baseline']('nano');oldshort=a['baseline']('nano','holdout')
        valid=preserves(old,full) and preserves(ctrl,full)
        valid_short=preserves(oldshort,short)
        gain=1-seconds(full)/seconds(ctrl)
        with (root/'paired-nano-lfm.json').open() as f:summary=json.load(f)
        summary['nano']={'prefill_preserved_full':valid,'prefill_preserved_holdout':valid_short,'gain':gain}
        if not (valid and valid_short and gain>=.08):
            fshort=run('nano','four-cpu-holdout','0,1,2,4',4,4,'holdout')
            if preserves(oldshort,fshort) and seconds(fshort)<1.08*seconds(oldshort):
                four=run('nano','four-cpu','0,1,2,4',4,4)
                summary['nano']['four_preserved_full']=preserves(old,four) and preserves(ctrl,four)
        run('nano','ngram-holdout','0,1',sample='holdout',extra=['--ngram'])
        (root/'paired-nano-lfm.json').write_text(json.dumps(summary,indent=2)+'\n')
        compact=run('qwen','one-line-holdout','2,3',sample='holdout',extra=['--one-line'])
        qold=a['baseline']('qwen','holdout')
        qualifies=(preserves(qold,compact) and output_tokens(compact)<.85*output_tokens(qold)
                   and seconds(compact)<seconds(qold))
        if qualifies:run('qwen','one-line-two','2,3',extra=['--one-line'])
        (root/'all-speed-trials-finished.json').write_text(json.dumps({'paired':summary,'compact_qualified':qualifies},indent=2)+'\n')
        print('All three models finished',summary,'Qwen short compact',qualifies,flush=True)
    finally:
        marker.unlink(missing_ok=True)
