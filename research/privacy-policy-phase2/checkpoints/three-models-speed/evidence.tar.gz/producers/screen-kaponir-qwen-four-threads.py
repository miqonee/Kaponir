"""Check the four-thread option on the small corpus before committing to a full run."""
from pathlib import Path
import fcntl
import json
import runpy
import subprocess
import sys
import time

work=Path(__file__).resolve().parent
a=runpy.run_path(str(work/'analyze-kaponir-speed.py'))
root=a['SPEED'];q=root/'qwen'
first=root/'qwen-isolated-finished.json'
marker=root/'exclusive-requested'
out=root/'qwen-four-thread-finished.json'
read=a['read']
def run(label,sample):
    subprocess.run([sys.executable,'-Bu',str(work/'measure-kaponir-speed.py'),'qwen',label,'--isolated','--cpu-list','0,1,2,4',
                    '--threads','4','--batch','4','--sample',sample],check=True)
    return read(q/label/'result.json')
def preserved(label,sample):
    baseline=a['baseline']('qwen',sample);before=read(baseline/'result.json');after=read(q/label/'result.json')
    return a['compare'](baseline,q/label)['private_lost']==0 and after['P']<=before['P'] and after['R']<=before['R']
while not first.is_file():time.sleep(.25)
options=read(first)['eligible_faster']
control=read(q/'same-l2-two/result.json')['http_seconds']
fast=min([read(q/k/'result.json')['http_seconds'] for k in options],default=control)
if fast<=.8*control:
    out.write_text(json.dumps({'tested':False,'reason':'already_verified_at_least_twenty_percent'})+'\n')
    sys.exit(0)
# The first coordinator owns the lock until after all its model processes exit.
marker.touch()
try:
    with (root/'shared-cpus.lock').open('a') as guard:
        fcntl.flock(guard,fcntl.LOCK_EX)
        marker.touch()
        short=run('four-cpu-holdout','holdout')
        short_ok=preserved('four-cpu-holdout','holdout')
        info={'tested':True,'short_eligible':short_ok,'full_eligible':False}
        if short_ok:
            full=run('four-cpu','full')
            info['full_eligible']=preserved('four-cpu','full') and full['http_seconds']<control
        out.write_text(json.dumps(info,indent=2)+'\n')
        print('Four CPU privacy and latency',info,flush=True)
finally:
    marker.unlink(missing_ok=True)
