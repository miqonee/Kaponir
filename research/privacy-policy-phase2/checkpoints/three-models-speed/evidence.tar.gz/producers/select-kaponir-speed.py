"""Build the result table from fresh matched controls and separately label quality regressions."""
from collections import Counter
from pathlib import Path
import json
import runpy

work = Path(__file__).resolve().parent
a = runpy.run_path(str(work / 'analyze-kaponir-speed.py'))
root = a['SPEED']
names = {'qwen':'Qwen3.5-4B', 'nano':'Nanbeige 4.2 3B', 'lfm':'LFM 2.5 2.6B'}
labels = {'control-two':'прежний режим, 2/2', 'same-l2-two':'прежний режим, 2/2',
          'separate-l2-two':'два потока в разных группах кэша L2', 'prefill-four':'чтение 4, генерация 2',
          'four-cpu':'чтение 4, генерация 4', 'ngram-two':'ngram-simple, 2/2',
          'budget192-two':'бюджет 192, 2/2', 'short384-long192':'бюджет 384 до 1 024 токенов, 192 выше, 2/2',
          'one-line-two':'компактный JSON, 2/2', 'one-line':'компактный JSON, 2/2',
          'ngram':'ngram-simple, 2/2', 'separate-l2':'два потока в разных группах кэша L2',
          'placement-check':'два потока в разных группах кэша L2, первый замер'}
rank = {'qwen/ngram-two':'split-greedy-ngram4x12','qwen/one-line-two':'split-greedy-compact',
        'qwen/separate-l2-two':'split-greedy-separate-l2','nano/ngram-two':'wide-t020-ngram4x12',
        'lfm/budget192-two':'split-nohint192','lfm/short384-long192':'split-nohint192-short384'}
controls = {'qwen':'same-l2-two','nano':'control-two','lfm':'control-two'}
chosen, conditions, displays, holdouts, decisions = {}, {}, {}, {}, {}
head, findings = [], []
def f(v,n=2): return f'{v:.{n}f}'.replace('.',',')
def cval(result): return [result[k] for k in ('H','P','R')]
def read(path): return a['summary'](path)
def exists(p): return (p/'result.json').is_file() and a['read'](p/'result.json')['complete']
def good(before, after):
    d=a['compare'](before,after)
    old, new=read(before),read(after)
    return d['private_lost']==0 and d['public_newly_lost']==0 and new['P']<=old['P'] and new['R']<=old['R']
def full_label(key, label):
    if key=='qwen' and label=='control-two': return 'прежний режим, 2/2, возможна параллельная нагрузка'
    return labels.get(label.removesuffix('-holdout'),label)
def documents(r):
    return sum(v['prompt_seconds'] for v in r['docs'].values()),sum(v['gen_seconds'] for v in r['docs'].values())
for key,title in names.items():
    previous=a['baseline'](key)
    old=a['baseline'](key,'holdout')
    ctrl=root/key/controls[key]
    assert exists(ctrl)
    candidates=['prefill-four','four-cpu','one-line-two'] if key=='qwen' else (['prefill-four','four-cpu','ngram-two'] if key=='nano' else ['prefill-four','four-cpu','short384-long192'])
    options=[(read(ctrl)['http_seconds'],controls[key])]
    for label in candidates:
        path=root/key/label
        if not exists(path):continue
        short_label={'ngram-two':'ngram-holdout','one-line-two':'one-line-holdout'}.get(label,label+'-holdout')
        short=root/key/short_label
        okay=good(ctrl,path) and good(previous,path) and exists(short) and good(old,short)
        if okay:options.append((read(path)['http_seconds'],label))
        else:decisions[key+'/'+label]='quality_tradeoff'
    _,winner=min(options)
    chosen[key]=winner
    after=read(root/key/winner); before=read(ctrl)
    control_comparison=a['compare'](ctrl,root/key/winner)
    old_comparison=a['compare'](previous,root/key/winner)
    assert good(previous,root/key/winner) and good(ctrl,root/key/winner)
    verdict=f"расход времени сократился на {f(control_comparison['gain_percent'],1)}%" if winner!=controls[key] else 'самым быстрым с сохранением качества остался прежний профиль'
    head.append(f"**{title}.** {f(before['http_seconds']/60)} → **{f(after['http_seconds']/60)} мин** за три файла, {verdict}. Скрыто {before['H']} → {after['H']} из 193. Сохранены все ранее скрытые позиции. Публичные потери {before['P']} → {after['P']} из 87, замены в справке {before['R']} → {after['R']}.")
    mode=full_label(key,winner)
    cp,gp=documents(before); np,ng=documents(after)
    if control_comparison['matched_contents']:
        details=f"Все {after['requests']} финальных ответов совпали побайтово."
    else:
        details=f"Совпали позиции {before['H']} прежних полных скрытий, добавилось {control_comparison['private_gained']}."
    findings.append(f"**{title}, {mode}.** {details} Модель читала вход {f(cp/60)} → {f(np/60)} мин, генерировала ответ {f(gp/60)} → {f(ng/60)} мин.")
    if key=='qwen':
        findings.append('Исходный поисковый прогон Qwen дал 173/193, шесть публичных потерь, шесть замен и 32,25 мин. Пресет по рекомендации производителя скрыл 128/193 за 6,90 мин, сохранил все 87 публичных вхождений и сделал две замены в справке. В предыдущей настройке с температурой 0 удалось воспроизвести исходные 173/193, шесть публичных потерь и шесть замен за 15,06 мин. В текущем исследовании свежий контроль занял 11,97 мин. Процент экономии считается от этого последнего замера на том же стенде.')
        findings.append('С ngram-simple Qwen закрыла 144/193, пропустив 30 ранее скрытых вхождений и добавив одно. С четырьмя потоками генерации получилось 145/193. В обоих случаях в последнем ответе по логу было 15 предложений вместо 21. Модель пропустила имя сервиса `cedar-api` (14 вхождений) и базы `cedar_events` (13). Все ответы прошли проверку JSON Schema. При четырёх потоках генерации короткая тройка давала те же 17/19, что и контроль.')
    if key=='nano':
        comp=a['compare'](previous,root/key/'ngram-two')
        assert (comp['private_lost'],comp['private_gained'])==(0,1)
        findings.append('С ngram-simple Nanbeige скрыла 192/193 за 32,91 мин. В смете она закрыла все 80 приватных вхождений и сохранила все 12 публичных. В логе сохранились те же 112 скрытий, число публичных потерь возросло с двух до пяти. Все пять потерь в новом логе — один повторяющийся публичный идентификатор `rq-0001`. Во всём корпусе публичные потери выросли с трёх до пяти.')
        findings.append('В прежней публикации четыре запроса Nanbeige по логу заняли 24,28 мин. Свежий контроль вернул те же четыре JSON за 16,53 мин. Предварительный ngram-прогон на этом логе занял 19,34 мин при другой нагрузке на машину. В таблице экономия выбранного режима рассчитана относительно полного свежего контроля.')
        if exists(root/key/'ngram-holdout'):
            nshort=read(root/key/'ngram-holdout')
            findings.append(f"На коротких документах ngram-simple у Nanbeige дал {nshort['H']}/19 при {nshort['P']} публичных потерях. Прежний пресет и выбранное ускорение с четырьмя потоками чтения дали 13/19 и две публичные потери.")
    if key=='lfm':
        for p,desc in [('budget192-two','192 для всего текста'),('short384-long192','384 для коротких документов и 192 для длинных')]:
            if not exists(root/key/p): continue
            comp=a['compare'](previous,root/key/p); r=read(root/key/p)
            findings.append(f"С бюджетом рассуждений {desc} LFM скрыла {r['H']}/193 за {f(r['http_seconds']/60)} мин. Относительно прежней разметки масок появилось {comp['private_gained']} новых полных скрытий и пропало {comp['private_lost']} прежних. Публичные потери {r['P']}/87, замены в справке {r['R']}.")
        if exists(root/key/'short384-long192'):
            findings.append('В варианте LFM с двумя бюджетами среди добавлений пять вхождений `gateway.cedar.test` и два `helpdesk-demo`. Открылись два вхождения `pg01.cedar.test`, одно `cache01.cedar.test` и один номер договора. На коротком корпусе все документы получили бюджет 384.')
    all_runs={p.parent.name for p in (root/key).glob('*/result.json') if exists(p.parent)}
    fullorder=[controls[key],'control-two','prefill-four','four-cpu','separate-l2-two','one-line-two','ngram-two','budget192-two','short384-long192']
    displays[key]=list(dict.fromkeys(s for s in fullorder if s in all_runs))
    holdouts[key]=sorted(s for s in all_runs if s.endswith('holdout'))
    for j in all_runs:conditions[key+'/'+j]=full_label(key,j)
    decisions[key+'/'+winner]='selected' if winner!=controls[key] else 'control_retained'
    if key=='qwen':
        decisions.update({'qwen/ngram-two':'rejected_quality','qwen/four-cpu':'rejected_quality',
                          'qwen/separate-l2-two':'no_paired_speedup'})
if exists(root/'qwen/one-line-holdout'):
    path=root/'qwen/one-line-holdout'; r=read(path)
    text=(f"Qwen с компактным JSON на коротком наборе скрыла {r['H']}/19 за {f(r['http_seconds'],1)} с при {r['P']} публичных потерях и {r['R']} заменах в справке.")
    if not exists(root/'qwen/one-line-two'):
        prior=read(a['baseline']('qwen','holdout'))
        bt=sum(v['completion_tokens'] for v in prior['docs'].values())
        nt=sum(v['completion_tokens'] for v in r['docs'].values())
        missed=a['compare'](a['baseline']('qwen','holdout'),path)['missing_positions']
        text+=f" Число токенов ответа сократилось с {bt} до {nt}."
        if missed:
            text+=' В коротком логе пропущено ранее скрытое значение '+', '.join('`'+v+'`' for _,v,_,_ in missed)+'. Вариант отклонён на короткой проверке.'
            decisions['qwen/one-line-holdout']='rejected_quality_on_short_corpus'
    findings.append(text)
    if exists(root/'qwen/one-line-two'):
        full=root/'qwen/one-line-two'
        rr=read(full); comp=a['compare'](a['baseline']('qwen'),full)
        findings.append(f"Компактный JSON в полном двухпоточном прогоне потребовал {f(rr['http_seconds']/60)} мин. Скрыто {rr['H']}/193, пропало {comp['private_lost']} прежних скрытий, добавилось {comp['private_gained']}. Публичные потери {rr['P']}, замены в справке {rr['R']}.")
supp=('В эксперименте число потоков задавали при запуске llama.cpp. Режим «чтение 4, генерация 2» запускался с `-t 2 -tb 4 -np 1`. '
      'В текущем Worker параметр `[worker].threads` задаёт одновременно `-t` и `-tb`. Результат с раздельными значениями получен через параметр `[worker].runtime` и обёртку над тем же бинарником. '
      'Остальные настройки моделей приведены в [таблице проверенных пресетов](FOUR_MODEL_TUNING.md#выбранные-параметры).')
result={'headline':head,'controls':controls,'recommended':chosen,'labels':conditions,'display_order':displays,
        'holdouts':holdouts,'decisions':decisions,'rank':{k:v for k,v in rank.items() if exists(root/k)},
        'findings':findings,'supplement':supp}
(root/'selection.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'recommended':chosen,'head':head},ensure_ascii=False,indent=2))
