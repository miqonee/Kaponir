"""Read byte-BPE newline-bearing tokens directly from the local, pinned GGUF."""
import struct
from pathlib import Path

def newline_ids(path):
    lengths={0:1,1:1,2:2,3:2,4:4,5:4,6:4,7:1,10:8,11:8,12:8}
    with Path(path).open('rb') as f:
        def integer(fmt):
            return struct.unpack('<'+fmt,f.read(struct.calcsize(fmt)))[0]
        def string():
            return f.read(integer('Q')).decode()
        def skip_string():
            f.seek(integer('Q'),1)
        assert f.read(4)==b'GGUF' and integer('I') in (2,3)
        integer('Q')
        vocab_size=integer('Q')
        model=None
        for _ in range(vocab_size):
            key=string()
            kind=integer('I')
            if kind==8:
                if key=='tokenizer.ggml.model':model=string()
                else:skip_string()
            elif kind==9:
                item=integer('I'); count=integer('Q')
                if key=='tokenizer.ggml.tokens':
                    assert item==8 and model in ('gpt2','llama'),(item,model)
                    tokens=[string() for _ in range(count)]
                    if model=='gpt2':
                        return [i for i,t in enumerate(tokens) if 'Ċ' in t]
                    return [i for i,t in enumerate(tokens) if '\n' in t or t=='<0x0A>']
                if item==8:
                    for _ in range(count):skip_string()
                else:f.seek(lengths[item]*count,1)
            else:f.seek(lengths[kind],1)
    raise ValueError('missing GGUF vocabulary')
if __name__=='__main__':
    import sys
    for p in sys.argv[1:]:
        ids=newline_ids(p);print(Path(p).name,len(ids),ids[:12])
