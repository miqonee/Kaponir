"""Check the effect of single-line JSON on a two-thread server after the paired runs."""
import fcntl
import runpy
import subprocess
import sys
import time
from pathlib import Path

work = Path(__file__).resolve().parent
audit = runpy.run_path(str(work / 'analyze-kaponir-speed.py'))
root = audit['SPEED']
marker = root / 'exclusive-requested'
while marker.exists() or not (root / 'nano/ngram-holdout/result.json').is_file():
    time.sleep(3)

def run(sample):
    label = 'one-line-holdout' if sample == 'holdout' else 'one-line-two'
    path = root / 'qwen' / label
    if not (path / 'result.json').exists():
        subprocess.run([sys.executable, '-Bu', str(work / 'measure-kaponir-speed.py'),
                        'qwen', label, '--sample', sample, '--cpu-list', '2,3',
                        '--one-line', '--isolated'], check=True)
    return path

with (root / 'shared-cpus.lock').open('a') as gate:
    fcntl.flock(gate, fcntl.LOCK_EX)
    marker.touch()
    try:
        short = run('holdout')
        old = audit['baseline']('qwen', 'holdout')
        metrics = audit['summary'](short)
        base = audit['summary'](old)
        def output_tokens(result):
            return sum(row['completion_tokens'] for row in result['docs'].values())
        preserve = (audit['compare'](old, short)['private_lost'] == 0 and
                    metrics['P'] <= base['P'] and metrics['R'] <= base['R'])
        qualifies = (preserve and output_tokens(metrics) < .85 * output_tokens(base)
                     and metrics['http_seconds'] < base['http_seconds'])
        print('Single-line holdout', metrics['H'], metrics['P'], metrics['R'], 'qualified', qualifies, flush=True)
        if qualifies:
            run('full')
    finally:
        marker.unlink(missing_ok=True)
