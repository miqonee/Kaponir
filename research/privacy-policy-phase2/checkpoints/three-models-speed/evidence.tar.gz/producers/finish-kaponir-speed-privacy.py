"""Keep prior generation settings as a speed candidate on each model; test actual masks."""
import os
from pathlib import Path
import subprocess
import sys
import time

work=Path(__file__).resolve().parent
out=work/'kaponir-hybrid-pilot/three-models-speed-v1'
active={}
def start(key,label,lane,options,drain=False):
    if (out/key/label/'result.json').exists():return
    env=os.environ.copy()
    if drain:env['KAPONIR_SPEED_DRAIN']='1'
    cmd=[sys.executable,'-Bu',str(work/'measure-kaponir-speed.py'),key,label,'--cpu',str(lane),*options]
    proc=subprocess.Popen(cmd,env=env)
    active[key]=(label,proc)
    print('START',label,key,options,flush=True)

# A short Nanbeige placement check can use CPUs 0 and 4 while Qwen's old control runs on 2 and 3.
while not (out/'nano/ngram-two/result.json').exists() and not (out/'qwen/control-two/result.json').exists():time.sleep(2)
if (out/'nano/ngram-two/result.json').exists() and not (out/'qwen/control-two/result.json').exists():
    start('nano','separate-l2-holdout',0,['--cpu-list','0,4','--sample','holdout'],True)

queues={
 'nano':[('separate-l2-two',['--cpu-list','0,4']),('separate-l2-holdout',['--cpu-list','0,4','--sample','holdout']),
         ('ngram-holdout',['--ngram','--sample','holdout'])],
 'lfm':[('separate-l2-two',['--cpu-list','2,4']),
        ('separate-l2-holdout',['--cpu-list','2,4','--sample','holdout']),
        ('short384-long192',['--budget','192','--short-budget','384']),
        ('short384-long192-holdout',['--budget','192','--short-budget','384','--sample','holdout'])]
}
while queues or active:
    for key,(label,proc) in list(active.items()):
        if proc.poll() is not None:
            print('END',key,label,proc.returncode,flush=True)
            del active[key]
    for key,queue in list(queues.items()):
        if key in active or not (out/key/'control-two/result.json').exists():continue
        if not queue:
            del queues[key]
            continue
        label,opts=queue.pop(0)
        start(key,label,0 if key=='nano' else 2,opts)
    if queues or active:time.sleep(2)
