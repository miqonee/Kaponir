from pathlib import Path
import os
import subprocess
import sys
import time
work=Path(__file__).resolve().parent
out=work/'kaponir-hybrid-pilot/three-models-speed-v1'
while not any((out/k/(j+'/result.json')).exists() for k,j in [('qwen','control-two'),('nano','ngram-two')]):time.sleep(2)
if (out/'qwen/control-two/result.json').exists() and not (out/'nano/ngram-two/result.json').exists():
    env=os.environ.copy();env['KAPONIR_SPEED_DRAIN']='1'
    subprocess.run([sys.executable,'-Bu',str(work/'measure-kaponir-speed.py'),'qwen','placement-check-holdout','--cpu','2',
                    '--cpu-list','2,4','--sample','holdout'],env=env,check=True)
