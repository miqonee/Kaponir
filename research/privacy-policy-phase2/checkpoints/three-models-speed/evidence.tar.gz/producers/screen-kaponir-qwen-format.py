"""A short formatting-only run after the quality-preserving CPU placement comparison."""
from pathlib import Path
import json
import runpy
import subprocess
import sys
import time

work=Path(__file__).resolve().parent
a=runpy.run_path(str(work/'analyze-kaponir-speed.py'))
root=a['SPEED'];flag=root/'qwen-isolated-finished.json'
while not flag.is_file():time.sleep(2)
def run(label,sample):
    subprocess.run([sys.executable,'-Bu',str(work/'measure-kaponir-speed.py'),'qwen',label,'--cpu','2',
                    '--one-line','--sample',sample],check=True)
run('one-line-holdout','holdout')
new=root/'qwen/one-line-holdout';old=a['baseline']('qwen','holdout')
b=a['summary'](old);s=a['summary'](new);comparison=a['compare'](old,new)
valid=(comparison['private_lost']==0 and s['P']<=b['P'] and s['R']<=b['R']
       and sum(d['completion_tokens'] for d in s['docs'].values())<.85*sum(d['completion_tokens'] for d in b['docs'].values()))
print('Format-only Qwen holdout',s['H'],s['P'],s['R'],'eligible',valid,flush=True)
if valid and not json.loads(flag.read_text())['eligible_faster']:
    run('one-line-two','full')
