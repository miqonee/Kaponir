"""Confirm the LFM log-chunk preset with new inference on all three documents."""

from argparse import Namespace
import os
from pathlib import Path
import runpy
from tempfile import TemporaryDirectory
import time

from experiment_inference import discover, prompts_and_kinds
from kaponir_worker import Worker, configuration
from run_privacy_policy_suite import SuiteLock, atomic_json, file_sha, runtime_processes
from summarize_privacy_policy import require


REFERENCE = runpy.run_path(str(Path(__file__).with_name('check-kaponir-lfm-large.py')))
STUDY, RUNTIME, BINARY = (REFERENCE[key] for key in ('ROOT', 'RUNTIME', 'BINARY'))
MODEL, LOG, TARGET = (REFERENCE[key] for key in ('LFM12', 'LOG', 'LOG_INPUT_TARGET'))
OUTPUT = REFERENCE['WORK'].parent / 'lfm12-log-chunks-full-confirmation'


def main():
    require(not OUTPUT.exists(), 'confirmation_already_exists')
    require(file_sha(RUNTIME) == REFERENCE['RUNTIME_SHA256'], 'runtime_changed')
    binary_sha = file_sha(BINARY)
    require(binary_sha == REFERENCE['read'](STUDY/'status.json')['binary_sha256'], 'application_binary_changed')
    sources, private, public, pool = REFERENCE['corpus']()
    anchor = REFERENCE['originals'](MODEL, sources, binary_sha)
    recorded = REFERENCE['read'](REFERENCE['WORK']/MODEL/'log-chunks/transports.json')
    profile = anchor['profile']
    require(recorded['profile'] == profile, 'original_split_profile_changed')
    original_chunks = [(row['request_sha256'], row['rendered_prompt_sha256']) for row in recorded['requests']]
    require(len(original_chunks) == 4, 'expected_four_log_fragments')
    name, size, sha, _ = anchor['artifact']
    weights = STUDY/'models'/name
    require(weights.stat().st_size == size and file_sha(weights) == sha, 'model_weights_changed')
    cores = sorted(os.sched_getaffinity(0))[:2]
    require(len(cores) == 2, 'need_two_worker_cpus')
    os.sched_setaffinity(0, cores)
    args = Namespace(**profile, candidate_mode='typed', strategy='auto', target_input_tokens=0)
    prompt, _, kinds = prompts_and_kinds()
    history, measured = [], {}
    with SuiteLock(STUDY/'.native-retest.lock'), REFERENCE['research_registration'](
            MODEL, REFERENCE['catalog_for'](MODEL)), TemporaryDirectory(prefix='kaponir-lfm-confirm-') as td:
        require(not runtime_processes(RUNTIME), 'runtime_already_running')
        OUTPUT.mkdir()
        atomic_json(OUTPUT/'plan.json', {'model': MODEL, 'profile': profile,
            'artifact': anchor['artifact'], 'source_sha256': anchor['source_sha256'],
            'runtime_sha256': file_sha(RUNTIME), 'binary_sha256': binary_sha,
            'log_target_input_tokens': TARGET, 'cpu_affinity': cores})
        home = Path(td)
        worker = Worker(home, configuration(home, {'model_dir': str(STUDY/'models'),
                        'runtime': str(RUNTIME), 'threads': 2,
                        'ocr_timeout_seconds': profile['worker_configuration_timeout_seconds']}), 'unused')
        started = time.monotonic()
        try:
            generation = {key: profile[key] for key in ('temperature','top_p','top_k','min_p','seed')}
            client = REFERENCE['MeasuredClient'](worker, MODEL, profile['context_tokens'], profile['output_tokens'],
                        profile['response_format'], generation, profile, OUTPUT, history)
            search_started = time.monotonic()
            for name, text in sources.items():
                client.measurement_stage = f'discovery:{name}'
                args.target_input_tokens = TARGET if name == LOG else 0
                before = len(history)
                stage = discover(client, text, prompt, kinds, args, client.save_history, {})
                calls = history[before:]
                REFERENCE['measured_requests_ok'](calls, anchor['requests'][name], text, {}, args.target_input_tokens)
                if name == LOG:
                    same_chunks = [(r['request_sha256'], r['rendered_prompt_sha256']) for r in calls]
                    require(same_chunks == original_chunks, 'log_requests_differ_from_selected_preset')
                require(not stage['errors'], 'discovery_incomplete')
                elapsed = sum(r['record']['http_wall_seconds'] for r in calls)
                measured[name] = {**stage, 'requests': len(calls), 'http_seconds': elapsed}
                atomic_json(OUTPUT/'discovery.json', measured)
                print(name, len(calls), round(elapsed, 2), flush=True)
            search_elapsed = time.monotonic() - search_started
        finally:
            worker.stop_runtime()
        application = REFERENCE['apply_stage'](MODEL, 'log-chunks-full-confirmation', measured, sources,
                    private, public, pool, anchor['source_sha256'], OUTPUT)
        result = {**application, 'wall_search_seconds': search_elapsed,
                  'wall_with_start_and_api_seconds': time.monotonic() - started,
                  'fresh_requests': len(history)}
        atomic_json(OUTPUT/'result.json', result)
        print('FULL', len(history), result['http_seconds'], search_elapsed,
              result['wall_with_start_and_api_seconds'], result['exact_roundtrips'])


if __name__ == '__main__':
    main()
