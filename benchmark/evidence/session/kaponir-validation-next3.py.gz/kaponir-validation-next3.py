import json,subprocess,sys
from pathlib import Path
root=Path('/workspace/Kaponir');base=root/'artifacts/validation-schemes'
common=[sys.executable,'scripts/evaluate_validation_schemes.py','--model-dir','/tmp/kaponir-three-models','--runtime','/tmp/kaponir-real-eval/models/runtime/llama-b12038/llama-server','--detectors',str(base/'detector_candidates'),'--probes-only','--context-policy','balanced']
models=json.loads((root/'tests/fixtures/validation-models.json').read_text())['models']
runs=[('nanbeige-probes-prompt-single',['--model',models[1]['id'],'--hf-url',models[1]['url'],'--response-format','prompt','--batch-size','1']),
      ('minicpm-probes-single',['--model','minicpm5-2b','--batch-size','1']),
      ('minicpm-probes-prompt-single',['--model','minicpm5-2b','--response-format','prompt','--batch-size','1'])]
for name,args in runs:
 print('START',name,flush=True)
 with open('/tmp/kaponir-validation-'+name+'.log','a') as log:
  subprocess.run(common+args+['--output',str(base/name)],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('DONE',name,flush=True)
state=json.loads((base/'nanbeige-probes-prompt-single/result.json').read_text())
Path('/tmp/kaponir-three-models/MiniCPM5-2B-Q4_K_M.gguf').unlink()
(Path('/tmp/kaponir-three-models')/state['signature']['artifact'][0]).unlink()
model=models[2];name='granite-probes-prompt-single';print('START',name,flush=True)
with open('/tmp/kaponir-validation-'+name+'.log','w') as log:
 subprocess.run(common+['--model',model['id'],'--hf-url',model['url'],'--response-format','prompt','--batch-size','1','--output',str(base/name)],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
print('DONE',name,flush=True)
