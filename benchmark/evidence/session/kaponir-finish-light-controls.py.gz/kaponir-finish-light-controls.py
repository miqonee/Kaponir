"""Continue the frozen local controls sequentially; checkpoint every job."""
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path('/workspace/Kaponir')
BASE=ROOT/'artifacts/validation-schemes'
CONTROL=BASE/'context-controls'
MODELS='/tmp/kaponir-three-models'
RUNTIME='/tmp/kaponir-real-eval/models/runtime/llama-b12038/llama-server'
STATUS=BASE/'light-control-queue.json'
sys.path.insert(0,str(ROOT/'scripts'))
from evaluate_validation_schemes import atomic_json

jobs=[]
def control(label,model,*flags):
    jobs.append((label,[sys.executable,'scripts/evaluate_context_controls.py',
        '--model',model,'--model-dir',MODELS,'--runtime',RUNTIME,
        '--detectors',str(BASE/'detector_candidates'),'--output',str(CONTROL/label),*flags]))

control('qwen08-common','qwen3.5-0.8b','--thinking','bounded','off')
control('qwen08-prompt-document','qwen3.5-0.8b','--tasks','review','--contexts','document',
        '--thinking','off','--response-format','prompt')
control('qwen08-native-document','qwen3.5-0.8b','--tasks','discovery','--thinking','on','--timeout','1200')
control('qwen2-common','qwen3.5-2b','--thinking','bounded','off')
control('qwen2-prompt-document','qwen3.5-2b','--tasks','review','--contexts','document',
        '--thinking','off','--response-format','prompt')
jobs.append(('selected-holdout',[sys.executable,'/tmp/kaponir-holdout-after-matrix.py']))
control('qwen2-native-document','qwen3.5-2b','--tasks','discovery','--thinking','on','--timeout','1200')
control('minicpm-common','minicpm5-2b','--thinking','bounded','off')
control('minicpm-prompt-document','minicpm5-2b','--tasks','review','--contexts','document',
        '--thinking','off','--response-format','prompt')
control('minicpm-native-document','minicpm5-2b','--tasks','discovery','--thinking','on','--timeout','1200')
control('minicpm-card-document','minicpm5-2b','--tasks','discovery','--thinking','off','on',
        '--temperature','1','--top-p','0.95','--min-p','0','--seed','42','--timeout','1200')

state={'status':'waiting_for_existing_qwen08','jobs':{name:{'status':'pending','command':cmd} for name,cmd in jobs}}
atomic_json(STATUS,state)
# Resume the existing command, never launch a second model alongside it.
existing=Path('/proc/76589/cmdline')
while existing.exists():
    try:cmdline=existing.read_bytes()
    except FileNotFoundError:break
    if b'evaluate_context_controls.py' not in cmdline:break
    time.sleep(10)
for label,command in jobs:
    state['status']='running';state['active_job']=label
    row=state['jobs'][label];row.update(status='running',started=time.time());atomic_json(STATUS,state)
    print(json.dumps({'job':label,'status':'running'}),flush=True)
    with Path('/tmp/kaponir-'+label+'.log').open('a') as log:
        process=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
    row.update(status='completed' if process.returncode==0 else 'failed',returncode=process.returncode,ended=time.time())
    atomic_json(STATUS,state)
    print(json.dumps({'job':label,**row}),flush=True)
    if process.returncode:
        state['status']='failed';atomic_json(STATUS,state);sys.exit(process.returncode)
state['status']='completed';state.pop('active_job',None);atomic_json(STATUS,state)
