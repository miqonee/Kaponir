import subprocess,sys
common=[sys.executable,'scripts/experiment_inference.py','--url','https://route.fn.x3dev.ru/v1','--model','ag/gemini-3.8-flash','--key-file','/tmp/kaponir-eval-api-key','--transport-retries','2','--context-tokens','32768','--output-tokens','4096','--max-candidates','128','--candidate-mode','lean','--hint-tokens','256','--skip-review','--documents','01-cost-estimate.md']
for name,extra in [('external-exhaustive-whole',[]),('external-exhaustive-focused',['--target-input-tokens','4096'])]:
 print('START',name,flush=True)
 subprocess.run([*common,*extra,'--output','artifacts/inference-lab/'+name],check=True)
