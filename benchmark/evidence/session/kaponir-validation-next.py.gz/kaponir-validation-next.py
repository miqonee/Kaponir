import json, subprocess, sys, time
from pathlib import Path
root=Path('/workspace/Kaponir')
base=root/'artifacts/validation-schemes'
while True:
 state=json.loads((base/'minicpm-calibration/result.json').read_text())
 if state['status']=='completed': break
 if state['status']=='failed': raise RuntimeError('calibration_failed')
 time.sleep(5)
common=[sys.executable,'scripts/evaluate_validation_schemes.py','--model-dir','/tmp/kaponir-three-models','--runtime','/tmp/kaponir-real-eval/models/runtime/llama-b12038/llama-server','--detectors',str(base/'detector_candidates')]
runs=[('minicpm-balanced',['--model','minicpm5-2b','--schemes','point','--context-policy','balanced']),
      ('minicpm-probes',['--model','minicpm5-2b','--probes-only','--context-policy','balanced'])]
for name,args in runs:
 print('START',name,flush=True)
 with open('/tmp/kaponir-validation-'+name+'.log','w') as log:
  subprocess.run(common+args+['--output',str(base/name)],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('DONE',name,flush=True)
model=json.loads((root/'tests/fixtures/validation-models.json').read_text())['models'][1]
name='nanbeige-probes'
print('START',name,flush=True)
with open('/tmp/kaponir-validation-'+name+'.log','w') as log:
 subprocess.run(common+['--model',model['id'],'--hf-url',model['url'],'--probes-only','--context-policy','balanced','--output',str(base/name)],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
print('DONE',name,flush=True)
