from pathlib import Path
from functools import lru_cache
import hashlib
import json
import sys
sys.path.insert(0,'/workspace/Kaponir/scripts')
from kaponir_worker import http_json,FILES
from check_learning_corpus import load_corpus
from validation_pipeline import Candidate,candidate_context
from evaluate_validation_schemes import atomic_json

root=Path('/workspace/Kaponir');base=root/'artifacts/validation-schemes'
state=json.loads((base/'context-controls/qwen2-common/result.json').read_text())
for directory in Path('/proc').glob('[0-9]*'):
    try:args=[a.decode() for a in (directory/'cmdline').read_bytes().split(b'\0') if a]
    except (FileNotFoundError,PermissionError,ProcessLookupError):continue
    if args and args[0]=='/tmp/kaponir-real-eval/models/runtime/llama-b12038/llama-server':
        assert Path(args[args.index('-m')+1]).name==FILES['qwen3.5-2b'][0]
        endpoint='http://127.0.0.1:'+args[args.index('--port')+1];break
else:raise RuntimeError('matching_native_runtime_not_found')
@lru_cache(maxsize=256)
def count(text):return len(http_json(endpoint+'/tokenize',{'content':text,'add_special':False})['tokens'])
_,gold,_,sources,_=load_corpus()
cases=json.loads((root/'tests/fixtures/context-control-candidates.json').read_text())['candidates']
case=Candidate(**next(c for c in cases if c['value']=='740,00 ₽'))
text=sources[case.file]
assert hashlib.sha256(text.encode()).hexdigest()==state['signature']['source_sha256'][case.file]
context=candidate_context(case,text,count,256)
assert state['calls'][0]['stage']=='review-record-bounded'
first=next(iter(state['responses'].values()))
rows=[row for row in first['reply']['decisions'] if row['id']==case.id]
assert len(rows)==1
probe={'status':'completed','shadow':True,'rules_changed':0,'model':'qwen3.5-2b',
    'artifact':list(FILES['qwen3.5-2b']),'source_sha256':state['signature']['source_sha256'][case.file],
    'file':case.file,'value':case.value,'context_policy':'prefix','hint_budget':256,
    'hint_actual_tokens':count(context['context']),
    'confidentiality_statement_present':'распространение вне рабочей группы запрещено' in context['context'],
    'context':context['context'],'model_decision':rows[0],
    'gold':gold[(case.file,case.value)],
    'probe_method':'Read-only /tokenize on the same running Qwen2 runtime, reconstructing the frozen candidate_context. No new inference.',
    'source_code_sha256':{name:hashlib.sha256((root/'scripts'/name).read_bytes()).hexdigest()
        for name in ['validation_pipeline.py','kaponir_inference.py']}}
atomic_json(base/'context-budget-probe.json',probe)
print(json.dumps({key:probe[key] for key in ['model','hint_actual_tokens','confidentiality_statement_present']}))
