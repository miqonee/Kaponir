import argparse,hashlib,json,sys,tempfile,time
from pathlib import Path
ROOT=Path('/workspace/Kaponir');sys.path.insert(0,str(ROOT/'scripts'))
from kaponir_worker import Worker,configuration
from experiment_inference import LocalClient,prompts_and_kinds
from evaluate_validation_schemes import Experiment,atomic_json
from validation_pipeline import Candidate,PRIMARY_PROMPT
from check_learning_corpus import load_corpus

state=json.loads((ROOT/'artifacts/validation-schemes/qwen-calibration/result.json').read_text())
args=argparse.Namespace(**state['signature']['settings']);args.context_policy='prefix'
_,_,_,sources,_=load_corpus();sources={name:sources[name] for name in args.documents}
with tempfile.TemporaryDirectory(prefix='kaponir-cache-replay-') as temporary:
    home=Path(temporary);worker=Worker(home,configuration(home,{
        'model_dir':'/tmp/kaponir-three-models','runtime':'/tmp/kaponir-real-eval/models/runtime/llama-b12038/llama-server','threads':2}),'unused')
    try:
        client=LocalClient(worker,'qwen3.5-2b',args.context_tokens,args.output_tokens)
        _,_,kinds=prompts_and_kinds()
        experiment=Experiment(client,args,sources,kinds,state,lambda:None)
        captured=[]
        class Captured(Exception):pass
        def capture(stage,prompt,value,schema):
            key=hashlib.sha256(json.dumps([stage,prompt,value,schema],sort_keys=True,ensure_ascii=False).encode()).hexdigest()
            previous=state['responses'][key]
            captured.append((key,prompt,value,schema,previous))
            if len(captured)==2:raise Captured()
            return previous
        experiment.infer=capture
        try:experiment.validate('point',[Candidate(**c) for c in state['candidate_pool']],PRIMARY_PROMPT)
        except Captured:pass
        result={'model':'qwen3.5-2b','new_cache_ram_mib':0,'requests':[]}
        for key,prompt,value,schema,previous in captured:
            reply=client.infer(prompt,value,schema,args.output_tokens)
            row={'request_key':key,'matches_previous_reply':reply==previous['reply'],
                'old_reply_sha256':hashlib.sha256(json.dumps(previous['reply'],sort_keys=True,ensure_ascii=False).encode()).hexdigest(),
                'new_reply_sha256':hashlib.sha256(json.dumps(reply,sort_keys=True,ensure_ascii=False).encode()).hexdigest(),
                'telemetry':client.records[-1]}
            result['requests'].append(row)
            atomic_json(ROOT/'artifacts/validation-schemes/runtime-cache-replay.json',result)
            print(json.dumps(row),flush=True)
        if not all(r['matches_previous_reply'] for r in result['requests']):raise RuntimeError('replay_answers_changed')
    finally:
        worker.stop.set();worker.stop_runtime()
