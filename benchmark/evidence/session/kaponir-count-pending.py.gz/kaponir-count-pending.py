import argparse,json,hashlib,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path('/workspace/Kaponir');sys.path.insert(0,str(ROOT/'scripts'))
from kaponir_worker import Worker,configuration
from validation_pipeline import Candidate,AUDIT_PROMPT
from evaluate_validation_schemes import Experiment
from experiment_inference import prompts_and_kinds
from check_learning_corpus import load_corpus
name=sys.argv[1] if len(sys.argv)>1 else 'qwen-calibration'
s=json.loads((ROOT/'artifacts/validation-schemes'/name/'result.json').read_text())
server=next(row.split() for row in subprocess.check_output(['ps','-eo','args'],text=True).splitlines()
            if row.startswith('/tmp/kaponir-real-eval/models/runtime/llama-b12038/llama-server '))
port=server[server.index('--port')+1]
with tempfile.TemporaryDirectory(prefix='kaponir-count-') as tmp:
    home=Path(tmp);w=Worker(home,configuration(home),'unused');w.ocr_base='http://127.0.0.1:'+port
    try:
        client=argparse.Namespace(token_count=w.count_text_tokens,input_tokens=lambda p,v,sch:w.prompt_token_count(p,v))
        args=argparse.Namespace(**s['signature']['settings']);args.context_policy='prefix'
        _,_,_,sources,_=load_corpus();_,_,kinds=prompts_and_kinds()
        e=Experiment(client,args,sources,kinds,s,lambda:None);calls=[]
        def infer(stage,prompt,value,schema):
            key=hashlib.sha256(json.dumps([stage,prompt,value,schema],sort_keys=True,ensure_ascii=False).encode()).hexdigest()
            cached=s['responses'].get(key);calls.append({'cached':cached is not None,'items':len(value['items'])})
            return cached if cached is not None else {'error':'pending'}
        e.infer=infer
        e.validate('audit',[Candidate(**c) for c in s['stages']['current_union']['candidates']],AUDIT_PROMPT)
        print(json.dumps({'model':s['signature']['model'],'audit_batches':len(calls),
              'completed_batches':sum(c['cached'] for c in calls),'remaining_batches':sum(not c['cached'] for c in calls),
              'remaining_candidates':sum(c['items'] for c in calls if not c['cached'])}))
    finally:w.stop.set()
