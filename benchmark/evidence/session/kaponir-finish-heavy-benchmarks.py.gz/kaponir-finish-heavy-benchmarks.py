"""Run larger catalog models only after the light controls and holdout finish.

All removable files below were created for this benchmark in /tmp or target/debug.
User model directories, documents, settings and vaults are never modified.
"""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

ROOT=Path('/workspace/Kaponir');BASE=ROOT/'artifacts/validation-schemes'
STATUS=BASE/'heavy-benchmark-queue.json';LIGHT=BASE/'light-control-queue.json'
MODELS=Path('/tmp/kaponir-three-models')
RUNTIME=Path('/tmp/kaponir-real-eval/models/runtime/llama-b12038/llama-server')
BACKUP=Path('/tmp/kaponir-benchmark-toolchain.tar.zst')
sys.path.insert(0,str(ROOT/'scripts'))
from evaluate_validation_schemes import atomic_json
from kaponir_worker import Worker,configuration,FILES

PLANS=[('nanbeige42-3b','nanbeige',.6,20),('granite42-3b','granite',1,40),
       ('gemma4-e4b-qat','gemma',1,64)]
state=(json.loads(STATUS.read_text()) if STATUS.exists() else
       {'status':'waiting_for_light_controls','jobs':{},'source':'synthetic repository fixtures',
        'cleanup_scope':'task-owned /tmp/kaponir-three-models weights and reproducible task build caches only'})
state['status']='waiting_for_light_controls'
atomic_json(STATUS,state)
def save():atomic_json(STATUS,state)
def log(message):print(json.dumps(message,ensure_ascii=False),flush=True)
def native_running():
    for directory in Path('/proc').glob('[0-9]*'):
        try:args=(directory/'cmdline').read_bytes().split(b'\0')
        except (FileNotFoundError,PermissionError,ProcessLookupError):continue
        if args and args[0]==str(RUNTIME).encode() and any(str(MODELS).encode() in arg for arg in args):return True
    return False
def publish():
    for script in ['report_validation_results.py','export_validation_evidence.py']:
        subprocess.run([sys.executable,str(ROOT/'scripts'/script)],cwd=ROOT,check=True)
def completed(label):
    row=state['jobs'].get(label,{})
    if row.get('status')!='completed':return False
    command=row.get('command',[])
    if '--output' not in command:return False
    path=Path(command[command.index('--output')+1])/'result.json'
    return path.exists() and json.loads(path.read_text()).get('status')=='completed'
def run(label,command):
    previous=state['jobs'].get(label,{})
    if completed(label):
        if previous['command']!=command:raise RuntimeError('completed_job_command_changed:'+label)
        log({'job':label,'status':'reused_completed'});publish();return
    row={'status':'running','command':command,'started':time.time()}
    state['jobs'][label]=row;state.update(status='running',active_job=label);save();log({'job':label,'status':'running'})
    with Path('/tmp/kaponir-'+label+'.log').open('a') as output:
        result=subprocess.run(command,cwd=ROOT,stdout=output,stderr=subprocess.STDOUT)
    row.update(status='completed' if result.returncode==0 else 'failed',returncode=result.returncode,ended=time.time());save()
    log({'job':label,**row})
    if result.returncode:raise RuntimeError('benchmark_failed:'+label)
    publish()

try:
    while True:
        if LIGHT.exists():
            light=json.loads(LIGHT.read_text())
            if light['status']=='failed':raise RuntimeError('light_controls_failed')
            if light['status']=='completed' and not native_running():break
        time.sleep(10)
    holdout=json.loads((BASE/'selected-holdout/result.json').read_text())
    if holdout['status']!='completed':raise RuntimeError('holdout_not_completed')
    state['light_queue_sha256']=hashlib.sha256(LIGHT.read_bytes()).hexdigest();save()
    publish()
    native_prompt=[sys.executable,str(ROOT/'scripts/evaluate_context_controls.py'),
        '--model','qwen3.5-0.8b','--model-dir',str(MODELS),'--runtime',str(RUNTIME),
        '--detectors',str(BASE/'detector_candidates'),'--tasks','discovery',
        '--thinking','on','--response-format','prompt','--timeout','1200',
        '--output',str(BASE/'context-controls/qwen08-native-prompt')]
    run('qwen08-native-prompt',native_prompt)
    # Same oracle cases as record/off, changing only the number per request.
    # This is not detector recall and does not replace the 92-value scheme matrix.
    for model,label in [('qwen3.5-0.8b','qwen08'),('qwen3.5-2b','qwen2'),('minicpm5-2b','minicpm')]:
        individual=[sys.executable,str(ROOT/'scripts/evaluate_context_controls.py'),
            '--model',model,'--model-dir',str(MODELS),'--runtime',str(RUNTIME),
            '--detectors',str(BASE/'detector_candidates'),'--tasks','review',
            '--contexts','record','--thinking','off','--batch-size','1',
            '--output',str(BASE/'context-controls'/(label+'-single-record'))]
        run(label+'-single-record',individual)
    preserve=Path('/tmp/kaponir-preserved-build');preserve.mkdir(exist_ok=True)
    for name,source in [('kaponir',ROOT/'target/debug/kaponir'),
                        ('classifier_audit',ROOT/'target/debug/examples/classifier_audit')]:
        if source.exists():shutil.copy2(source,preserve/name)
        elif not (preserve/name).exists():raise RuntimeError('missing_preserved_build:'+name)
    # Only the pinned, task-owned baseline downloads; all their runs are finished.
    for model in ['qwen3.5-0.8b','qwen3.5-2b','minicpm5-2b']:
        (MODELS/FILES[model][0]).unlink(missing_ok=True)
    for model,label,temperature,top_k in PLANS:
        if completed(label+'-calibration') and completed(label+'-card-document'):
            (MODELS/FILES[model][0]).unlink(missing_ok=True)
            log({'model':model,'status':'reused_completed'});continue
        if model=='gemma4-e4b-qat':
            state.update(status='backing_up_task_toolchain');save()
            if not BACKUP.exists():
                subprocess.run(['tar','-I','zstd -1 -T1','-cf',str(BACKUP),'-C','/tmp',
                                'kaponir-cargo','kaponir-rustup'],check=True)
            subprocess.run(['tar','-I','zstd','-tf',str(BACKUP)],stdout=subprocess.DEVNULL,check=True)
            for directory in [ROOT/'target/debug',Path('/tmp/kaponir-cargo'),Path('/tmp/kaponir-rustup')]:
                if directory.exists():shutil.rmtree(directory)
        state.update(status='installing_model',active_job=model);save();log({'model':model,'status':'installing'})
        with tempfile.TemporaryDirectory(prefix='kaponir-heavy-install-') as temporary:
            home=Path(temporary)
            worker=Worker(home,configuration(home,{'model_dir':str(MODELS),'runtime':str(RUNTIME)}),'unused')
            try:
                job=worker.submit('download',model=model);worker.install(job['id'],model)
            finally:worker.stop.set();worker.stop_runtime()
        common=[sys.executable,str(ROOT/'scripts/evaluate_validation_schemes.py'),
                '--model',model,'--model-dir',str(MODELS),'--runtime',str(RUNTIME),
                '--detectors',str(BASE/'detector_candidates'),'--response-format','auto',
                '--timeout','1200',
                '--output',str(BASE/(label+'-calibration'))]
        run(label+'-calibration',common)
        card=[sys.executable,str(ROOT/'scripts/evaluate_context_controls.py'),
              '--model',model,'--model-dir',str(MODELS),'--runtime',str(RUNTIME),
              '--detectors',str(BASE/'detector_candidates'),'--contexts','document',
              '--thinking','bounded','off','--temperature',str(temperature),'--top-p','.95',
              '--top-k',str(top_k),'--min-p','0','--seed','42','--timeout','1200',
              '--output',str(BASE/'context-controls'/(label+'-card-document'))]
        run(label+'-card-document',card)
        if native_running():raise RuntimeError('runtime_did_not_stop')
        (MODELS/FILES[model][0]).unlink()
    if BACKUP.exists():
        state.update(status='restoring_task_toolchain');save()
        subprocess.run(['tar','-I','zstd','-xf',str(BACKUP),'-C','/tmp'],check=True)
    state.update(status='completed');state.pop('active_job',None);save();publish()
except Exception as exc:
    state.update(status='failed',error=str(exc));save();raise
