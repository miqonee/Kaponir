import hashlib,json,subprocess,sys,tempfile,time
from pathlib import Path
from unittest.mock import patch
ROOT=Path('/workspace/Kaponir');sys.path.insert(0,str(ROOT/'scripts'))
from kaponir_worker import Worker,configuration,http_json
from evaluate_validation_schemes import atomic_json

result={'model':'qwen3.5-2b','context_tokens':4096,'threads':2,'max_output_tokens':1,
        'cache_prompt':False,'purpose':'Technical memory stress, not quality scoring','runs':[]}
original_popen=subprocess.Popen
for limit,count in [(8192,8),(0,16)]:
    with tempfile.TemporaryDirectory(prefix='kaponir-cache-control-') as temporary:
        home=Path(temporary)
        worker=Worker(home,configuration(home,{'model_dir':'/tmp/kaponir-three-models',
            'runtime':'/tmp/kaponir-real-eval/models/runtime/llama-b12038/llama-server','threads':2}),'unused')
        run={'cache_ram_mib':limit,'samples':[]};result['runs'].append(run)
        def launch(command,**kwargs):
            command=list(command);command[command.index('--cache-ram')+1]=str(limit)
            run['command']=command
            return original_popen(command,**kwargs)
        try:
            deadline=time.monotonic()+30
            while not worker.status()['models']['qwen3.5-2b']['downloaded']:
                if time.monotonic()>deadline:raise RuntimeError('verification_timeout')
                time.sleep(.1)
            job=worker.submit('evaluate',model='qwen3.5-2b')
            with patch('kaponir_worker.subprocess.Popen',side_effect=launch):
                worker.start_runtime(job['id'],'qwen3.5-2b')
            run['before']=worker.resources()
            for i in range(count):
                payload={'messages':[{'role':'user','content':'Public reference text, control '+str(i)}],
                    'temperature':0,'max_tokens':1,'stream':False,'cache_prompt':False,
                    'chat_template_kwargs':{'enable_thinking':False},
                    'response_format':{'type':'json_schema','json_schema':{'name':'control','strict':True,
                        'schema':{'type':'object','properties':{'ok':{'type':'boolean'}},'required':['ok'],'additionalProperties':False}}}}
                started=time.monotonic()
                reply=http_json(worker.ocr_base+'/v1/chat/completions',payload,timeout=60)
                row={'request':i+1,'seconds':round(time.monotonic()-started,3),
                     'memory':worker.resources(),'usage':reply.get('usage')}
                run['samples'].append(row)
                atomic_json(ROOT/'artifacts/validation-schemes/runtime-cache-diagnostic.json',result)
                print(json.dumps({'cache_ram_mib':limit,'request':i+1,'rss':row['memory']['model_rss_bytes']}),flush=True)
        finally:
            worker.stop.set();worker.stop_runtime()
