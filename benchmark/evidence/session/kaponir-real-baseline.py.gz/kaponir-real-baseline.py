import sys,json,time,subprocess,tempfile,os,socket,urllib.request
from pathlib import Path
root=Path('/workspace/Kaponir');sys.path.insert(0,str(root/'scripts'))
from validate_console import free_port,wait_for
home=Path(tempfile.mkdtemp(prefix='kaponir-baseline-run-'));binary='/tmp/kaponir-baseline-binary'
subprocess.run([binary,'--home',home,'init'],check=True,capture_output=True)
p=home/'config.toml';s=p.read_text();s=s.replace('model_dir = "models"','model_dir = "/tmp/kaponir-real-eval/models"');p.write_text(s)
port=free_port();env={k:v for k,v in os.environ.items() if not k.startswith('KAPONIR_')};env['KAPONIR_MODEL_DIR']='/tmp/kaponir-real-eval/models';env['KAPONIR_WORKER_LISTEN']=f'127.0.0.1:{free_port()}'
log=open('/tmp/kaponir-baseline.log','w');proc=subprocess.Popen([binary,'--home',home,'serve','--listen',f'127.0.0.1:{port}'],env=env,stdout=log,stderr=log)
base=f'http://127.0.0.1:{port}'
def api(path,body=None,method=None):
 r=urllib.request.Request(base+path,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json'},method=method)
 with urllib.request.urlopen(r,timeout=40) as r:return json.load(r)
try:
 wait_for(lambda:api('/api/v1/ui/info'));cfg=api('/api/v1/ui/analysis')['settings'];cfg.update(enabled=True,provider='local',model='qwen3.5-0.8b',auto_apply=False,timeout_seconds=300,parallelism=1)
 cat=api('/api/v1/ui/categorization')['settings'];cat['provider']='none';api('/api/v1/ui/categorization',{'settings':cat},'PUT');api('/api/v1/ui/analysis',{'settings':cfg},'PUT');api('/api/v1/ui/worker/start',{})
 wait_for(lambda:api('/api/v1/ui/worker')['models']['qwen3.5-0.8b']['downloaded'])
 text=(root/'tests/docs/input/01-cost-estimate.md').read_text();start=time.monotonic();api('/api/v1/ui/analysis/documents',{'documents':[{'name':'01-cost-estimate.md','text':text}]})
 data=wait_for(lambda:(d if (d:=api('/api/v1/ui/learning'))['summary']['totals']['processed'] or d['summary']['totals']['failed'] else None),timeout=1500)
 data['elapsed_seconds']=round(time.monotonic()-start,2);Path('/tmp/kaponir-real-baseline.json').write_text(json.dumps(data,ensure_ascii=False,indent=2));print(json.dumps({'elapsed':data['elapsed_seconds'],'entries':len(data['entries']),'summary':data['summary']},ensure_ascii=False))
finally:proc.terminate();proc.wait(timeout=20);log.close()
