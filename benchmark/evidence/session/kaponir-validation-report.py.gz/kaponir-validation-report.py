import collections,hashlib,json,sys
from pathlib import Path
sys.path.insert(0,'/workspace/Kaponir/scripts')
from validation_pipeline import Candidate,combine,score
from check_learning_corpus import load_corpus
root=Path('/workspace/Kaponir');base=root/'artifacts/validation-schemes'
corpus,gold,public,sources,stats=load_corpus()
names=['minicpm-calibration','minicpm-balanced','minicpm-probes','minicpm-probes-single','nanbeige-probes','nanbeige-probes-prompt-batch8-timeout','minicpm-probes-prompt-single','nanbeige-probes-prompt-single','granite-probes-prompt-single','gemma-probes-prompt-single','selected-holdout']
def raw_probes(state):
    responses=list(state['responses'].values())
    if len(responses)%2:return {'unavailable':'unequal_stage_partition'}
    cases=state['probes']['rows'];known={row['id'] for row in cases};mid=len(responses)//2
    maps=[]
    for group in [responses[:mid],responses[mid:]]:
        byid={}
        for response in group:
            reply=response.get('reply',{})
            rows=reply.get('decisions',[]) if isinstance(reply,dict) else []
            for row in rows if isinstance(rows,list) else []:
                if isinstance(row,dict) and row.get('id') in known:
                    id=row['id'];byid[id]=row if id not in byid else None
        maps.append(byid)
    result={}
    for label,byid in zip(['point','audit'],maps):
        result[label]={'action_correct':sum((byid.get(r['id']) or {}).get('verdict')==r['case']['expected_verdict'] for r in cases),
                       'private_kept':sum('expected_kind' in r['case'] and (byid.get(r['id']) or {}).get('verdict')=='keep' for r in cases),
                       'missing_or_unparseable':sum(not byid.get(r['id']) for r in cases)}
    result['double_keep_private']=sum('expected_kind' in r['case'] and all((m.get(r['id']) or {}).get('verdict')=='keep' for m in maps) for r in cases)
    return result

runs={}
for name in names:
 p=base/name/'result.json'
 if not p.exists(): continue
 s=json.loads(p.read_text());signature=s['signature']
 out={'status':s['status'],'result_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
      'model':signature['model'],'artifact':signature['artifact'],'settings':signature['settings'],'structured_output':s.get('structured_output','grammar'),'runtime_json_schema_supported':s.get('runtime_supports_json_schema'),
      'source_sha256':signature['source_sha256'],'prompts':signature['prompts'],
      'metrics':s.get('metrics',{}),'protected_candidates':sum(c['protected'] for c in s['candidate_pool']),'calls':len(s.get('calls',[])),
      'finish_reasons':dict(collections.Counter(c.get('finish_reason',c.get('error','unknown')) for c in s.get('calls',[]))),
      'model_rss_peak_bytes':max((c['memory']['model_rss_bytes'] for c in s.get('calls',[]) if c.get('memory',{}).get('model_rss_bytes') is not None),default=None),
      'inference_errors':dict(collections.Counter(r['error'] for r in s.get('responses',{}).values() if 'error' in r)),
      'resources_before':s.get('resources_before'), 'resources_after':s.get('resources_after'),
      'shadow':s['shadow'],'rules_changed':s['rules_changed']}
 if 'probes' in s:
  out['probes']=s['probes']['summary']
  out['raw_verdict_diagnostics']=raw_probes(s)
 if 'error' in s:out['error']=s['error']
 if 'runtime_exit_code' in s:out['runtime_exit_code']=s['runtime_exit_code']
 if 'cache_origin' in s:out['request_count_note']=s['cache_origin']['note']
 if 'regions' in s:
  out['regions']={'requests':len(s['regions']),'errors':dict(collections.Counter(r['error'] for r in s['regions'] if r['error'])),'invalid_proposals':s.get('region_invalid_proposals',0)}
 runs[name]=out
result={'version':1,'date':'2026-11-13','runtime':'llama.cpp b12038',
        'runtime_sha256':'3e042c4518a74fc3bdb3edb80e07922ee01d6a3455618952af23f3e546508934',
        'corpus_sha256':hashlib.sha256((root/'tests/docs/expected.json').read_bytes()).hexdigest(),
        'annotations_sha256':hashlib.sha256((root/'tests/docs/expected.json').read_bytes()).hexdigest(),
        'probe_sha256':hashlib.sha256((root/'tests/fixtures/validation-review-heldout.json').read_bytes()).hexdigest(),
        'code_sha256':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ['scripts/evaluate_validation_schemes.py','scripts/validation_pipeline.py','scripts/kaponir_worker.py','crates/kaponir-cli/examples/detector_candidates.rs']},
        'gold_values':len(gold),'probe_cases':20,'probe_private':9,'probe_public':9,'probe_ambiguous':2,
        'selection_policy':'Compare completed batch1/prompt runs, including the MiniCPM control. Exclude runs with no valid decisions. Minimize private KEEP errors, then maximize correct actions and jointly correct kind/scope; also inspect double-check behavior. Equal quality prefers the smaller artifact. Verify the chosen point validator on documents 03–07.',
        'checks':{'rust_workspace':190,'rust_exporter':1,'python':83,'clippy_all_targets':True,'review_browser':True,'models_browser':True},
        'limitations':['Synthetic corpus; unique values per document, not per occurrence.','Raw detector scope personal is a placeholder, not measured scope accuracy.','Outside-gold values include span-boundary errors; they are not all independently established false positives.','No cold-run speed comparison: calibration reused exact-request checkpoints and overlapped build/check activity.','No permanent rules or user vault decisions were changed by the experiments.'],
        'runs':runs}
(root/'docs/VALIDATION_RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print({n:r['status'] for n,r in runs.items()})
