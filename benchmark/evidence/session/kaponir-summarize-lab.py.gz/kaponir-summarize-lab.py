import collections,copy,json,sys
from pathlib import Path
root=Path('/workspace/Kaponir');sys.path.insert(0,str(root/'scripts'))
from compare_local_models import score_application_review
manifest=json.loads((root/'tests/docs/expected.json').read_text());gold={d['file']:{x['value'] for x in d['sensitive']} for d in manifest['documents']}
cases={c['id']:c for c in json.loads((root/'tests/fixtures/local-model-review.json').read_text())}
sources=[
 ('huihui_auto_typed','huihui-auto-grounded','grounded_model_proposals'),
 ('huihui_original_prompt_without_kind','huihui-independent-review','review_only'),
 ('qwen_context_diagnostic','qwen2-fixed-diagnostic','grounded_model_proposals_partial'),
 ('qwen_focused_values','qwen2-focused-lean','grounded_model_proposals'),
 ('minicpm_focused_values','minicpm-focused-lean','grounded_model_proposals'),
 ('external_schema_before_exhaustive','external-explicit-schema-lean','grounded_model_proposals'),
 ('external_exhaustive_whole','external-exhaustive-whole','grounded_model_proposals'),
 ('external_exhaustive_focused','external-exhaustive-focused','grounded_model_proposals'),
 ('external_application_full','external-application-full-resumed','application_entries'),
]
report={'date':'2026-11-12','corpus_sha256':'1815af85ae5198240fac4d9aaff659d33e35779f5bc1ae621699afafc370ce92',
 'corpus_documents':8,'corpus_unique_values':219,'runtime':'llama.cpp b12038','runtime_executable_sha256':'3e042c4518a74fc3bdb3edb80e07922ee01d6a3455618952af23f3e546508934',
 'scope_policy':'Closed commercial money is global; historical answers rescored against the canonical fixture.',
 'timing_limitation':'Local CPU quota is two cores; some runs overlapped builds/browser verification. No speed ranking is inferred.',
 'runs':{}}
for key,directory,layer in sources:
 path=root/'artifacts/inference-lab'/directory/'result.json'
 if not path.exists():continue
 d=json.loads(path.read_text());r={'artifact':str(path.relative_to(root)),'layer':layer,'status':d['status'],'settings':d.get('settings',d.get('profile',{}))}
 if isinstance(d.get('documents'),dict):
  r['documents']={name:{'matched':x['matched'],'expected':x['expected'],'proposed':len({v['value'] for v in x['values']}),
    'outside_expected':len(x['unmatched']),'errors':len(x['errors']),'calls':x['calls'],'planned_fragments':x['fragments']} for name,x in d['documents'].items()}
 else:
  entries=d.get('entries',[]);jobs=d.get('jobs',[])
  r['documents']={name:{'matched':len((found:={e['value'] for e in entries if e['source']==name})&gold[name]),'expected':len(gold[name]),'proposed':len(found),
   'outside_expected':len(found-gold[name]),'errors':sum(j['state']=='failed' for j in jobs if j['name']==name)} for name in d.get('documents',[]) if name in gold}
  r['resumed_after_environment_restart']=d.get('resumed',False);r['retry_rounds']=d.get('retry_rounds',0);r['initial_failures']=d.get('initial_failures',{})
 if r['documents']:
  r['discovery']={k:sum(x[k] for x in r['documents'].values()) for k in ['matched','expected','proposed','outside_expected','errors']}
  r['discovery']['public_document_findings']=r['documents'].get('08-public-reference.md',{}).get('proposed',0)
 reviews=copy.deepcopy(d.get('reviews',d.get('review_cases',[])))
 if reviews:
  rs={'cases':len(reviews),'valid':0,'action_correct':0,'kind_correct':0,'scope_correct':0,'private_cases':5,
      'ids':'opaque' if d.get('settings',{}).get('opaque_review_ids') else 'semantic_calibration'}
  for row in reviews:
   c=cases[row['case']['id']];a=row.get('answer',{});valid=row['valid'];row['case']=c
   rs['valid']+=valid;rs['action_correct']+=valid and a.get('action')==c['expected_action']
   rs['kind_correct']+=valid and 'expected_kind' in c and a.get('kind')==c['expected_kind']
   rs['scope_correct']+=valid and 'expected_scope' in c and a.get('scope')==c['expected_scope']
  rs.update(score_application_review(reviews));r['review']=rs
 calls=d.get('calls',[]);r['recorded_calls']=len(calls)
 r['finish_reasons']=dict(collections.Counter(c.get('finish_reason','no_response') for c in calls))
 r['http_errors']=dict(collections.Counter(str(c['http_status']) for c in calls if c.get('http_status',0)>=400))
 r['max_observed_model_rss_bytes']=max((c.get('memory',{}).get('model_rss_bytes',0) or 0 for c in calls),default=0)
 report['runs'][key]=r
(root/'docs/INFERENCE_RESULTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
for key,r in report['runs'].items():print(key,r['status'],r.get('discovery'),r.get('review'))
