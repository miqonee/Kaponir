"""Resume only the authorised synthetic benchmark queue after a session stops."""
from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

ROOT=Path('/workspace/Kaponir')
BASE=ROOT/'artifacts/validation-schemes'
QUEUE=BASE/'heavy-benchmark-queue.json'
RUNNER='/tmp/kaponir-finish-heavy-benchmarks.py'
STOP=Path('/tmp/kaponir-benchmark-supervisor.stop')
PIDFILE=Path('/tmp/kaponir-benchmark-supervisor.pid')

def log(event,**fields):
    print(json.dumps({'utc':datetime.now(timezone.utc).isoformat(),'event':event,**fields}),flush=True)

def active_processes():
    active=[]
    for proc in Path('/proc').glob('[0-9]*'):
        try:args=[v.decode() for v in (proc/'cmdline').read_bytes().split(b'\0') if v]
        except (OSError,UnicodeError):continue
        if not args:continue
        runner=len(args)>1 and args[1]==RUNNER
        model=args[0].endswith('/llama-server') and any('/tmp/kaponir-three-models/' in v for v in args)
        experiment=(len(args)>1 and Path(args[1]).name in
            ['evaluate_validation_schemes.py','evaluate_context_controls.py'] and
            '/tmp/kaponir-three-models' in args)
        if runner or model or experiment:active.append(int(proc.name))
    return sorted(active)

def annotate_resume(queue):
    label=queue.get('active_job','')
    if not re.fullmatch(r'[a-z0-9_-]{1,80}',label):return
    for path in [BASE/label/'result.json',BASE/'context-controls'/label/'result.json']:
        if not path.is_file():continue
        state=json.loads(path.read_text())
        if state.get('status')=='completed':return
        state.setdefault('runtime_restarts',[]).append({
            'cause':'session_runner_stopped_supervisor_resume',
            'utc':datetime.now(timezone.utc).isoformat(),
            'saved_technical_calls':len(state.get('calls',[]))})
        temporary=path.with_suffix('.tmp')
        temporary.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n');temporary.replace(path)
        return

def main():
    with PIDFILE.open('a+') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:log('already_running');return
        lock.seek(0);lock.truncate();lock.write(str(os.getpid()));lock.flush()
        previous=None
        while not STOP.exists():
            if not QUEUE.exists():log('queue_missing');return
            queue=json.loads(QUEUE.read_text())
            if queue['status'] in ['completed','failed','cancelled','interrupted_by_user']:
                log('queue_terminal',status=queue['status']);return
            active=active_processes()
            if active:
                if active!=previous:log('waiting_for_active_runner',pids=active)
                previous=active;time.sleep(5);continue
            annotate_resume(queue);log('resuming_queue',job=queue.get('active_job'))
            with Path('/tmp/kaponir-heavy-benchmark-queue.log').open('a') as output:
                child=subprocess.Popen([sys.executable,RUNNER],cwd=ROOT,stdout=output,
                    stderr=subprocess.STDOUT,start_new_session=True)
                while child.poll() is None:
                    if STOP.exists():
                        log('stopping_owned_runner',pid=child.pid)
                        os.killpg(child.pid,signal.SIGTERM)
                        try:child.wait(timeout=15)
                        except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
                        return
                    time.sleep(5)
                log('runner_finished',returncode=child.returncode)
            previous=None
        log('stop_requested')

if __name__=='__main__':main()
