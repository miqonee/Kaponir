import json,os,subprocess,sys,tempfile,time
from pathlib import Path
sys.path.insert(0,'/workspace/Kaponir/scripts')
from kaponir_worker import Worker,configuration
root=Path('/workspace/Kaponir');os.chdir(root)
lab=root/'artifacts/inference-lab';models=Path('/tmp/kaponir-three-models');runtime=Path('/tmp/kaponir-real-eval/models/runtime/llama-b12038/llama-server')
while json.loads((lab/'huihui-auto-grounded/result.json').read_text())['status']=='running':
 try:os.kill(48557,0)
 except ProcessLookupError:raise RuntimeError('Huihui run stopped unexpectedly')
 time.sleep(1)
def run(model,name,extra):
 args=[sys.executable,'scripts/experiment_inference.py','--model',model,'--model-dir',str(models),'--runtime',str(runtime),'--output',str(lab/name),*extra]
 print('START',name,flush=True);subprocess.run(args,check=True);print('FINISH',name,flush=True)
run('huihui-qwen3.5-2b-abliterated','huihui-independent-review',['--review-only','--blind-review'])
(models/'Huihui-Qwen3.5-2B-abliterated.Q4_K_M.gguf').unlink()
run('qwen3.5-2b','qwen2-fixed-diagnostic',['--strategy','fixed','--documents','02-application.log','--skip-review'])
profile=['--strategy','auto','--candidate-mode','lean','--target-input-tokens','1024','--hint-tokens','256','--blind-review']
run('qwen3.5-2b','qwen2-focused-lean',profile)
(models/'Qwen3.5-2B-Q4_K_M.gguf').unlink()
with tempfile.TemporaryDirectory(prefix='kaponir-mini-download-') as t:
 h=Path(t);w=Worker(h,configuration(h,{'model_dir':str(models),'runtime':str(runtime)}),'unused');j=w.submit('download',model='minicpm5-2b');w.install(j['id'],'minicpm5-2b');w.stop.set()
run('minicpm5-2b','minicpm-focused-lean',profile)
