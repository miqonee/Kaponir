"""Capture the completed benchmark session; never run inference or change its results."""
import csv
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
from datetime import datetime, timezone

ROOT=Path('/workspace/Kaponir')
OUT=ROOT/'benchmark'
REV='627f58d015f3f7c2ee4a242b9c05b89e4e91cc6c'
OUT.mkdir(exist_ok=True)
records=[];aliases=[];excluded=[];decoded_dest={}

def sha(data):return hashlib.sha256(data).hexdigest()
def json_bytes(value):return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()

# This file is used only as a denylist for removing operational credentials.
# Its contents are never copied, logged, or placed in a manifest.
known=[]
key_file=Path('/tmp/kaponir-eval-api-key')
if key_file.is_file():
    value=key_file.read_bytes().strip()
    if len(value)>=20:known.append(value)
fixture_bytes=(ROOT/'tests/docs/expected.json').read_bytes()
provider_pattern=re.compile(rb'sk-[A-Za-z0-9_-]{24,}')
def scrub(data):
    changes=0
    for value in known:
        changes+=data.count(value);data=data.replace(value,b'[REDACTED_PROVIDER_KEY]')
    def replace(match):
        nonlocal changes
        value=match.group()
        if value in fixture_bytes or any(marker in value.lower() for marker in
                [b'test',b'fixture',b'synthetic',b'example',b'dummy',b'must-not-leak']):return value
        changes+=1;return b'[REDACTED_PROVIDER_KEY]'
    data=provider_pattern.sub(replace,data)
    return data,changes

def store(source, destination, category, compress=False, pristine=False):
    path=Path(source);raw=path.read_bytes()
    if pristine:
        cleaned,count=scrub(raw)
        if count:raise RuntimeError('operational_credential_in_pristine_source:'+str(path))
    elif path.suffix in ['.png','.svg']:
        cleaned,count=raw,0
    else:cleaned,count=scrub(raw)
    payload=gzip.compress(cleaned,mtime=0) if compress else cleaned
    target=OUT/destination;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(payload)
    status=None;keys=[]
    if path.suffix=='.json':
        try:
            state=json.loads(cleaned)
            if isinstance(state,dict):
                status=state.get('status')
                if status is None and isinstance(state.get('passed'),bool):status='passed' if state['passed'] else 'failed'
                keys=list(state)
        except (ValueError,UnicodeError):pass
    row={'path':destination,'category':category,'source':str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path),
         'source_sha256':sha(raw),'sha256':sha(payload),'bytes':len(payload),'encoding':'gzip' if compress else 'original',
         'content_sha256':sha(cleaned),'content_bytes':len(cleaned),'redactions':count,'status':status}
    records.append(row)
    decoded_dest.setdefault(sha(cleaned),destination)
    return row

# Preserve the already published evidence byte-for-byte.
frozen=json.loads((ROOT/'docs/benchmarks/manifest.json').read_text())
for relative,row in frozen['files'].items():
    source=ROOT/'docs/benchmarks'/row['archive'];compressed=source.read_bytes();raw=gzip.decompress(compressed)
    assert sha(compressed)==row['archive_sha256'] and sha(raw)==row['json_sha256']
    assert not scrub(raw)[1],relative
    saved=store(source,'data/validation/'+row['archive'],'published_validation',pristine=True)
    saved.update(encoding='gzip',content_sha256=sha(raw),content_bytes=len(raw),status=row['status'])
    decoded_dest[sha(raw)]='data/validation/'+row['archive']
store(ROOT/'docs/benchmarks/manifest.json','data/validation/manifest.json','published_manifest',pristine=True)
for original,target in [('docs/VALIDATION_RESULTS.json','data/validation-results.json'),
                        ('docs/INFERENCE_RESULTS.json','data/inference-results.json')]:
    store(ROOT/original,target,'published_summary',pristine=True)

# Capture every available artifact JSON, log and screenshot. Binaries are rebuildable.
for path in sorted((ROOT/'artifacts').rglob('*')):
    if not path.is_file():continue
    source=path.relative_to(ROOT).as_posix()
    if path.suffix not in ['.json','.log','.png','.md','.txt','.svg']:
        excluded.append({'source':source,'bytes':path.stat().st_size,'reason':'compiled_binary_or_non_evidence_file; frozen outputs and binary SHA are retained'})
        continue
    raw=path.read_bytes()
    if sha(raw) in decoded_dest:
        aliases.append({'source':source,'path':decoded_dest[sha(raw)],'source_sha256':sha(raw),'reason':'identical content already preserved'})
        continue
    destination='evidence/'+source+('' if path.suffix in ['.png','.svg'] else '.gz')
    store(path,destination,'historical_ui' if path.suffix in ['.png','.svg'] or '/browser-' in source or '-ui/' in source else 'workspace_artifact',
          compress=path.suffix not in ['.png','.svg'])

# Keep text evidence and operational scripts as historical references, not live jobs.
text_suffixes={'.json','.py','.md','.log','.cpp','.h','.tsv','.txt','.svg','.png','.sh'}
for path in sorted(Path('/tmp').glob('kaponir-*')):
    if not path.is_file():continue
    if path.suffix not in text_suffixes:
        reason=('credential_file_omitted' if 'key' in path.name or 'token' in path.name else
                'database_or_sidecar_omitted' if '.db' in path.name else
                'environment_binary_backup_or_process_marker_omitted')
        excluded.append({'source':str(path),'bytes':path.stat().st_size,'reason':reason})
        continue
    image=path.suffix in ['.png','.svg']
    store(path,'evidence/session/'+path.name+('' if image else '.gz'),'session_reference_only',compress=not image)

for path in sorted((ROOT/'tests/docs').rglob('*')):
    if path.is_file():
        target='data/corpus/'+path.relative_to(ROOT/'tests/docs').as_posix()
        if path.name=='README.md':
            (OUT/target).unlink(missing_ok=True)
            store(path,target+'.gz','synthetic_corpus',compress=True,pristine=True)
        else:store(path,target,'synthetic_corpus',pristine=True)
for name in ['context-control-candidates.json','validation-review-heldout.json','local-model-review.json','validation-models.json']:
    store(ROOT/'tests/fixtures'/name,'data/fixtures/'+name,'synthetic_fixture',pristine=True)
for name in ['LOCAL_MODEL_FINDINGS.md','SCHEME_COMPARISON.md','VALIDATION_TABLES.md','VALIDATION_EXPERIMENTS.md',
             'INFERENCE_EXPERIMENTS.md','MODEL_COMPARISON.md','REVIEW_QUALITY.md','WORK_LOG.md','WORKER.md',
             'DISCOVERY.md','LEARNING.md','S1.md','CONTROL_PANEL.md','ROADMAP.md']:
    store(ROOT/'docs'/name,'reference/'+name+'.gz','verbatim_source_document',compress=True,pristine=True)
store(ROOT/'docs/assets/validation-memory.svg','evidence/figures/validation-memory.svg','runtime_memory_figure',pristine=True)

# Audit reachable Git blobs before creating an offline history bundle.
objects=subprocess.check_output(['git','rev-list','--objects',REV],cwd=ROOT,text=True).splitlines()
paths={line.split(' ',1)[0]:line.split(' ',1)[1] if ' ' in line else '(tree)' for line in objects}
proc=subprocess.Popen(['git','cat-file','--batch'],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
try:
    for oid,name in paths.items():
        proc.stdin.write((oid+'\n').encode());proc.stdin.flush()
        header=proc.stdout.readline().split();size=int(header[2]);raw=proc.stdout.read(size);assert proc.stdout.read(1)==b'\n'
        if header[1]!=b'blob':continue
        if raw.startswith(b'\x1f\x8b'):
            try:raw=gzip.decompress(raw)
            except (OSError,EOFError):pass
        if scrub(raw)[1]:raise RuntimeError('operational_credential_in_git_history:'+name)
finally:
    proc.stdin.close();proc.wait()
bundle=OUT/'evidence/source/repository.bundle';bundle.parent.mkdir(parents=True,exist_ok=True)
assert subprocess.check_output(['git','rev-parse','refs/heads/main'],cwd=ROOT,text=True).strip()==REV
subprocess.run(['git','bundle','create',str(bundle),'refs/heads/main'],cwd=ROOT,check=True)
subprocess.run(['git','bundle','verify',str(bundle)],cwd=ROOT,check=True,stdout=subprocess.DEVNULL)
raw=bundle.read_bytes();records.append({'path':bundle.relative_to(OUT).as_posix(),'category':'offline_git_history',
    'source':'git:refs/heads/main@'+REV,'sha256':sha(raw),'bytes':len(raw),'encoding':'git bundle','redactions':0,'status':'verified'})

history=subprocess.check_output(['git','log',REV,'--format=%H%x1f%aI%x1f%s%x1e'],cwd=ROOT,text=True)
commits=[]
for entry in history.split('\x1e'):
    if not entry.strip():continue
    commit,date,subject=entry.strip().split('\x1f',2);commits.append({'commit':commit,'date':date,'subject':subject})
(OUT/'data/git-history.json').write_bytes(json_bytes({'head':REV,'commits':commits}))

catalog={'version':1,'captured_utc':datetime.now(timezone.utc).isoformat(),'source_revision':REV,
    'published_archives':len(frozen['files']),'files':records,'aliases':aliases,'omissions':excluded,
    'important':'Historical running/aborted/failed files are preserved as evidence, not as pending jobs or completed quality results. Read STATE.json and AGENT_HANDOFF.md first.'}
(OUT/'data/COLLECTION.json').write_bytes(json_bytes(catalog))
rows=[]
for row in records:
    if row['status'] is not None or row['source'].endswith('/result.json'):
        rows.append([row['source'],row['path'],row['category'],row['status'] or 'not_recorded',row.get('content_sha256',row['sha256']),row['redactions']])
for row in aliases:
    if row['source'].endswith('/result.json'):rows.append([row['source'],row['path'],'alias_of_published_evidence','see archived status',row['source_sha256'],0])
with (OUT/'data/experiment-index.csv').open('w',newline='') as output:
    writer=csv.writer(output);writer.writerow(['original_source','packaged_path','category','recorded_status','content_sha256','redactions']);writer.writerows(rows)
print(json.dumps({'published_archives':len(frozen['files']),'copied_files':len(records),'deduplicated_aliases':len(aliases),
    'explicit_omissions':len(excluded),'redacted_files':sum(bool(row['redactions']) for row in records),
    'bytes':sum(row['bytes'] for row in records),'git_commits':len(commits)}))
