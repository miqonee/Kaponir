import json,subprocess,sys,time
from pathlib import Path
root=Path('/workspace/Kaponir');base=root/'artifacts/validation-schemes'
while True:
 p=base/'nanbeige-probes/result.json'
 if p.exists():
  state=json.loads(p.read_text())
  if state['status']=='completed':break
  if state['status']=='failed':raise RuntimeError('nanbeige_probe_failed_needs_diagnosis')
 log=Path('/tmp/kaponir-validation-next.log').read_text()
 if 'Traceback' in log and 'START nanbeige-probes' not in log:raise RuntimeError('earlier_probe_failed')
 time.sleep(5)
time.sleep(5)
common=[sys.executable,'scripts/evaluate_validation_schemes.py','--model-dir','/tmp/kaponir-three-models','--runtime','/tmp/kaponir-real-eval/models/runtime/llama-b12038/llama-server','--detectors',str(base/'detector_candidates'),'--probes-only','--context-policy','balanced']
name='minicpm-probes-single'; print('START',name,flush=True)
with open('/tmp/kaponir-validation-'+name+'.log','w') as log:
 subprocess.run(common+['--model','minicpm5-2b','--batch-size','1','--output',str(base/name)],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
print('DONE',name,flush=True)
Path('/tmp/kaponir-three-models/MiniCPM5-2B-Q4_K_M.gguf').unlink()
Path('/tmp/kaponir-three-models'/Path(state['signature']['artifact'][0])).unlink()
model=json.loads((root/'tests/fixtures/validation-models.json').read_text())['models'][2]
name='granite-probes';print('START',name,flush=True)
with open('/tmp/kaponir-validation-'+name+'.log','w') as log:
 subprocess.run(common+['--model',model['id'],'--hf-url',model['url'],'--output',str(base/name)],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
print('DONE',name,flush=True)
