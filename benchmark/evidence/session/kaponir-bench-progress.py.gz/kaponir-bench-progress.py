"""Read-only progress for the frozen, sequential benchmark queues."""
from datetime import datetime,timezone
import json
from pathlib import Path
import os

base=Path('/workspace/Kaponir/artifacts/validation-schemes')
out={'utc':datetime.now(timezone.utc).strftime('%H:%M:%S'),'queues':[]}
processes={}
for proc in Path('/proc').glob('[0-9]*'):
    try:
        args=(proc/'cmdline').read_bytes().split(b'\0')
        if not args:continue
        if args[0].endswith(b'llama-server'):
            stats=(proc/'stat').read_text().split()
            status=dict(line.split(':',1) for line in (proc/'status').read_text().splitlines() if ':' in line)
            processes['native']={'pid':int(proc.name),'rss_mib':round(int(status['VmRSS'].split()[0])/1024,1),
                'cpu_seconds':round((int(stats[13])+int(stats[14]))/os.sysconf('SC_CLK_TCK'),1)}
        for label in ['light','heavy']:
            script=f'/tmp/kaponir-finish-{label}-'+('controls.py' if label=='light' else 'benchmarks.py')
            if script.encode() in args:processes[label]=int(proc.name)
    except (OSError,ValueError,KeyError):continue
out['processes']=processes
for name in ['light-control','heavy-benchmark']:
    path=base/(name+'-queue.json')
    if not path.exists():continue
    queue=json.loads(path.read_text())
    row={'queue':name,'status':queue['status']}
    if 'error' in queue:row['error']=queue['error']
    label=queue.get('active_job')
    if label:
        row['active']=label
        if queue['status']=='installing_model':
            import sys
            sys.path.insert(0,str(base.parents[1]/'scripts'))
            from kaponir_worker import FILES
            if label in FILES:
                artifact=FILES[label]
                target=Path('/tmp/kaponir-three-models')/artifact[0]
                partial=target.with_suffix(target.suffix+'.part')
                size=partial.stat().st_size if partial.exists() else target.stat().st_size if target.exists() else 0
                row.update(download_mib=round(size/2**20,1),total_mib=round(artifact[1]/2**20,1))
        for candidate in [base/label/'result.json',base/'context-controls'/label/'result.json']:
            if not candidate.exists():continue
            state=json.loads(candidate.read_text())
            row.update(run_status=state['status'],calls=len(state.get('calls',[])))
            if state.get('discovery_checkpoint_policy'):
                progress=state.get('discovery_progress',{}).values()
                row['cached_search_responses']=sum(len(p.get('responses',{})) for p in progress)
                row['replayed_search_responses']=sum(p.get('cache_hits',0) for p in progress)
                row['legacy_calls_before_search_cache']=state.get('discovery_checkpoint_initial_calls',0)
                row['completed_search_documents']={key.split(':',1)[1]:{
                    'values':len(value.get('values',[])),'errors':len(value.get('errors',[]))}
                    for key,value in state.get('stages',{}).items() if key.startswith('discovery:')}
            if state.get('calls'):
                last=state['calls'][-1]
                row['last_call']={key:last[key] for key in ['stage','finish_reason','error','seconds',
                    'max_output_tokens','final_text_chars','reasoning_text_tokens'] if key in last}
            if state.get('metrics'):
                method=next(reversed(state['metrics']))
                metric=state['metrics'][method]
                if method.startswith('review'):
                    row['last_completed_method']={
                        'name':method,'private_mask':metric['confirmed_matches'],
                        'public_keep':metric['outside_values_filtered'],
                        'wrong_private_keep':metric['correct_values_filtered'],
                        'wrong_public_mask':metric['confirmed_outside'],'review':metric['needs_review_values']}
                else:
                    row['last_completed_method']={'name':method,**{key:metric[key] for key in
                        ['visible_matches','visible_outside','quality_is_lower_bound_if_incomplete','complete_documents'] if key in metric}}
            break
    out['queues'].append(row)
print(json.dumps(out,ensure_ascii=False))
