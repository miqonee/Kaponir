# NEWEST ADDENDUM: Huihui47calls, point+regions done; plotting/report enhancements

Huihui sameprofile measurements NOW: current_union142proposals76true66outside; point68truepool→27true15outside,41truewronglyfiltered,32review. regions70proposals47true23outside,correctkind33/scope16(allinclude7protected). union_point/doublepending. Stillmainrunner68005/PID73172,holdoutqueue7279correct. Monitoringcells295/298/301allFINISHED;notactive. LatestHui47calls;cachefixed0RSS~2GiB. NootherLLMrunning.

All3regionsquality excluding7protectedgold:
Mini10goldfound/9rightkind/8rightscope/7joint;
Qwen63/9/25/8;
Hui40/26/9/5. Thisistype/scopeonexactgoldfound,notfull92datasetaccuracy. Miniomitsallmoneyherebutbetterlabelingsmallset;can'tchooseoverallwinnerbycoveragealone.

Summaryscript now adds validation_quality forpoint/regions/union_point/double excludingprotected;also rss_by_request_bytes. summarize()nowvalidatesactualcurrentsource/annotationSHAs,inadditiontocrossmodelprofile/runtime/prompt/exporters. Added2morereportregressionsforbadprobeanswersandstaleannotations;script/test_scheme_matrix.py now7testsPASS. FullPythontotalnow93EXPECTED;latestfullsuitewas91beforelast2,rerunfinalonce(noinferencechanges). Rust190/clippy/UIallstillvalid.

Newoptional scripts/plot_validation_memory.py (matplotlibonly,notproductiondependency) readsdocs/VALIDATION_RESULTS.json andrendersdocs/assets/validation-memory.svg (COMMITTHISnewSVG). Renderedandvisuallyinspectedvia/tmp/kaponir-validation-memory.png:clean2panelsQwen81callRSSrises2→7.7anddrops2after67;controlledRAMcache8MiB? **8192MiB** case8calls rises272MiBvs0case16flat0.5MiB. DefaultenvreadonlyMPLconfigwarnedbutgeneratedfine;futurecommand envMPLCONFIGDIR=/tmp/kaponir-validation-mpl python scripts/plot_validation_memory.py. docsSCHEME_COMPARISON embedsSVG+optionalreproducecommand.

docsSCHEME_COMPARISONcurrenttableHuiunion76/66,point27/15,regions47/23,restpending;Qwen/Mini complete. Addedregionqualitytableaboveandclarifiedcandidate-onlyconfirmedfieldsarenotprivacyvalidation;raw/current_unionscopeplaceholder. NeedfinalHuitwomethods+holdout+bestmethodsconclusions,statusrewrite,reportregenerate+finalpush. Reportpublicv2nooldselectionpolicy. NEWMETADATAeditsdoNOTchangeinferencepromptsorbudgets;Huiinmemoryoldharnessstilltreatsmodelrequestsconsistently.

Latestnaturalcommentaryexplained7/10vs8/63vs5/40jointtypescopedifferencetoavoidmisleadingcoverage. Originaluserlatestquestionclarity+Qwenallmethodsremainsprimarygoal;don'tdiverttoextraGemmauntiloriginalcohort+holdoutdone. Product4c1b178alreadyPUSHED.

# LATEST: Qwen complete, Huihui running, product FIX PUSHED

**PUSHED main4c1b178** tohttps://github.com/miqonee/Kaponir (successfulsession35690).19productfiles:runtimecachefix,JSONfallback/profile/telemetry,3additionalcatalogpresets,reviewabstentionstate/UI/opaqueIDs/tests/docs. Experiments+reportremainuncommitted. Rust190passedagainaftercachefix;clippyagainPASS;latestCLIrebuiltwithnewworker;Pythonnow**91passed** (2newreporttests),logs finalpathsunchanged. UI priorPASS unchangedUIsince.

**QWEN COMPLETED81requests** same92gold. double **80true retained,42outside,0truefiltered,9outsidefiltered,112review,7trueconfirmed(allprotected),3outsideconfirmed(protected)**. Hugeimprovementinretentionvsunion_point23true57filtered, BUTthisisguard/manualreviewnotcorrectclassifier.
Audit independentderivedmetrics:80truevisible41outside,22trueconfirmed27outsideconfirmed,0truefiltered10outsidefiltered,72review,correctkind7/correctscope12. ALL51goldmoney auditresponsesinvalid:rawMNAMEfor5andSVCfor46,soformatguardsretainreview. Primarymoneyall51validKEEP(kindAMOUNT;39personal12team). Rawlatestresponses examplesaudit:1320₽ mask,SVC,reasonpriceofspecificservice;3292699.92₽mask,SVC;48600₽keep,MNAME,reasonnotpersonalidentifier. Exactuser'sSVC-moneyerrorreproduced2B. Don'tclaimdoubleautomaticallysolvedclassificationorprovensafe; some rawwrongKEEPshiddenbyguards. Citableexampledatafictional.

Mainmatrixrunner session68005/PID73172 stillactive **HUIHUI NOWRUNNING**, output.../huihui-calibration/result.json;Qwenstopruntimefreedcorrectly. LatestHui3calls discovery. Queueholdout session7279 stillwaitingparent73172;selectscurrent_uniongeneratorbyhighestcoverage,tiefeweroutside/smallerfile;notbestautomaticvalidator. Stillfine:Qwendouble0goldfilterbut112reviewtypebadnoautowinner. Couldreportbestfinderandbestconservativeverifierseparately;don'tforceunifiedwinner. Holdout1275docsvalidatesthebestadditivefinderonly,notallmethods.

**Newpublicscript** scripts/report_validation_results.py generatesdocs/VALIDATION_RESULTS.json **version2**, nowseparatesprimary_matrix fromdiagnostic_runs,selected_holdout,cachecontrols/replays. Replacesoldtemp generator/oldmisleadingselectionpolicy. `python3 scripts/report_validation_results.py` afterfinal. Missingmodels/statusnotrunexplicit.2newtestsinscripts/test_scheme_matrix.py(total5infile,91Pythonoverall) ensuremissingmodelsnotzerosand20caseprobesoutsideprimarymatrix. BothsummaryandreportreadsingleatomicsnapshotbeforeSHAtoavoidrace.

docsSCHEME_COMPARISON nowcontains3doccounts67/25/0,51moneyimbalance,tableMini+Qwenincludingdouble80/42,Hui running/pending,cachediagnosisexceptionandexact2replays,selectedSVC/MNAMEexamples. MustreplacependingwithHuiresults+holdout+finalbestmethodconclusionbeforefinalcommit/push. docsVALIDATION_EXPERIMENTS candidate-onlyrowsnowdashforreview/filterinsteadofmisleadingzeros;needsreviewcolumnincludesoutsides.

Noaddmodelrunnings. StrongerGemma nottested;Nano/Granite20casesseparateasbefore. Userpriorityfinishoriginal3first. CoulddoGemmaafteroriginal+holdoutifcompletingearlierbroadplan;don'tdelaycohortforit. Don'tclaimGemmaqualityfromcatalog. Noexternalproviderthisturn.

/tmp/kaponir-count-pending.py canattachcurrentloadednativeTokenizernoinferenceandcountauditcachekeys;`python ... huihui-calibration` onlyaftercurrent_unionexists. LastusedQwenremaining3→completed. Tokenizerclassmethodsread-only,socketneedsescalation.

Usercommentarylatest:twoSVC/MNAMEexamplesexplainsthatdouble0filterreflectsguards/manualreview;notallcorrect. Priormessageproductpushlinked4c1b178. Keepupdates~60s;explicitavoidrankallmodelsfrommicrotests.

# UPDATE: cache root cause and resumed jobs (supersedes older running IDs)

Original session85123 / PID71294 was deliberately SIGINT-stopped at Qwen67 completed requests (checkpoint retained) after serious memory growth. **Root cause proved**: llama.cpp b12038's separate RAM prompt-state archive defaults8192MiB and still saves prompts despite request cache_prompt=false. Source retrieved /tmp/kaponir-llama-server-context.cpp: get_available_slot around1880 only excludes embedding/rerank stateless, not cache_prompt false; default --cache-ram8192, --cache-idle-slots enabled. QwenRSS grew1.999GiB(call1)→7.75GiB(call67), roughly100MiB/request; requests66/67 slowed to259.7/236.7sec from~50; memory.events oom0/oom_kill0, but massive reclaim (max3.5million events). This is actual technical cause candidate for historical obryvs, not proven historicOOM.

**FIX IMPLEMENTED** universally in Worker.start_runtime: --cache-ram0 --no-cache-idle-slots (all models, consistent with independent requests, no smaller token/context limits). New regression test test_independent_requests_do_not_accumulate_server_prompt_states; Python **89passed** /tmp/kaponir-validation-python-final.log. docsWORKER updated memory explanation, removed inference that Nanbeige inherentlyrequires4+GB (that diagnostic predated cachefix).

Controlled native stress complete (/tmp/kaponir-cache-diagnostic.py, artifacts/validation-schemes/runtime-cache-diagnostic.json, log/tmp/kaponir-cache-diagnostic.log): same Qwen4096ctxCPU2, maxoutput1, unique publictoy strings/cache_prompt false. cache_ram8192:RSS2079416320→2364280832 over8requests (+272MiB); cache_ram0:2038710272→2039222272 over16 (+0.49MiB). Not modelqualitytest. Both keep no-cache-idle-slots, so RAMcache isolatescause.

Exact replay complete (/tmp/kaponir-cache-replay.py, artifacts/.../runtime-cache-replay.json): two EXACT original Qwenpointbatches (request keys624720... and219e86...) withcacheRAM0 fullymatch oldreplysha; RSS~2GiB, no semanticchange on2controls. Existingrecords have cached_tokens0. Do NOT pretend ALL3ran samecacheflags; docsSCHEME_COMPARISON explicitly records exception: Mini/all earlyQwen useddefault8GiBarchive, Qwen after67 andHui usefix0. Weights/prompts/input/outputbudgets unchanged, no promptreuseallcalls, no latency/rankingfromthese runs.

**NOW RUNNING** resumed matrix execsession**68005**, parentPID**73172**, log/tmp/kaponir-original-matrix-resumed.log. Qwenresumes67exact replies thenfinishesaudit; Hui automaticallynext. Qwen at69calls newestcheck,RSS1.97GiB, stillrunning. Oldmatrixlog has tracebackdeliberateSIGINT notunexpectedfailure. Noothermodelrun.

**QUEUED holdout** execsession**7279**, /tmp/kaponir-holdout-after-matrix.py, log/tmp/kaponir-holdout.log. Waits forPID73172 cmdline todisappear, verifiesall3completed+profile/provenance. Then selects **current_union additive finder** highest calibrationcoverage, tie feweroutside then smallerartifact; NEVERautofilter orapplyrules. Runs '--schemes free --documents03..07'(127gold) samebudget, outputartifacts/.../selected-holdout. Installsselectedweights; ifMini wins, removesta[REDACTED_PROVIDER_KEY] tofitdisk. Selectionmetadataat.../holdout-selection.json. Olderfailedqueue45737 wasboundtodeadoldpid; new7279correct.

Newharnessmetadata active_runtime_memory_policy={cache_ram_mib:0,cache_idle_slots:False,request_cache_prompt:False}; Qwenstate runtime_cache_history manuallyrecordsfirst67defaultthen0. New matrixsummarize publishesmemorypolicy/history,allprovenance,detector_applied,resources. PROFILE nowchecksmax_candidates24,max_fragments256,timeout300 +generationdefaultsandno probes.3matrixtestspass; no method/promptchanges.

Minor serializationfix: stage freezes decisiondict bycandidateids (previous first.update(extra) alsoappendedunionextras toserializedpointdecisions; metricsalwaysscoredonlypointcandidatesandunchanged). OldMini/Qwenserializedpoint MAYextraIDs; alwaysfilterbycandidateIDsforanalysis. NewHuiwillsnapshotproperly. No needrerun qualityforserialization.

Latestnew Rustrecheck afterworkerfix execsession**51806**, log/tmp/kaponir-validation-rust-final.log, currentlyrunning190tests. Needpollcompletion. Previousclippypassed, onlyPythonembeddedchanged; rebuildCLIembedlatestworker forfinal ifneeded. UItests werealreadyPASS onpriorproduction state, newchange onlyruntimecacheflags provenrealnative+test.

Usercommentarylatest: confirmed rootcache;2repliesexact; continueQwen/Hui; notclaimsemanticmodelqualityfixed. KeepRussianupdates~60secs; canstreamstatuswithshorttoolloops whilewaiting butavoidmeaninglessrepeats. No subagents, nopushyetyet.

# Kaponir active task / priority
User approved implementing experiments on fast-detector candidate validation, record extraction, double validation and stronger models. Latest correction: MUST finish original MiniCPM5-2B / Qwen3.5-2B / Huihui-Qwen3.5-2B same-scheme matrix BEFORE expanding stronger models. We acknowledged we had drifted and no general winner is established. Continue autonomously; don't end with only a plan. Prior push authorization persists. No subagents allowed.

Repo /workspace/Kaponir main initial b7bb735. Many uncommitted changes (git status). No AGENTS. Cloud runtime skill read earlier, no need reread. Tools socket/network need require_escalated (auto approves). CPU quota2, cgroup8GiB, disk7.9GiB. Commentary in Russian, meaningful update within60s. Do not print old user API key; unused this turn.

# ACTIVE PROCESS
exec session85123: python scripts/evaluate_scheme_matrix.py --runtime /tmp/kaponir-real-eval/models/runtime/llama-b12038/llama-server --model-dir /tmp/kaponir-three-models --detectors artifacts/validation-schemes/detector_candidates --output artifacts/validation-schemes --models qwen3.5-2b huihui-qwen3.5-2b-abliterated
log /tmp/kaponir-original-matrix.log
Qwen currently running, Huihui automatically next. Both weights installed and SHA checked. Additional Granite sampling run was interrupted at user steering; no other model experiment should be running.

Artifacts: artifacts/validation-schemes/{minicpm-calibration,qwen-calibration,huihui-calibration}/result.json. Mini completed. Qwen current_union complete: 80/92 matches,51 outside vs Mini77/92,36outside. Point/regions/double pending. matrix.json primary summary; public runner summarize() can refresh, enforces same budgets/prompts/runtime/exporter/corpus. Tests test_scheme_matrix.py (3) enforce no mixing 20 probes with documents. Runner in-memory older version lacks later cross-provenance check, so explicitly rerun summarize after both finish (no inference).

# FROZEN main matrix profile
3 docs: 01-cost-estimate,02-application.log,08-public-reference;92gold. Entire corpus8docs219unique363occurrences. Holdout03-07=127gold UNTOUCHED. Need select best model+method after matrix then test best on5holdout. All main models: q4_k_m, CPU2, slot1, context4096,out1600,reserve64,hint256prefix,batch<=8,grammar,temp0,thinkingFalse,maxCandidates24,fragments256,timeout300. Actual tokenizer counts+adaptive splitting. S1/rules off. No model kind/score hint to verifier. Methods rawfast,current_union(fast+freeLLM),point(fast),regions,recheck union once(union_point),double(sameunion independent prompts).
Unit exact(file,value), not actual masking leakage. protected10 includes7gold+3out: ANON_SECRET_19(unapplied),database,upstream. Guards can't reject these; mention ceiling not model mistakes. Raw scope personal placeholder cannot grade original scope accuracy.
Mini final metrics:
rawfast proposals94 true68 extra26; applied32 true15 extra17.
union113 true77 extra36.
point retained47 extra5 dropped21 needs35 confirmed13.
regions proposals23 true17 extra6 (75of92notfound, NOT zero filtering failure).
union_point retained50 extra6 dropped27 needs39 confirmed13.
double retained53 extra11 dropped24 needs54 confirmed7 (all protected gold).
Separate balanced-context Mini sameprofile excepthead+tailpreamble: pointretained57 extra8 dropped11 needs44 confirmed13. Context helps but unsafe.
Initial exporter wrong reattached business values by substring (6800 in236800,etc4values). Fixed to actual discovery.example offsets, Rust regression test. Mini correct final run cached exact unchanged requests only; old invalid trial at minicpm-calibration-v1-context-error. Calls83 includes abandoned contexts; DO NOT rank cold latency/cost. New binary saved artifacts/.../detector_candidates. Same binary used all3.

# Code/product done
New offline scripts validation_pipeline.py/evaluate_validation_schemes.py/example exporter + tests. Source-grounded3way mask/keep/review, IDs exact, citeproof, numericaltypeguard, errorsreview, hardcredentialsprotected. combine two valid abstentions returns validreview; invalid KEEP never countedfiltered. Regions preserve originals as pending on transport/planning errors. Saves raw replies aftereachcall, resume profiles locked.
New production manual review: schema action review accepted, rec.state needs_review, reason visibleamber, Auto/apply blocked API(review_inconclusive)+UI; existing rules only manual confirmation. Model IDs opaque24hex. Existing review Rust integration extended for newstate, opaque IDs/no kind/prob hint.
New builtins Nano4.2-3B,Granite4.2-3B,Gemma4E4B QAT in Worker+core modelID whitelist+UI. Pins tests/fixtures/validation-models.json (main3 pins also Worker.FILES; don't index fixture blindly).
Real Nano compatibility bug: b12038 starts model but ANY response_format JSONschema returnsHTTP400 Failed initialize samplers std::exception. PlainJSONworks, no OOM. Implemented generic bootstrap1-token JSONcapability probe in Worker.start_runtime, no doc data. Only recognized sampler400 falls back to schema_in_prompt; unrelatedHTTP propagate. Effective schema prompt fully token-counted BEFOREplanning. Native worker/evaluate and legacy extraction use fallback; requests still validated. Mode recordedtelemetry+safeRusttrace.
New InferenceSettings.response_format auto|grammar|prompt defaultauto, validated+cache fingerprint; Worker obeys; APIprompt omits response_format but still JSONschema instruction. UI advanced selector+questiontip+diagnosticmode, RU/EN. UI tests verify profile roundtrip and no API response_format. No sampling knobs in PRODUCTION (temp0 still hardcoded); only experiment script has configurable sampling flags added later; do not add more scope until main matrix complete.
Compose worker memory now ${KAPONIR_WORKER_MEMORY:-8g}, CPUs${KAPONIR_WORKER_CPUS:-2.0}; parser checked defaults+override(12g4CPU), no containers deployed. docs notes bigger than4GB observedRSS.

# Tests / build
Rust toolchain CARGO_HOME=/tmp/kaponir-cargo RUSTUP_HOME=/tmp/kaponir-rustup; command env CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_INCREMENTAL=0 /tmp/kaponir-cargo/bin/cargo ...
Latest cargo test --workspace190passed log /tmp/kaponir-validation-rust-final.log. Exporter separatetest1passed earlier. Clippy workspacealltargets -Dwarnings passed /tmp/kaponir-validation-clippy-final.log. fmtpassed.
83Python passed before adding matrix3+sampling2 =>88 expected final. Final run needed. localhosttests requireescalated.
Latest UI BOTH PASS: /tmp/kaponir-validation-review-ui-final.log (JSONprofile/abstention/opaque asyncetc), /tmp/kaponir-validation-models-ui-final.log (all6additionalpresets/HF/closedloop/viewport). Screens artifacts/.../{review-ui,models-ui}. target/debug/kaponir currently built latest production changes. Old saved /tmp/kaponir-validation-current may predate response_format newfield; don't assume latest. Need copy latest before cleaning target if needed.
No Rust changes after final tests; later Python experiment-only generation knobs/matrix aren't embedded in product (except helper unchanged). JS syntax and locale tests passed. git diffcheck final needed.

# Separate diagnostic sweeps (NOT original matrix / NOT main winner)
20fictitiouscases9private9public2ambig; tests/fixtures/validation-review-heldout.json frozen input; expected NEVERinrequest. Datasetused for diagnostic/calibration, not fullheldout5docs. Names differ but allinputsame20.
Mini grammar batch8: pointvalid17/actions9/privateKept0/jointKindScope0; auditvalid17/actions10/privateKept3; doubleactions8,needs12.
Mini grammar batch1: pointactions10/privateKept4/joint1; auditprivateKept9; doubleprivateKept4 needs8. Singleton NOT universal improvement.
Mini prompt batch1: pointvalid11/actions9/privateKept0/joint1; auditactions6/privateKept7; doubleneeds15 actions6.
Nano grammar batch8:6HTTP400 =>0valid TECHNICAL, not modelquality.
Nano prompt batch8:timeout300,aborted preserved ...batch8-timeout. OOM0.
Nano prompt batch1:40calls complete, pointvalid15/actions12/privateKept2/joint4; auditvalid13/actions12/privateKept0; doubleactions8 needs12. Some apparent safety from bad metadata maxreason120; raw audit wronglykeepsinternalaccounts/projects too but rejectedbecauseverbose reason. Raw diagnostic report separate. JSONDecodeError2 on Cyrillicname, rawcontent notsaved so causeunknown. Do NOT assume fences, no parser changes done.
Granite prompt batch1:40complete pointvalid13/actions8/privateKept3/joint3; auditactions8/privateKept0; doubleneeds16/actions3.
Gemma NOT TESTED yet; user explicitly deprioritized stronger until main3 complete.
All nonthinkinggreedy0. Officialcards fetched /tmp/kaponir-card-{MiniCPM5-2B,Nanbeige4.2-3B,granite-4.2-3b,gemma-4-E4B-it}.md. Mini/Granite/Gemma recommend temp1/topP.95, Nano.6/.95/k20. Started Granite sampled20 primaryonly temp1/.95/k64/minp0/seed42, interrupted bylateststeering, state ...granite-probes-sampled maybe running marker (SIGINT nofinal), NOT maincomparison. No need resume until main done.

# Reporting / next
Primary docs/SCHEME_COMPARISON.md created clear methods/profile/status, replace final status with all3data+bestholdout oncecomplete. docs/VALIDATION_EXPERIMENTS.md diagnostics/methods/Mini controls. docs/VALIDATION_RESULTS.json draft mixeddiagnostic report; DO NOT present as main matrix winner. /tmp/kaponir-validation-report.py builds it; need update to include mainQwen/Hui if desired (or primary separate SCHEME_COMPARISON.json frommatrix). It computes rawverdict diagnostics for20cases, not strictvalidated. All docs final must separate mainmatrix,20probes,contextablation; no mixedrank.
Need finish Qwen/Hui, choose best pipeline based coverage,privatevaluesfiltered,noise,manualreview,type/scope (invalidreview not filtering). Then5holdout127. If no safe automaticfilter, say so and keep manual. Don't claim fullpipeline tested for everystrongmodel. Need final commit+push authorized; no pushes yetthisturn. Do not finalpartialonlyplan.

# Disk/runtime
Only Qwen/Hui weights now /tmp/kaponir-three-models (2.55GBtotal), both taskdownloaded; Mini/Nano/Gran removed AFTERmodelstop tofree disk. Runtime /tmp/kaponir-real-eval/models/runtime/llama-b12038/llama-server SHA3e042c4518a74fc3bdb3edb80e07922ee01d6a3455618952af23f3e546508934. Rustup617MB registry234MB debug~836MB. Space~1.2GiB. Don't need Gemma space now. If laterGemma5.15GB: savecurrentCLI/exporter, removeonlytaskbuildcache andweights, compressRustup+registry tar backup (notuserfiles), restoreafterweightsremoved. No code/source deletion.
