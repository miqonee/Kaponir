"""Wait for the frozen cohort, then verify its best additive finder on new docs."""
import json
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT=Path('/workspace/Kaponir')
sys.path.insert(0,str(ROOT/'scripts'))
from check_learning_corpus import load_corpus
from compare_local_models import DOCUMENTS
from evaluate_scheme_matrix import COHORT, summarize
from evaluate_validation_schemes import atomic_json
from kaponir_worker import Worker, configuration

base=ROOT/'artifacts/validation-schemes'
runtime=Path('/tmp/kaponir-real-eval/models/runtime/llama-b12038/llama-server')
models=Path('/tmp/kaponir-three-models')
runner=Path('/proc/73172/cmdline')
while runner.exists() and b'evaluate_scheme_matrix.py' in runner.read_bytes():
    time.sleep(10)
matrix=summarize(base)
if any(row['status']!='completed' for row in matrix['models'].values()):
    raise RuntimeError('original_matrix_not_complete')

# Validation has already discarded gold data on calibration. This selection is
# explicitly for adding candidates, not approving masks or rejecting findings.
selected=min(COHORT,key=lambda model:(
    -matrix['models'][model]['methods']['current_union']['visible_matches'],
    matrix['models'][model]['methods']['current_union']['visible_outside'],
    matrix['models'][model]['artifact'][1]))
_,_,_,sources,_=load_corpus()
documents=[name for name in sources if name not in DOCUMENTS]
selection={'model':selected,'method':'current_union','documents':documents,
    'policy':'Select additive finder by maximum calibration exact-value coverage, then fewer outside-gold values, then smaller artifact. No automatic candidate filtering or rule application.',
    'calibration_metrics':matrix['models'][selected]['methods']['current_union']}
atomic_json(base/'holdout-selection.json',selection)
print(json.dumps(selection,ensure_ascii=False),flush=True)
with tempfile.TemporaryDirectory(prefix='kaponir-selected-install-') as temporary:
    task_home=Path(temporary)
    worker=Worker(task_home,configuration(task_home,{'model_dir':str(models),'runtime':str(runtime)}),'unused')
    try:
        artifact=worker.model_files()[selected]
        if not (models/artifact[0]).is_file():
            # Task-owned model downloads only; no model process is running now.
            for model in COHORT:
                if model!=selected:
                    (models/worker.model_files()[model][0]).unlink(missing_ok=True)
        job=worker.submit('download',model=selected)
        worker.install(job['id'],selected)
    finally:
        worker.stop.set();worker.stop_runtime()
subprocess.run([sys.executable,str(ROOT/'scripts/evaluate_validation_schemes.py'),
    '--model',selected,'--model-dir',str(models),'--runtime',str(runtime),
    '--detectors',str(base/'detector_candidates'),'--schemes','free',
    '--documents',*documents,'--output',str(base/'selected-holdout')],check=True)
