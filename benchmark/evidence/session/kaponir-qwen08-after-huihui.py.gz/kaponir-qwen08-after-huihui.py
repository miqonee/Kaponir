import json,subprocess,sys,time
from pathlib import Path
root=Path('/workspace/Kaponir')
parent=Path('/proc/75235/cmdline')
while parent.exists():
    try:command=parent.read_bytes()
    except FileNotFoundError:break
    if b'evaluate_validation_schemes.py' not in command:break
    time.sleep(5)
state=json.loads((root/'artifacts/validation-schemes/huihui-calibration/result.json').read_text())
if state['status']!='completed':raise RuntimeError('huihui_matrix_incomplete')
subprocess.run([sys.executable,str(root/'scripts/evaluate_scheme_matrix.py'),
    '--runtime','/tmp/kaponir-real-eval/models/runtime/llama-b12038/llama-server',
    '--model-dir','/tmp/kaponir-three-models','--detectors',str(root/'artifacts/validation-schemes/detector_candidates'),
    '--output',str(root/'artifacts/validation-schemes'),'--models','qwen3.5-0.8b'],check=True,cwd=root)
