# Сводные таблицы экспериментов

Источник: [VALIDATION_RESULTS.json](VALIDATION_RESULTS.json). Короткий разбор: [LOCAL_MODEL_FINDINGS.md](LOCAL_MODEL_FINDINGS.md). Методы и ограничения: [SCHEME_COMPARISON.md](SCHEME_COMPARISON.md).

Это синтетические документы. Совпадение — точное значение в правильном документе. Значения вне эталона включают ошибки границ и не все являются ложными срабатываниями.

## Общая матрица всех моделей

В ячейке: **осталось эталонных из 92 / осталось вне эталона**. Включены записи на review. Это не число автоматически правильных решений.

| Схема | MiniCPM5-2B | Qwen3.5-2B | Huihui | Qwen3.5-0.8B | Nanbeige4.2-3B | Granite4.2-3B | Gemma4 E4B QAT |
|---|---|---|---|---|---|---|---|
| Предложения детекторов | 68 / 26 | 68 / 26 | 68 / 26 | 68 / 26 | 68 / 26 | 68 / 26 | 68 / 26 |
| Детекторы + поиск LLM | 77 / 36 | 80 / 51 | 76 / 66 | 76 / 47 | 89 / 69 | 79 / 26 | 86 / 36 |
| Проверка предложений детекторов | 47 / 5 | 13 / 20 | 27 / 15 | 68 / 26 | 60 / 11 | 58 / 6 | 8 / 3 |
| Поиск в записях срабатывания | 17 / 6 | 70 / 24 | 47 / 23 | 30 / 26 | 71 / 4 | 50 / 11 | 31 / 7 |
| Один проход по объединённому пулу | 50 / 6 | 23 / 34 | 34 / 53 | 76 / 47 | 69 / 26 | 58 / 6 | 10 / 3 |
| Два прохода по тому же пулу | 53 / 11 | 80 / 42 | 71 / 56 | 76 / 47 | 74 / 35 | 74 / 21 | 28 / 7 |

### Покрытие поиска с учётом состава данных

51 из 92 эталонных значений — суммы, уже предложенные детекторами. Разбивка относится к эталонному типу найденных значений; правильность типа, присвоенного LLM, оценивается отдельно.

| Пул | Суммы | Остальные значения | Всего |
|---|---|---|---|
| Предложения детекторов | 51 / 51 | 17 / 41 | 68 / 92 |
| MiniCPM5-2B + детекторы | 51 / 51 | 26 / 41 | 77 / 92 |
| Qwen3.5-2B + детекторы | 51 / 51 | 29 / 41 | 80 / 92 |
| Huihui + детекторы | 51 / 51 | 25 / 41 | 76 / 92 |
| Qwen3.5-0.8B + детекторы | 51 / 51 | 25 / 41 | 76 / 92 |
| Nanbeige4.2-3B + детекторы | 51 / 51 | 38 / 41 | 89 / 92 |
| Granite4.2-3B + детекторы | 51 / 51 | 28 / 41 | 79 / 92 |
| Gemma4 E4B QAT + детекторы | 51 / 51 | 35 / 41 | 86 / 92 |

- MiniCPM5-2B: завершён.
- Qwen3.5-2B: завершён.
- Huihui: завершён.
- Qwen3.5-0.8B: завершён.

Пулы поиска ещё не классифицируют приватность и scope. Защищённые credentials сохранены правилами; это не заслуга LLM.

## Условия сравнения

Те же 92 значения и шесть схем. Совместимый JSON-режим выбирается технической пробой runtime; эффективный режим указан под таблицей. Основной профиль temperature=0 отделён от рекомендованных sampling-профилей ниже.

Контекст 4096 и выход 1600 совпадают с младшими моделями. Для больших моделей CPU-таймаут увеличен с 300 до 1200 секунд; все запросы младших моделей основной матрицы завершились в пределах 300 секунд. В режиме prompt лимит 24 кандидата задаётся инструкцией и порогом дробления входа; ответ может содержать больше строк. Это отличается от ограничения JSON-грамматикой.

Четыре младшие модели основной матрицы использовали JSON Schema.

- Nanbeige4.2-3B: завершён; JSON: prompt; ошибки запросов/JSON, включая восстановленные дроблением: JSONDecodeError × 7; ошибки этапов; могут относиться к тем же запросам: JSONDecodeError × 4.
- Granite4.2-3B: завершён; JSON: grammar.
- Gemma4 E4B QAT: завершён; JSON: grammar.

Gemma использует QAT Q4_0, остальные — Q4_K_M. Это не одинаковое квантование.

## Объединение сохранённых региональных находок с детекторами

Анализ уже полученных списков, **без новых запросов LLM**. Все исходные предложения сохранены и дополнены региональными находками. Это расчёт кандидатного пула, а не отдельный прогон проверки приватности, типа, scope или применения правил. Основные шесть схем выше не меняются.

| Модель | В эталоне / вне эталона | Добавлено: эталон / вне эталона |
|---|---|---|
| MiniCPM5-2B | 74 / 29 | 6 / 3 |
| Qwen3.5-2B | 77 / 46 | 9 / 20 |
| Huihui | 76 / 45 | 8 / 19 |
| Qwen3.5-0.8B | 71 / 47 | 3 / 21 |
| Nanbeige4.2-3B | 78 / 27 | 10 / 1 |
| Granite4.2-3B | 75 / 34 | 7 / 8 |
| Gemma4 E4B QAT | 78 / 30 | 10 / 4 |

## Проверка на правильных границах кандидатов

32 отрезка: 16 приватных, 16 публичных. Метки и типы не отправляются модели; обход LLM для защищённых credentials отключён. Это контроль LLM, а не recall детекторов. Review включает ошибки формата и цитирования. Числа подтверждения приватного не гарантируют правильный тип и scope.

| Профиль | Метод | Верный mask приватного | Верный keep публичного | Ошибочный keep приватного | Ошибочный mask публичного | Review | Верны тип и scope / mask приватного | Сбоев пакетов |
|---|---|---|---|---|---|---|---|---|
| gemma-card-document | review-document-bounded | 7 | 16 | 9 | 0 | 0 | 6/7 | 0 |
| gemma-card-document | review-document-off | 0 | 14 | 14 | 0 | 4 | — | 0 |
| granite-card-document | review-document-bounded | 0 | 8 | 3 | 0 | 21 | — | 0 |
| granite-card-document | review-document-off | 0 | 8 | 11 | 0 | 13 | — | 0 |
| minicpm-common | review-record-bounded | 0 | 12 | 12 | 0 | 8 | — | 0 |
| minicpm-common | review-record-off | 1 | 9 | 12 | 4 | 6 | 0/1 | 0 |
| minicpm-common | review-document-bounded | 2 | 13 | 12 | 1 | 4 | 2/2 | 0 |
| minicpm-common | review-document-off | 0 | 14 | 14 | 0 | 4 | — | 0 |
| minicpm-prompt-document | review-document-off | 0 | 0 | 0 | 0 | 32 | — | 5 |
| minicpm-single-record | review-record-off | 4 | 9 | 8 | 5 | 6 | 2/4 | 0 |
| nanbeige-card-document | review-document-bounded | 0 | 4 | 0 | 0 | 28 | — | 4 |
| nanbeige-card-document | review-document-off | 4 | 7 | 7 | 0 | 14 | 2/4 | 2 |
| qwen08-common | review-record-bounded | 0 | 0 | 0 | 0 | 32 | — | 0 |
| qwen08-common | review-record-off | 0 | 0 | 0 | 0 | 32 | — | 0 |
| qwen08-common | review-document-bounded | 0 | 3 | 5 | 0 | 24 | — | 0 |
| qwen08-common | review-document-off | 0 | 0 | 0 | 0 | 32 | — | 0 |
| qwen08-prompt-document | review-document-off | 0 | 0 | 0 | 0 | 32 | — | 0 |
| qwen08-single-record | review-record-off | 0 | 0 | 0 | 0 | 32 | — | 0 |
| qwen2-common | review-record-bounded | 0 | 6 | 6 | 0 | 20 | — | 0 |
| qwen2-common | review-record-off | 0 | 10 | 3 | 0 | 19 | — | 0 |
| qwen2-common | review-document-bounded | 0 | 7 | 10 | 0 | 15 | — | 0 |
| qwen2-common | review-document-off | 0 | 11 | 10 | 0 | 11 | — | 0 |
| qwen2-prompt-document | review-document-off | 0 | 8 | 1 | 0 | 23 | — | 0 |
| qwen2-single-record | review-record-off | 0 | 10 | 4 | 0 | 18 | — | 0 |

`record` — запись с подсказкой; `document` — весь документ. `bounded` — лимит reasoning в половину начального ответа; `on` — без этого ограничения. Профили `prompt` меняют и инструкцию формата, и способ ограничения JSON. `single` содержит один кандидат на запрос. Точные параметры — в JSON-сводке.

Технически неполные этапы не получают численную оценку качества. Сбой пакета оставляет его кандидатов на review; ноль подтверждений после таймаута не измеряет способность модели распознать приватность.

Технические ошибки сохранённых запросов контрольных профилей:

- `minicpm-card-document`: TimeoutError × 1, model_response_truncated × 3.
- `minicpm-common`: model_response_truncated × 1.
- `minicpm-native-document`: model_response_truncated × 2.
- `minicpm-prompt-document`: JSONDecodeError × 5.
- `nanbeige-card-document`: JSONDecodeError × 1, TimeoutError × 7.
- `qwen08-common`: model_response_truncated × 4.
- `qwen08-native-document`: model_response_truncated × 2.
- `qwen08-native-prompt`: model_response_truncated × 2.
- `qwen08-native-unbounded`: model_response_truncated × 4.
- `qwen2-common`: model_response_truncated × 3.
- `qwen2-native-document`: model_response_truncated × 2.

## Диагностика лимита объяснения

Повторная обработка тех же сохранённых ответов, **без новых запросов модели**. Во втором варианте reason обрезан до 120 символов; остальные проверки сохранены. Исходные результаты выше не меняются. Это разбор влияния ограничения формата, а не проверенный режим автоматического применения.

| Профиль | Метод | Обработка ответа | Верный mask приватного | Верный keep публичного | Ошибочный keep приватного | Ошибочный mask публичного | Review | Верны тип и scope / mask приватного |
|---|---|---|---|---|---|---|---|---|
| qwen2-prompt-document | review-document-off | Исходный контракт | 0 | 8 | 1 | 0 | 23 | — |
| qwen2-prompt-document | review-document-off | Обрезан только reason | 12 | 8 | 4 | 6 | 2 | 4/12 |

Обрезка объяснения может пропустить и ошибочные keep. Соответствие длине текста не доказывает правильность приватности, типа или scope.

## Поиск по целому документу

В ячейке те же эталонные/вне эталона. Пул включает быстрые детекторы. Флаги confirmed и scope у поискового пула не означают проверенную приватность. По сравнению с основной матрицей здесь также увеличены лимиты контекста, ответа и предложений; это сравнение профилей.

| Профиль | Метод | Осталось / вне эталона | Документов завершено |
|---|---|---|---|
| gemma-card-document | discovery-document-bounded | 79 / 27 | 3 |
| gemma-card-document | discovery-document-off | 84 / 27 | 3 |
| granite-card-document | discovery-document-bounded | 75 / 27 | 3 |
| granite-card-document | discovery-document-off | 76 / 26 | 3 |
| minicpm-card-document | discovery-document-off | 72 / 29 | 3 |
| minicpm-card-document | discovery-document-on | неполный | 1 |
| minicpm-common | discovery-document-bounded | 68 / 27 | 3 |
| minicpm-common | discovery-document-off | 81 / 29 | 3 |
| minicpm-native-document | discovery-document-on | неполный | 0 |
| nanbeige-card-document | discovery-document-bounded | неполный | 1 |
| nanbeige-card-document | discovery-document-off | 86 / 31 | 3 |
| qwen08-common | discovery-document-bounded | 70 / 31 | 3 |
| qwen08-common | discovery-document-off | 68 / 30 | 3 |
| qwen08-native-document | discovery-document-on | неполный | 0 |
| qwen08-native-prompt | discovery-document-on | неполный | 0 |
| qwen2-common | discovery-document-bounded | 77 / 32 | 3 |
| qwen2-common | discovery-document-off | 74 / 33 | 3 |
| qwen2-native-document | discovery-document-on | неполный | 0 |

## Отложенные документы

127 эталонных значений в пяти других документах. Выбор добавляющего поиск профиля сделан по калибровке, без автоматического отклонения кандидатов.

Статус: завершён.

Модель: Qwen3.5-2B.

| Схема | Осталось / вне эталона |
|---|---|
| Предложения детекторов | 51 / 40 |
| Детекторы + поиск LLM | 79 / 58 |

Результаты коротких диагностических проб на 20 случаях не включены в документную матрицу. Сырые контрольные точки и их SHA — [benchmarks](benchmarks/README.md).
